# skewdist

Fit a skew-aware probability distribution to a list of scores.

Given a small, often-skewed sample of numeric outcomes (scores, times,
counts, ratings — anything where a plain normal distribution fits
badly because the data leans left or right), `skewdist` picks a
transform that symmetrizes the data, fits a normal curve on the
transformed axis, and maps it back to a usable probability curve over
your original scale.

No dependencies. Pure Python 3.9+, stdlib only. Optional matplotlib
support for quick plotting.

## Install

```bash
pip install .
# or, with the optional plotting helper:
pip install ".[plotting]"
```

## Quick start

```python
import skewdist

scores = [12, 15, 9, 40, 14, 11, 16, 13, 10, 38]
dist = skewdist.fit(scores)

dist.mode                 # the most likely score (x-value where the curve peaks)
dist.mean, dist.stdev     # fitted mean/stdev (in transformed space)
dist.method               # which transform was chosen (a skewdist.Method)
dist.pdf(20)              # density at any raw score, on demand
dist.normalized_curve     # precomputed peak-scaled curve (0..1)
dist.x_values             # the x-axis the curve was evaluated on
```

Optional quick plot:

```python
from skewdist.plotting import plot
plot(dist)
```

## How it works

1. **Measure skew.** Compute the sample skewness of your raw scores.
2. **Pick a transform.** Try four candidates — no transform, sqrt/square,
   log10/cube, reciprocal/quartic (direction depends on the sign of the
   raw skew) — and keep whichever makes the transformed data closest to
   symmetric (skew nearest 0).
3. **Fit a normal curve** on the transformed data (mean, stdev).
4. **Map back.** For any raw score `x`, apply the same transform and
   evaluate the normal PDF at the transformed point. A hard cutoff
   (default: the 95th percentile of your raw data) zeroes the curve out
   past the range your sample actually supports — otherwise the fitted
   normal's tail can extend into territory the data gives you no
   evidence for.
5. **Normalize (optional).** Rescale so the curve's peak is 1.0, useful
   for comparing shapes across different entities regardless of scale.

This is a general technique, not tied to any particular domain — it
was pulled out of a larger scouting/forecasting application because
the score-list → fitted-distribution step is broadly useful on its
own.

## API

### `skewdist.fit(scores, **kwargs) -> SkewDistribution`

| Parameter | Default | What it does |
|---|---|---|
| `scores` | — | List of numeric observations. `None`s are dropped. |
| `x_min`, `x_max` | `0`, `2 * max(scores)` | Range the curve is evaluated over. |
| `num_points` | `500` | Grid resolution between `x_min` and `x_max`. |
| `cutoff_percentile` | `0.95` | Curve forced to 0 above this percentile of raw scores. Use `1.0` to disable. |
| `build_grid` | `True` | Set `False` to skip precomputing the curve if you only need `.pdf(x)` at a few points. |
| `broaden` | `False` | Sqrt-broaden (soften) the normalized curve — for entities you already know are "weak" relative to a peer group. |
| `population_means` | `None` | Peer-group mean scores; if given, `broaden` is computed automatically (bottom `broaden_percentile`). |
| `broaden_percentile` | `0.27` | Threshold used against `population_means`. |

### `SkewDistribution`

Dataclass returned by `fit()`. Key fields: `mean`, `stdev`, `raw_skew`,
`method`, `positive_skew`, `cutoff`, `mode`, `x_values`, `curve`,
`normalized_curve`, `is_broadened`.

Methods:
- `.pdf(x)` — evaluate the un-normalized fitted density at any raw x.
- `.normalized_pdf(x)` — same, peak-scaled to 1.0.
- `.to_dict()` — plain-dict snapshot for serialization.

### `skewdist.Method`

Enum of the four candidate transforms: `RAW`, `SQRT`, `LOG10`, `RECIPROCAL`.

## What this library is *not*

This is intentionally narrow: one transformation, scores in,
distribution out. It does not include data import, storage, team/player
management, match/comparison logic, or a UI — those live in the
application this was extracted from. If you need the full pipeline for
comparing two combined groups' curves or forecasting head-to-head
outcomes, you'll need to build that on top of this.

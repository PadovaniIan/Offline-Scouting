"""
skewdist.core

The core transformation this library exists for:

    a list of observed scores  -->  a fitted, skew-aware distribution

Method, in brief
-----------------
1.  Compute the raw sample skewness of the scores.
2.  Try four candidate transforms meant to symmetrize the data (see
    `skewdist.transforms`): none, sqrt/square, log10/cube, 1/x/quartic
    - the direction depends on the sign of the raw skew. Whichever
    candidate's transformed skewness is closest to 0 is chosen.
3.  Fit a plain normal distribution (mean, stdev) to the chosen
    transform's output. This is the "skew-adjusted" mean/stdev.
4.  Build a probability curve over an x-axis of *raw* scores by, for
    each x, applying the same chosen transform and evaluating the
    normal PDF at the transformed point. A hard upper cutoff (default:
    the 95th percentile of the raw scores) zeroes the curve out beyond
    the range the data actually supports, since the fitted normal's
    tail can otherwise extend into score ranges the sample gives no
    evidence for.
5.  Optionally rescale so the curve's peak is 1.0, and optionally
    broaden (sqrt) the curve for entities that are weak relative to a
    peer group you supply - see `broaden` / `population_means` below.

This process was reverse-engineered from a specific analytical tool
but the technique itself - pick a symmetrizing transform, fit a normal
distribution on the transformed axis, then map back - is general and
useful anywhere you have a smallish, often-skewed sample of numeric
outcomes (scores, times, counts, ...) and want a smooth distribution
rather than just a mean/stdev.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

from ._stats import normal_pdf, percentile, sample_skewness, sample_stdev
from .transforms import Method, transform_series, transform_value

__all__ = ["SkewDistribution", "fit"]


@dataclass
class SkewDistribution:
    """
    A fitted skew-aware distribution over a series of raw scores.

    Attributes
    ----------
    scores:        the original input, cleaned of None values.
    method:        which transform (`Method`) was chosen.
    positive_skew: the sign of the RAW skewness that determined the
                   transform's direction (see `skewdist.transforms`).
    mean, stdev:   mean/stdev of the CHOSEN-TRANSFORM's output (i.e.
                   in transformed space, not raw-score space).
    raw_skew:      sample skewness of the untransformed scores.
    cutoff:        raw-score x-value above which the curve is forced
                   to 0 (see `cutoff_percentile` in `fit`).
    x_values:      the x-axis grid the curve was evaluated on, in raw
                   score units (only populated if a grid was built;
                   `pdf()` works at any x regardless).
    curve:         un-normalized PDF values at each `x_values` point.
    normalized_curve:
                   `curve` rescaled so its peak is 1.0 (and optionally
                   sqrt-broadened - see `is_broadened`).
    is_broadened:  whether the sqrt-broadening was applied to
                   `normalized_curve`.
    mode:          the raw-score x-value where the curve peaks.
    """

    scores: list[float]
    method: Method
    positive_skew: bool
    mean: float
    stdev: float
    raw_skew: float
    cutoff: float
    x_values: list[float] = field(default_factory=list)
    curve: list[float] = field(default_factory=list)
    normalized_curve: list[float] = field(default_factory=list)
    is_broadened: bool = False
    mode: float = 0.0

    def pdf(self, x: float) -> float:
        """
        Evaluate the (un-normalized) fitted PDF at any raw-score x,
        independent of the precomputed grid. Returns 0.0 beyond the
        cutoff or where the transform is undefined at x.
        """
        if x > self.cutoff:
            return 0.0
        tx = transform_value(float(x), self.method, self.positive_skew)
        if tx is None or self.stdev == 0:
            return 0.0
        return normal_pdf(tx, self.mean, self.stdev)

    def normalized_pdf(self, x: float) -> float:
        """Same as `pdf`, but rescaled so the curve's peak is 1.0."""
        peak = max(self.curve, default=0.0)
        if peak <= 0:
            return 0.0
        ratio = self.pdf(x) / peak
        return ratio ** 0.5 if self.is_broadened else ratio

    def to_dict(self) -> dict:
        """Plain-dict snapshot, e.g. for JSON serialization or a DataFrame row."""
        return {
            "method": self.method.value,
            "positive_skew": self.positive_skew,
            "mean": self.mean,
            "stdev": self.stdev,
            "raw_skew": self.raw_skew,
            "cutoff": self.cutoff,
            "mode": self.mode,
            "is_broadened": self.is_broadened,
            "x_values": list(self.x_values),
            "curve": list(self.curve),
            "normalized_curve": list(self.normalized_curve),
        }


def _choose_method(scores: Sequence[float]) -> tuple[Method, bool, list[float]]:
    """Returns (chosen_method, positive_skew, transformed_values_under_chosen_method)."""
    raw_skew = sample_skewness(scores)
    positive_skew = raw_skew > 0

    candidates: dict[Method, list[float]] = {Method.RAW: list(scores)}
    for m in (Method.SQRT, Method.LOG10, Method.RECIPROCAL):
        candidates[m] = transform_series(scores, m, positive_skew)

    candidate_skews = {
        m: (raw_skew if m is Method.RAW else sample_skewness(vals))
        for m, vals in candidates.items()
    }
    chosen = min(candidate_skews, key=lambda m: abs(candidate_skews[m]))
    return chosen, positive_skew, candidates[chosen]


def fit(
    scores: Sequence[float],
    *,
    x_min: Optional[float] = None,
    x_max: Optional[float] = None,
    num_points: int = 500,
    cutoff_percentile: float = 0.95,
    build_grid: bool = True,
    broaden: bool = False,
    population_means: Optional[Sequence[float]] = None,
    broaden_percentile: float = 0.27,
) -> SkewDistribution:
    """
    Fit a skew-aware distribution to a list of scores.

    Parameters
    ----------
    scores:
        The observed values for one entity (e.g. one player's, team's,
        or process's historical scores). None values are dropped.
        Needs at least 1 value; skewness-based method selection and a
        meaningful stdev need at least 3.
    x_min, x_max:
        Raw-score range to evaluate the curve over. Defaults to
        `0` and `2 * max(scores)` if not given.
    num_points:
        How many evenly spaced points to evaluate between x_min and
        x_max. Ignored if `build_grid=False`.
    cutoff_percentile:
        The curve is forced to 0 above this percentile of the raw
        scores (default: 95th percentile), since a fitted normal's
        tail can otherwise extend past what the sample supports. Pass
        `1.0` to disable the cutoff (uses the sample max).
    build_grid:
        If False, skip precomputing `x_values`/`curve`/
        `normalized_curve` and only fit the underlying parameters -
        useful if you only need `.pdf(x)` at a handful of points and
        want to skip the grid evaluation cost.
    broaden:
        If True, sqrt-broadens the normalized curve (spreads it out,
        softening the peak) - intended for entities you've already
        determined are "weak" relative to some peer group. You can set
        this directly, or leave it False and instead pass
        `population_means` to have it computed for you.
    population_means:
        Optional peer-group reference: the mean score of each peer
        entity (this entity's own mean should typically be included).
        If given, `broaden` is computed as whether this entity's mean
        falls at or below the `broaden_percentile` of this list,
        overriding whatever `broaden` was passed as.
    broaden_percentile:
        The percentile threshold used against `population_means`
        (default: 0.27, i.e. the bottom ~27% of the peer group).

    Returns
    -------
    A `SkewDistribution` with the fitted parameters and (by default) a
    precomputed curve.

    Raises
    ------
    ValueError if `scores` is empty after dropping None values.
    """
    clean = [float(v) for v in scores if v is not None]
    if not clean:
        raise ValueError("scores must contain at least one non-None value")

    raw_skew = sample_skewness(clean)
    method, positive_skew, transformed = _choose_method(clean)
    mean_adj = sum(transformed) / len(transformed) if transformed else 0.0
    stdev_adj = sample_stdev(transformed)

    cutoff = percentile(clean, min(max(cutoff_percentile, 0.0), 1.0))

    dist = SkewDistribution(
        scores=clean,
        method=method,
        positive_skew=positive_skew,
        mean=mean_adj,
        stdev=stdev_adj,
        raw_skew=raw_skew,
        cutoff=cutoff,
    )

    if population_means is not None:
        own_mean = sum(clean) / len(clean)
        threshold = percentile(list(population_means), broaden_percentile)
        dist.is_broadened = own_mean <= threshold
    else:
        dist.is_broadened = broaden

    if build_grid:
        if x_min is None:
            x_min = 0.0
        if x_max is None:
            x_max = max(clean) * 2.0 if max(clean) > 0 else 1.0
        n = max(int(num_points), 2)
        step = (x_max - x_min) / (n - 1) if n > 1 else 0.0
        x_values = [x_min + i * step for i in range(n)]

        curve = [dist.pdf(x) for x in x_values]
        peak = max(curve, default=0.0)
        if peak > 0:
            ratio = [v / peak for v in curve]
            normalized = [r ** 0.5 for r in ratio] if dist.is_broadened else ratio
        else:
            normalized = [0.0] * len(curve)

        dist.x_values = x_values
        dist.curve = curve
        dist.normalized_curve = normalized
        if normalized:
            peak_idx = max(range(len(normalized)), key=lambda i: normalized[i])
            dist.mode = x_values[peak_idx]

    return dist

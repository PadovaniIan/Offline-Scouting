"""
skewdist.transforms

The four candidate "symmetrizing" transforms this library chooses
between. Each is meant to pull a skewed data series toward a
symmetric (skew ~ 0) shape so that a plain normal distribution can be
fit to it honestly.

Which direction a transform runs depends on the sign of the series'
OWN raw (untransformed) skewness:

    right-skewed (skew > 0)  -> compress the right tail:
                                 sqrt(x), log10(x), 1/x
    left-skewed  (skew <= 0) -> the mirror-image operation:
                                 x**2,   x**3,      x**4

`Method.RAW` is always included as a candidate (i.e. "don't transform
at all") so that data that's already close to symmetric is left alone.
"""

from __future__ import annotations

import math
from enum import Enum
from typing import Optional, Sequence

__all__ = ["Method", "transform_value", "transform_series"]


class Method(Enum):
    """A candidate transform. The library picks whichever minimizes |skew|."""

    RAW = "raw"
    SQRT = "sqrt"
    LOG10 = "log10"
    RECIPROCAL = "reciprocal"


def transform_value(x: float, method: Method, positive_skew: bool) -> Optional[float]:
    """
    Apply one transform to a single value.

    Returns None where the transform is undefined for that value (e.g.
    sqrt/log10 of a negative number, or 1/0) - the caller should drop
    such values from the series rather than error out, mirroring how
    spreadsheet IFERROR wrapping behaves for the same formulas.
    """
    if method is Method.RAW:
        return x
    if method is Method.SQRT:
        if positive_skew:
            return math.sqrt(x) if x >= 0 else None
        return x ** 2
    if method is Method.LOG10:
        if positive_skew:
            return math.log10(x) if x > 0 else None
        return x ** 3
    if method is Method.RECIPROCAL:
        if positive_skew:
            return (1.0 / x) if x != 0 else None
        return x ** 4
    raise ValueError(f"Unknown method: {method!r}")


def transform_series(values: Sequence[float], method: Method, positive_skew: bool) -> list[float]:
    """Apply `transform_value` across a series, dropping undefined results."""
    out = []
    for v in values:
        t = transform_value(v, method, positive_skew)
        if t is not None:
            out.append(t)
    return out

"""
skewdist._stats

Small, dependency-free statistics helpers used by the rest of the
library. Every function here operates on plain Python lists of floats
and has no third-party dependencies (no numpy/scipy), so the library
stays trivially installable anywhere.

Skewness and percentile match the conventions used by spreadsheet
tools (Excel/Google Sheets `SKEW` and `PERCENTILE`), which is what this
library's fitting method was originally derived against. That choice
is otherwise arbitrary and does not affect how you use the library.
"""

from __future__ import annotations

import math
from typing import Sequence

__all__ = ["sample_stdev", "sample_skewness", "percentile", "normal_pdf"]


def sample_stdev(values: Sequence[float]) -> float:
    """Sample standard deviation (ddof=1). Returns 0.0 for n < 2."""
    n = len(values)
    if n < 2:
        return 0.0
    mean = sum(values) / n
    var = sum((v - mean) ** 2 for v in values) / (n - 1)
    return math.sqrt(var)


def sample_skewness(values: Sequence[float]) -> float:
    """
    Adjusted Fisher-Pearson standardized moment coefficient - the same
    definition used by Excel/Google Sheets' SKEW() function:

        skew = [n / ((n-1)(n-2))] * sum(((x - mean) / stdev) ** 3)

    Returns 0.0 for n < 3 or when the data has zero spread (both cases
    where skewness is undefined).
    """
    n = len(values)
    if n < 3:
        return 0.0
    mean = sum(values) / n
    sd = sample_stdev(values)
    if sd == 0:
        return 0.0
    m3 = sum(((v - mean) / sd) ** 3 for v in values)
    return (n / ((n - 1) * (n - 2))) * m3


def percentile(values: Sequence[float], p: float) -> float:
    """
    Linear-interpolation percentile, matching Excel/Google Sheets'
    PERCENTILE (and numpy's default 'linear' method). `p` is in [0, 1].
    Returns 0.0 for an empty sequence.
    """
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    if n == 1:
        return s[0]
    rank = p * (n - 1)
    lo = int(rank)
    hi = min(lo + 1, n - 1)
    frac = rank - lo
    return s[lo] + (s[hi] - s[lo]) * frac


_SQRT_2PI = math.sqrt(2.0 * math.pi)


def normal_pdf(x: float, loc: float, scale: float) -> float:
    """
    Normal-distribution probability density function. Equivalent to
    `scipy.stats.norm.pdf(x, loc, scale)`, computed directly with the
    stdlib `math` module so this library never needs numpy/scipy.
    """
    if scale <= 0:
        return 0.0
    z = (x - loc) / scale
    return math.exp(-0.5 * z * z) / (scale * _SQRT_2PI)

"""
skewdist - fit a skew-aware probability distribution to a list of scores.

Quick start
-----------
    import skewdist

    dist = skewdist.fit([12, 15, 9, 40, 14, 11, 16, 13])
    dist.mode              # most likely score
    dist.pdf(20)           # density at any raw score
    dist.normalized_curve  # peak-scaled curve, ready to plot

See `skewdist.fit` for the full parameter list and `skewdist.core` for
a description of the method.
"""

from .core import SkewDistribution, fit
from .transforms import Method

__all__ = ["fit", "SkewDistribution", "Method", "__version__"]

__version__ = "1.0.0"

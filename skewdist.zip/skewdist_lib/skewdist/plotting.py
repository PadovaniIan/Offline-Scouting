"""
skewdist.plotting

Optional convenience plotting for a `SkewDistribution`. matplotlib is
NOT a hard dependency of this library - it's imported lazily here so
that `import skewdist` never requires it. Install it yourself
(`pip install matplotlib`) if you want to use this module.
"""

from __future__ import annotations

from typing import Optional

from .core import SkewDistribution

__all__ = ["plot"]


def plot(dist: SkewDistribution, *, normalized: bool = True, ax: Optional["object"] = None, show: bool = True):
    """
    Quick-look plot of a fitted `SkewDistribution`.

    Parameters
    ----------
    dist:        a `SkewDistribution` returned by `skewdist.fit(...)`,
                 built with `build_grid=True` (the default).
    normalized:  plot the peak-scaled curve (True, default) or the raw
                 curve (False).
    ax:          an existing matplotlib Axes to draw on. A new figure
                 is created if not given.
    show:        call `plt.show()` before returning (set False if
                 you're embedding this in your own GUI/figure).

    Returns
    -------
    The matplotlib Axes used.
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError as e:
        raise ImportError(
            "skewdist.plotting requires matplotlib. Install it with "
            "`pip install matplotlib`."
        ) from e

    if not dist.x_values:
        raise ValueError(
            "This SkewDistribution has no precomputed curve - call "
            "skewdist.fit(..., build_grid=True) (the default) first."
        )

    created_fig = False
    if ax is None:
        _, ax = plt.subplots()
        created_fig = True

    y = dist.normalized_curve if normalized else dist.curve
    ax.plot(dist.x_values, y)
    ax.axvline(dist.mode, linestyle="--", linewidth=1, label=f"mode = {dist.mode:g}")
    ax.axvline(dist.cutoff, linestyle=":", linewidth=1, label=f"cutoff = {dist.cutoff:g}")
    ax.set_xlabel("score")
    ax.set_ylabel("relative probability" if normalized else "density")
    ax.set_title(f"Fitted distribution ({dist.method.value})")
    ax.legend()

    if show and created_fig:
        plt.show()

    return ax

import math
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import skewdist
from skewdist import Method
from skewdist._stats import sample_skewness, sample_stdev, percentile, normal_pdf


def test_sample_stdev_basic():
    assert abs(sample_stdev([2, 4, 4, 4, 5, 5, 7, 9]) - 2.13809) < 1e-4
    assert sample_stdev([5]) == 0.0
    assert sample_stdev([]) == 0.0


def test_sample_skewness_symmetric_is_near_zero():
    assert abs(sample_skewness([1, 2, 3, 4, 5])) < 1e-9


def test_sample_skewness_needs_three_points():
    assert sample_skewness([1, 2]) == 0.0


def test_percentile_matches_linear_interpolation():
    assert percentile([1, 2, 3, 4], 0.5) == 2.5
    assert percentile([10], 0.9) == 10
    assert percentile([], 0.5) == 0.0


def test_normal_pdf_peak_at_mean():
    assert normal_pdf(0, 0, 1) > normal_pdf(1, 0, 1)
    assert normal_pdf(5, 5, 2) > normal_pdf(0, 5, 2)
    assert normal_pdf(1, 0, 0) == 0.0


def test_fit_returns_distribution_with_expected_shape():
    scores = [12, 15, 9, 40, 14, 11, 16, 13, 10, 38]
    dist = skewdist.fit(scores)
    assert isinstance(dist, skewdist.SkewDistribution)
    assert isinstance(dist.method, Method)
    assert dist.stdev >= 0
    assert len(dist.x_values) == 500
    assert len(dist.curve) == len(dist.x_values)
    assert len(dist.normalized_curve) == len(dist.x_values)
    # normalized curve peak should be 1.0 (or all zero in degenerate cases)
    assert max(dist.normalized_curve) in (0.0, 1.0) or abs(max(dist.normalized_curve) - 1.0) < 1e-9


def test_fit_drops_none_values():
    dist = skewdist.fit([10, None, 12, None, 14])
    assert dist.scores == [10.0, 12.0, 14.0]


def test_fit_rejects_all_none():
    try:
        skewdist.fit([None, None])
        assert False, "expected ValueError"
    except ValueError:
        pass


def test_fit_cutoff_zeroes_curve_above_percentile():
    scores = [10] * 20 + [1000]  # one big outlier
    dist = skewdist.fit(scores, cutoff_percentile=0.95)
    assert dist.pdf(999) == 0.0  # beyond the 95th-percentile cutoff


def test_fit_without_grid_still_supports_pdf():
    scores = [5, 6, 7, 8, 9, 10, 6, 7]
    dist = skewdist.fit(scores, build_grid=False)
    assert dist.x_values == []
    assert dist.pdf(7) >= 0.0


def test_broaden_via_population_means():
    scores = [1, 2, 1, 2, 1, 2]  # low performer
    population = [1.5, 10, 12, 15, 20]  # this entity's mean (1.5) is low in the group
    dist = skewdist.fit(scores, population_means=population, broaden_percentile=0.27)
    assert dist.is_broadened is True


def test_broaden_explicit_flag():
    dist = skewdist.fit([5, 6, 7, 8], broaden=True)
    assert dist.is_broadened is True


def test_custom_x_range_and_resolution():
    dist = skewdist.fit([1, 2, 3, 4, 5], x_min=0, x_max=10, num_points=11)
    assert dist.x_values[0] == 0
    assert dist.x_values[-1] == 10
    assert len(dist.x_values) == 11


if __name__ == "__main__":
    import inspect
    failures = 0
    tests = [f for name, f in list(globals().items()) if name.startswith("test_") and callable(f)]
    for t in tests:
        try:
            t()
            print(f"PASS: {t.__name__}")
        except AssertionError as e:
            failures += 1
            print(f"FAIL: {t.__name__}: {e}")
    print(f"\n{len(tests) - failures}/{len(tests)} passed")
    sys.exit(1 if failures else 0)

"""
Basic usage example for skewdist.

Run with:  python examples/example_usage.py
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import skewdist

# A right-skewed sample: mostly low scores with a couple of big outliers.
scores = [3, 5, 4, 6, 3, 5, 42, 4, 5, 3, 38, 6]

dist = skewdist.fit(scores)

print(f"Chosen transform : {dist.method.value}")
print(f"Raw skew         : {dist.raw_skew:.3f}")
print(f"Fitted mean/stdev (transformed space): {dist.mean:.3f} / {dist.stdev:.3f}")
print(f"95th-pct cutoff  : {dist.cutoff:.1f}")
print(f"Mode (most likely raw score): {dist.mode:.1f}")
print()
print("Density at a few raw scores:")
for x in (3, 10, 20, 40, 60):
    print(f"  pdf({x:>3}) = {dist.pdf(x):.5f}   normalized = {dist.normalized_pdf(x):.5f}")

# Uncomment to see a plot (requires `pip install matplotlib`):
# from skewdist.plotting import plot
# plot(dist)

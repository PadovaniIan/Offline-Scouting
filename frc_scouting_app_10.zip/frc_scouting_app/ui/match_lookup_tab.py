"""
ui/match_lookup_tab.py

Recreates the "Match Lookup" sheet: pick a match, see both alliances,
their per-robot stats, and the computed win odds / expected scores from
calculations.alliance_generator + calculations.match_odds (built live
from each alliance's three teammates' Normalized Distributions curves -
see those modules' docstrings for exactly how the two alliances' curves
are combined and compared).
"""

import tkinter as tk
from tkinter import ttk

from database import get_connection
from calculations.alliance_generator import build_alliance_distribution
from calculations.match_odds import compute_match_odds


class MatchLookupTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.data = None
        self.matches: list[int] = []

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)
        ttk.Label(top, text="Match #:").pack(side="left")

        # Digits-only validation, applied as the user types.
        vcmd = (self.register(self._validate_digits), "%P")
        self.match_var = tk.StringVar()
        self.match_entry = ttk.Entry(top, textvariable=self.match_var, width=10,
                                      validate="key", validatecommand=vcmd)
        self.match_entry.pack(side="left", padx=6)
        # Enter/Return submits, as does clicking away (focus-out).
        self.match_entry.bind("<Return>", lambda e: self._render())
        self.match_entry.bind("<FocusOut>", lambda e: self._render())

        ttk.Button(top, text="Go", command=self._render).pack(side="left")

        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=10, pady=10)

    @staticmethod
    def _validate_digits(proposed: str) -> bool:
        # Allow the field to be cleared, and allow digits only (no decimals,
        # no negatives - match numbers are positive integers).
        return proposed == "" or proposed.isdigit()

    def refresh(self, data):
        self.data = data
        with get_connection() as conn:
            rows = conn.execute(
                "SELECT match_num FROM match_schedule ORDER BY match_num"
            ).fetchall()
        self.matches = [r["match_num"] for r in rows]
        if self.matches and not self.match_var.get():
            self.match_var.set(str(self.matches[0]))
        self._render()

    def _render(self):
        for w in self.body.winfo_children():
            w.destroy()
        if not self.data:
            ttk.Label(self.body, text="No match schedule loaded yet. Use the Data menu to import a Match Schedule CSV.").pack()
            return

        raw = self.match_var.get().strip()
        if not raw:
            ttk.Label(self.body, text="Type a match number above and press Enter.").pack()
            return

        match_num = int(raw)
        with get_connection() as conn:
            m = conn.execute(
                "SELECT * FROM match_schedule WHERE match_num = ?", (match_num,)
            ).fetchone()
        if not m:
            ttk.Label(self.body, text=f"Match {match_num} not found.").pack()
            return

        red_teams = [m["red1"], m["red2"], m["red3"]]
        blue_teams = [m["blue1"], m["blue2"], m["blue3"]]

        odds = None
        odds_error = None
        try:
            missing = [t for t in red_teams + blue_teams
                       if t not in self.data.normalized_distributions]
            if missing:
                odds_error = f"Missing fitted distribution for team(s): {missing}"
            else:
                red_dist = build_alliance_distribution(
                    tuple(self.data.normalized_distributions[t] for t in red_teams)
                )
                blue_dist = build_alliance_distribution(
                    tuple(self.data.normalized_distributions[t] for t in blue_teams)
                )
                odds = compute_match_odds(red_dist, blue_dist)
        except Exception as exc:  # noqa: BLE001
            odds_error = str(exc)

        cols = ttk.Frame(self.body)
        cols.pack(fill="both", expand=True)

        def alliance_panel(parent, title, teams, actual_score, win_prob, expected_score):
            frame = ttk.LabelFrame(parent, text=title)
            tree = ttk.Treeview(frame, columns=("avg", "rrp"), show="tree headings", height=3)
            tree.heading("#0", text="Team")
            tree.heading("avg", text="Avg Score")
            tree.heading("rrp", text="Score RRP")
            tree.column("#0", width=80, anchor="center")
            tree.column("avg", width=110, anchor="center")
            tree.column("rrp", width=90, anchor="center")
            tree.pack(fill="x", padx=5, pady=5)
            for t in teams:
                sv = self.data.score_variance.get(t)
                avg = f"{sv.avg:.1f}" if sv else "—"
                rrp = f"{sv.rrp:.3f}" if sv else "—"
                tree.insert("", "end", text=str(t), values=(avg, rrp), iid=str(t))

            ttk.Label(frame, text=f"Actual recorded score: {actual_score:g}",
                      font=("TkDefaultFont", 10, "bold")).pack(anchor="w", padx=5)
            if win_prob is not None:
                ttk.Label(frame, text=f"Expected score: {expected_score:.0f}").pack(anchor="w", padx=5)
                ttk.Label(frame, text=f"Win probability: {win_prob*100:.1f}%",
                          font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=5, pady=(0, 5))
            return frame

        red_win = odds.alliance_a_win_probability if odds else None
        blue_win = odds.alliance_b_win_probability if odds else None
        red_expected = odds.expected_score_a if odds else 0.0
        blue_expected = odds.expected_score_b if odds else 0.0

        red_frame = alliance_panel(cols, "Red Alliance", red_teams,
                                    m["red_score"] or 0, red_win, red_expected)
        red_frame.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

        blue_frame = alliance_panel(cols, "Blue Alliance", blue_teams,
                                     m["blue_score"] or 0, blue_win, blue_expected)
        blue_frame.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)

        for c in range(2):
            cols.columnconfigure(c, weight=1)

        if odds_error:
            ttk.Label(self.body, text=f"Win odds unavailable: {odds_error}",
                      foreground="#a33").pack(anchor="w", padx=5, pady=(10, 0))

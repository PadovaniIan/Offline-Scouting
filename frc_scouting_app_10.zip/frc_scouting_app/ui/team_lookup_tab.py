"""
ui/team_lookup_tab.py

Recreates the "Team Lookup" sheet's purpose: pick a team, see everything
computed about them. Fields that depend on Stage 2/3 calculations (RPP,
ROP, RDP, weak-to-defense flag, super-scouting notes) are shown as
"pending" until those stages are implemented - see README.md.
"""

import tkinter as tk
from tkinter import ttk


class TeamLookupTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.data = None
        self.teams: list[int] = []

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)
        ttk.Label(top, text="Team:").pack(side="left")

        # Digits-only validation, applied as the user types.
        vcmd = (self.register(self._validate_digits), "%P")
        self.team_var = tk.StringVar()
        self.team_entry = ttk.Entry(top, textvariable=self.team_var, width=12,
                                     validate="key", validatecommand=vcmd)
        self.team_entry.pack(side="left", padx=6)
        # Enter/Return submits, as does clicking away (focus-out).
        self.team_entry.bind("<Return>", lambda e: self._render())
        self.team_entry.bind("<FocusOut>", lambda e: self._render())

        ttk.Button(top, text="Go", command=self._render).pack(side="left")

        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=10, pady=10)

    @staticmethod
    def _validate_digits(proposed: str) -> bool:
        # Allow the field to be cleared, and allow digits only (no decimals,
        # no negatives - team numbers are positive integers).
        return proposed == "" or proposed.isdigit()

    def refresh(self, data):
        self.data = data
        self.teams = [t.team_num for t in data.roster]
        if self.teams and not self.team_var.get():
            self.team_var.set(str(self.teams[0]))
        self._render()

    def _render(self):
        for w in self.body.winfo_children():
            w.destroy()
        if not self.data:
            ttk.Label(self.body, text="No data loaded yet. Use the Data menu to import CSVs.").pack()
            return

        raw = self.team_var.get().strip()
        if not raw:
            ttk.Label(self.body, text="Type a team number above and press Enter.").pack()
            return

        team = int(raw)
        if team not in self.teams:
            ttk.Label(self.body, text=f"Team {team} not found in the imported roster.").pack()
            return

        def stat_row(parent, label, value):
            row = ttk.Frame(parent)
            row.pack(fill="x", pady=1)
            ttk.Label(row, text=label, width=28).pack(side="left")
            ttk.Label(row, text=value, font=("TkDefaultFont", 10, "bold")).pack(side="left")

        header = ttk.Label(self.body, text=f"Team {team}",
                            font=("TkDefaultFont", 14, "bold"))
        header.pack(anchor="w", pady=(0, 10))

        cols = ttk.Frame(self.body)
        cols.pack(fill="both", expand=True)

        auto = ttk.LabelFrame(cols, text="Auto Balls Scored")
        auto.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        a = self.data.auto_balls_scored.get(team)
        if a:
            stat_row(auto, "Average", f"{a.avg:.2f}")
            stat_row(auto, "Std Dev", f"{a.stdev:.2f}")
            stat_row(auto, "RRP", f"{a.rrp:.3f}")
            stat_row(auto, "Matches", str(len(a.values)))

        teleop = ttk.LabelFrame(cols, text="Teleop Balls Scored")
        teleop.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)
        t = self.data.teleop_balls_scored.get(team)
        if t:
            stat_row(teleop, "Average", f"{t.avg:.2f}")
            stat_row(teleop, "Std Dev", f"{t.stdev:.2f}")
            stat_row(teleop, "RRP", f"{t.rrp:.3f}")
            stat_row(teleop, "Matches", str(len(t.values)))

        sv = ttk.LabelFrame(cols, text="Score Variance (raw scouted score - used everywhere in place of Adjusted Score Variance, see README)")
        sv.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
        s = self.data.score_variance.get(team)
        if s:
            stat_row(sv, "Average", f"{s.avg:.2f}")
            stat_row(sv, "Std Dev", f"{s.stdev:.2f}")
            stat_row(sv, "Skew", f"{s.skew:.3f}")
            stat_row(sv, "RRP", f"{s.rrp:.3f}")

        # NOTE: the "Adjusted Score Variance" panel that used to sit here
        # has been removed - see README.md "Experiment: Adjusted Score
        # Variance removed". The app now uses plain Score Variance
        # (shown above) everywhere Adjusted Score Variance used to be
        # used, so a separate panel showing the same numbers again would
        # just be redundant.

        sas = ttk.LabelFrame(cols, text="Skew Adjusted Spread")
        sas.grid(row=2, column=0, sticky="nsew", padx=5, pady=5)
        spread = self.data.skew_adjusted_spreads.get(team)
        if spread:
            method_names = {1: "Raw", 2: "SQRT", 3: "Log10", 4: "1/X"}
            stat_row(sas, "Chosen method", method_names.get(spread.chosen_method, "?"))
            stat_row(sas, "Average", f"{spread.matrix.avg:.4f}")
            stat_row(sas, "Std Dev", f"{spread.matrix.stdev:.4f}")
            stat_row(sas, "Skew (post-transform)", f"{spread.matrix.skew:.4f}")

        dist = ttk.LabelFrame(cols, text="Fitted Score Distribution")
        dist.grid(row=2, column=1, sticky="nsew", padx=5, pady=5)
        nd = self.data.normalized_distributions.get(team)
        if nd:
            method_names = {1: "Raw", 2: "SQRT", 3: "Log10", 4: "1/X"}
            stat_row(dist, "Most likely score (mode)", f"{nd.mode_x:.0f}")
            stat_row(dist, "Upper cutoff (95th pct.)", f"{nd.upper_cutoff:.1f}")

        defense_row = ttk.LabelFrame(cols, text="Defense")
        defense_row.grid(row=3, column=0, sticky="nsew", padx=5, pady=5)
        dc = self.data.defense_calculations.get(team)
        da = self.data.defense_adjustment.get(team)
        if dc:
            stat_row(defense_row, "Trend slope", f"{dc.slope:.3f}")
            stat_row(defense_row, "Defensive variance RRP", f"{dc.rrp:.3f}")
        if da:
            stat_row(defense_row, "Opponent-suppression RRP", f"{da.rrp:.3f}")

        compat = ttk.LabelFrame(cols, text="Average Compatability")
        compat.grid(row=3, column=1, sticky="nsew", padx=5, pady=5)
        ac = self.data.average_compatability.get(team)
        if ac:
            stat_row(compat, "Alliance-synergy ratio", f"{ac.ratio:.3f}")
            stat_row(compat, "RRP", f"{ac.rrp:.3f}")

        pending = ttk.LabelFrame(cols, text="Overall Power")
        pending.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
        rpp = self.data.rpp.get(team)
        if rpp:
            stat_row(pending, "RPP (overall power rank)", f"{rpp.rpp:.3f}")
            stat_row(pending, "ROP (offensive power)", f"{rpp.rop:.3f}")
            stat_row(pending, "RDP (defensive power)", f"{rpp.rdp:.3f}")
            stat_row(pending, "Weak to Defense?", "Yes" if rpp.defense_susceptible else "No")
            stat_row(pending, "Distance from ideal (1,1)", f"{rpp.distance:.3f}")

        for c in range(2):
            cols.columnconfigure(c, weight=1)

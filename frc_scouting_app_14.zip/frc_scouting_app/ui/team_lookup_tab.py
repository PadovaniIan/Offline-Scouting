"""
ui/team_lookup_tab.py

Recreates the "Team Lookup" sheet's purpose: pick a team, see everything
computed about them. Fields that depend on Stage 2/3 calculations (RPP,
ROP, RDP, weak-to-defense flag, super-scouting notes) are shown as
"pending" until those stages are implemented - see README.md.

Stage 10 added a "Score Trend" chart at the top of this tab, plotting
the selected team's Score Variance history (calculations.score_variance
.build_score_variance()'s per-team chronological, <=15-match value
list) as a line graph via matplotlib's Tkinter (TkAgg) backend. No
calculation code changed - this is a pure visualization of data the
pipeline already produces.

Stage 11 removed the "Score Variance", "Skew Adjusted Spread", and
"Defense" panels below the chart at the user's request, to fit the
tab on one screen without needing to scroll: Score Variance's numbers
are now shown by the Stage 10 chart instead, Skew Adjusted Spread
wasn't something users referenced, and Defense's info is covered by
the "Weak to Defense?" flag already in the Overall Power panel. The
underlying calculations are untouched - only these three panels'
Tkinter widgets were removed from _render().
"""

import tkinter as tk
from tkinter import ttk

from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


class TeamLookupTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.data = None
        self.teams: list[int] = []

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)
        ttk.Label(top, text="Team:").pack(side="left")

        # Digits-only validation, applied as the user types.
        vcmd = (self.register(self._validate_digits), "%P")
        self.team_var = tk.StringVar()
        self.team_entry = ttk.Entry(top, textvariable=self.team_var, width=12,
                                     validate="key", validatecommand=vcmd)
        self.team_entry.pack(side="left", padx=6)
        # Enter/Return submits, as does clicking away (focus-out).
        self.team_entry.bind("<Return>", lambda e: self._render())
        self.team_entry.bind("<FocusOut>", lambda e: self._render())

        ttk.Button(top, text="Go", command=self._render).pack(side="left")

        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=10, pady=10)

    @staticmethod
    def _validate_digits(proposed: str) -> bool:
        # Allow the field to be cleared, and allow digits only (no decimals,
        # no negatives - team numbers are positive integers).
        return proposed == "" or proposed.isdigit()

    def refresh(self, data):
        self.data = data
        self.teams = [t.team_num for t in data.roster]
        if self.teams and not self.team_var.get():
            self.team_var.set(str(self.teams[0]))
        self._render()

    def _render(self):
        for w in self.body.winfo_children():
            w.destroy()
        if not self.data:
            ttk.Label(self.body, text="No data loaded yet. Use the Data menu to import CSVs.").pack()
            return

        raw = self.team_var.get().strip()
        if not raw:
            ttk.Label(self.body, text="Type a team number above and press Enter.").pack()
            return

        team = int(raw)
        if team not in self.teams:
            ttk.Label(self.body, text=f"Team {team} not found in the imported roster.").pack()
            return

        def stat_row(parent, label, value):
            row = ttk.Frame(parent)
            row.pack(fill="x", pady=1)
            ttk.Label(row, text=label, width=28).pack(side="left")
            ttk.Label(row, text=value, font=("TkDefaultFont", 10, "bold")).pack(side="left")

        header = ttk.Label(self.body, text=f"Team {team}",
                            font=("TkDefaultFont", 14, "bold"))
        header.pack(anchor="w", pady=(0, 10))

        chart_frame = ttk.LabelFrame(self.body, text="Score Trend")
        chart_frame.pack(fill="x", pady=(0, 10))
        self._draw_score_chart(chart_frame, self.data.score_variance.get(team))

        cols = ttk.Frame(self.body)
        cols.pack(fill="both", expand=True)

        auto = ttk.LabelFrame(cols, text="Auto Balls Scored")
        auto.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        a = self.data.auto_balls_scored.get(team)
        if a:
            stat_row(auto, "Average", f"{a.avg:.2f}")
            stat_row(auto, "Std Dev", f"{a.stdev:.2f}")
            stat_row(auto, "RRP", f"{a.rrp:.3f}")
            stat_row(auto, "Matches", str(len(a.values)))

        teleop = ttk.LabelFrame(cols, text="Teleop Balls Scored")
        teleop.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)
        t = self.data.teleop_balls_scored.get(team)
        if t:
            stat_row(teleop, "Average", f"{t.avg:.2f}")
            stat_row(teleop, "Std Dev", f"{t.stdev:.2f}")
            stat_row(teleop, "RRP", f"{t.rrp:.3f}")
            stat_row(teleop, "Matches", str(len(t.values)))

        # NOTE (Stage 10): the "Score Variance" panel that used to sit
        # here was removed - its Average/Std Dev/Skew/RRP numbers are
        # now shown visually by the Score Trend chart above instead.
        # The "Skew Adjusted Spread" and "Defense" panels were also
        # removed at the user's request (Stage 11) - Skew Adjusted
        # Spread wasn't something users referenced, and Defense's
        # info is now covered by the "Weak to Defense?" flag already
        # in the Overall Power panel below. None of the underlying
        # calculations changed - this data is still fully computed by
        # the pipeline and available on self.data if a future stage
        # wants to surface it again.

        dist = ttk.LabelFrame(cols, text="Fitted Score Distribution")
        dist.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        nd = self.data.normalized_distributions.get(team)
        if nd:
            method_names = {1: "Raw", 2: "SQRT", 3: "Log10", 4: "1/X"}
            stat_row(dist, "Most likely score (mode)", f"{nd.mode_x:.0f}")
            stat_row(dist, "Upper cutoff (95th pct.)", f"{nd.upper_cutoff:.1f}")

        compat = ttk.LabelFrame(cols, text="Average Compatability")
        compat.grid(row=1, column=1, sticky="nsew", padx=5, pady=5)
        ac = self.data.average_compatability.get(team)
        if ac:
            stat_row(compat, "Alliance-synergy ratio", f"{ac.ratio:.3f}")
            stat_row(compat, "RRP", f"{ac.rrp:.3f}")

        pending = ttk.LabelFrame(cols, text="Overall Power")
        pending.grid(row=2, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
        rpp = self.data.rpp.get(team)
        if rpp:
            stat_row(pending, "RPP (overall power rank)", f"{rpp.rpp:.3f}")
            stat_row(pending, "ROP (offensive power)", f"{rpp.rop:.3f}")
            stat_row(pending, "RDP (defensive power)", f"{rpp.rdp:.3f}")
            stat_row(pending, "Weak to Defense?", "Yes" if rpp.defense_susceptible else "No")
            stat_row(pending, "Distance from ideal (1,1)", f"{rpp.distance:.3f}")

        for c in range(2):
            cols.columnconfigure(c, weight=1)

    def _draw_score_chart(self, parent, sv_row):
        """Line chart of this team's chronological scouted-score history.

        Draws from sv_row.values - the same <=15-entry, chronologically
        ordered list (capped exactly like the source sheet's Score
        Variance tab, see calculations/score_variance.py) that used to
        back a separate "Score Variance" stat panel before Stage 11
        removed it in favor of this chart. The x-axis is scouting
        order, not the real FRC match number - the source sheet itself
        lays a team's history across columns B:P by chronological
        appearance, with no real match number attached to each column,
        so this chart matches that same convention rather than
        inventing one.
        """
        values = list(sv_row.values) if sv_row and sv_row.values else []

        fig = Figure(figsize=(6.4, 2.6), dpi=100)
        ax = fig.add_subplot(111)

        if values:
            x = list(range(1, len(values) + 1))
            ax.plot(x, values, marker="o", color="#2563eb",
                    linewidth=1.8, markersize=5)
            ax.axhline(sv_row.avg, color="#94a3b8", linestyle="--",
                       linewidth=1, label=f"Avg {sv_row.avg:.1f}")
            ax.set_xticks(x)
            ax.set_xlabel("Scouted match order (chronological, up to 15)")
            ax.set_ylabel("Score")
            ax.legend(loc="best", fontsize=8, frameon=False)
            ax.grid(True, alpha=0.3)
        else:
            ax.text(0.5, 0.5, "No scouted score history for this team.",
                     ha="center", va="center", transform=ax.transAxes,
                     color="#64748b")
            ax.set_xticks([])
            ax.set_yticks([])

        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)

"""
calculations/distributions.py

Recreates the "Skew Distributions" and "Normalized Distributions" sheets -
the core of the algorithm described in the PDF ("Skewed Distribution
Algorithm for Practiced Task Performance Forecasting"). This is the
approximation method from that paper's "Skewed Distribution Derivation"
section, confirmed cell-for-cell against the exported formulas.

--------------------------------------------------------------------------
Skew Distributions sheet
--------------------------------------------------------------------------
For each team, and for each whole-number x from 1 to X_AXIS_MAX (the
sheet used 1..500 - the score range for the season; adjust X_AXIS_MAX
below if your game's scores run higher), the sheet evaluates a normal
PDF at a TRANSFORMED x, using that team's Skew Adjusted Spreads mean and
standard deviation (i.e. the mean/stdev of the already skew-corrected
data from Stage 1):

    y(x) = 0                                     if x > team's 95th
                                                   percentile raw score
         = NORMDIST(transform(x), mean_adj, stdev_adj, cumulative=False)
                                                   otherwise

Which transform(x) is applied mirrors calculations.transforms exactly,
using the SAME method (raw/sqrt/log10/1-over-x) chosen for that team in
Stage 1's Skew Adjusted Spreads, and branching on the sign of the team's
OWN (untransformed) skew - exactly as calculations.skew_methods does for
real data points, just applied to the x-axis grid instead.

mean_adj / stdev_adj = that team's Skew Adjusted Spreads AVG / STDEV
(already computed in Stage 1 - no new statistics needed here).

--------------------------------------------------------------------------
Normalized Distributions sheet
--------------------------------------------------------------------------
Takes the raw Skew Distributions curve and scales it so its peak is 1
(the paper's "scaled skew adjusted distribution"):

    ratio(x) = skew_curve(x) / max(skew_curve)

    y(x) = sqrt(ratio(x))   if this team's Adjusted Score Variance mean
                            is at or below the 27th percentile of every
                            team's Adjusted Score Variance mean (a
                            "weaker" team, whose curve gets broadened)
         = ratio(x)         otherwise
EXPERIMENT (see README.md "Experiment: Adjusted Score Variance
removed"): the source sheet builds these two from Adjusted Score
Variance. At the user's request, this app now feeds them from plain
Score Variance instead (see pipeline.py) - the functions below just
take whatever TeamMatrixRow dict is passed in as `score_variance`.
"""

from dataclasses import dataclass

from scipy.stats import norm

from calculations.matrix_stats import TeamMatrixRow
from calculations.transforms import transform_value

X_AXIS_MIN = 1
X_AXIS_MAX = 500  # matches the source sheet (1..500); raise this if your
                   # game's score range regularly exceeds 500 points.


def _percentile(values: list[float], p: float) -> float:
    """Matches Google Sheets PERCENTILE (linear interpolation), p in [0,1]."""
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    if n == 1:
        return s[0]
    rank = p * (n - 1)
    lo = int(rank)
    hi = min(lo + 1, n - 1)
    frac = rank - lo
    return s[lo] + (s[hi] - s[lo]) * frac


@dataclass
class TeamDistribution:
    team_num: int
    x_values: list[int]
    raw_curve: list[float]          # Skew Distributions y-values
    normalized_curve: list[float]   # Normalized Distributions y-values (peak=1)
    upper_cutoff: float             # 95th percentile raw score - hard cutoff
    mode_x: float                   # x-value where normalized_curve peaks


def build_skew_distributions(
    score_variance: dict[int, TeamMatrixRow],
    skew_adjusted_spreads: dict[int, "object"],  # skew_methods.SkewAdjustedSpreadRow
) -> dict[int, list[float]]:
    """
    Returns {team_num: [y(1), y(2), ..., y(X_AXIS_MAX)]} - the raw
    (un-scaled) Skew Distributions curve for every team.
    """
    x_axis = list(range(X_AXIS_MIN, X_AXIS_MAX + 1))
    curves: dict[int, list[float]] = {}

    for team, sv_row in score_variance.items():
        spread = skew_adjusted_spreads.get(team)
        if spread is None or sv_row.stdev == 0:
            curves[team] = [0.0] * len(x_axis)
            continue

        positive_skew = sv_row.skew > 0
        method = spread.chosen_method
        mean_adj = spread.matrix.avg
        stdev_adj = spread.matrix.stdev
        cutoff = _percentile(sv_row.values, 0.95)

        curve = []
        for x in x_axis:
            if x > cutoff:
                curve.append(0.0)
                continue
            tx = transform_value(float(x), method, positive_skew)
            if tx is None or stdev_adj == 0:
                curve.append(0.0)
                continue
            curve.append(float(norm.pdf(tx, loc=mean_adj, scale=stdev_adj)))
        curves[team] = curve

    return curves


def build_normalized_distributions(
    score_variance: dict[int, TeamMatrixRow],
    raw_curves: dict[int, list[float]],
) -> dict[int, TeamDistribution]:
    """
    Scales each team's raw Skew Distributions curve so its peak is 1,
    applying the sqrt-broadening adjustment for below-27th-percentile teams.
    """
    x_axis = list(range(X_AXIS_MIN, X_AXIS_MAX + 1))

    # PERCENTILE of every team's mean at 0.27 - a global, not per-team,
    # threshold.
    all_means = [row.avg for row in score_variance.values()]
    low_performer_threshold = _percentile(all_means, 0.27)

    out: dict[int, TeamDistribution] = {}
    for team, curve in raw_curves.items():
        sv_row = score_variance.get(team)
        peak = max(curve, default=0.0)
        is_weak_team = (sv_row is not None) and (sv_row.avg <= low_performer_threshold)

        if peak <= 0:
            normalized = [0.0] * len(curve)
        else:
            ratio = [v / peak for v in curve]
            normalized = [r ** 0.5 for r in ratio] if is_weak_team else ratio

        if normalized:
            peak_idx = max(range(len(normalized)), key=lambda i: normalized[i])
            mode_x = float(x_axis[peak_idx])
        else:
            mode_x = 0.0

        out[team] = TeamDistribution(
            team_num=team,
            x_values=x_axis,
            raw_curve=curve,
            normalized_curve=normalized,
            upper_cutoff=_percentile(sv_row.values, 0.95) if sv_row else 0.0,
            mode_x=mode_x,
        )

    return out

# FRC Scouting App (Offline) — Stages 1–3 Complete

A 100%-offline Python translation of the "Copy of Worlds Scouting Sheet"
Google Sheet (32 tabs, ~215k formula cells). Runs on Windows and Mac.
No internet access, no external API, no cloud database — everything is a
local SQLite file (`data/scouting.db`) plus files you import from disk.

## Why "Stage 1"

The spreadsheet's 32 tabs form a long dependency chain, and several of
them (Skew Distributions: 88,082 cells; Normalized Distributions: 38,300
cells; the Alliance Generators; Match Odds) implement the bespoke
skew-normal curve-fitting algorithm described in your PDF — genuinely
novel statistical logic, not boilerplate spreadsheet math. Rather than
guess at 200k+ formula cells in one pass and risk silently getting the
core algorithm wrong, this is being built and verified sheet-by-sheet
against the real exported formulas, in stages:

**Stage 1 — done, in this delivery.** The full raw-data pipeline:
- `Team Numbers`, `BPS`
- `Unfiltered Raw Data` → `Raw Data`
- `Auto Balls Scored`, `Teleop Balls Scored`
- `Score Variance` → `Raw Data Processing` → Match Schedule "Adjusted"
  columns → `Adjusted Score Variance`
- `SQRT Method`, `Log10 Method`, `1/X Method` → `Skew Adjusted Spreads`
  (the per-team, skew-normalized score distribution that Stage 2 will
  turn into an actual probability curve)

This is 10 of the 32 sheets — the foundational data layer every other
sheet reads from. It's fully wired into a working 4-tab GUI right now.

**Stage 2 — done, in this delivery.**
- `Skew Distributions` + `Normalized Distributions`: the actual skew-normal
  curve-fitting approximation from your algorithm PDF ("Skewed
  Distribution Derivation" section) — evaluates a normal PDF at a
  transformed x-axis using each team's Skew Adjusted Spreads mean/stdev,
  applies the 95th-percentile hard cutoff, then peak-scales the curve
  (with the sqrt-broadening adjustment for teams whose average sits at or
  below the 27th percentile league-wide). This produces each team's fitted
  score-probability curve and its mode (most likely score).
- `Defense Calculations`: trend-line (SLOPE) detrending of each team's
  first 12 chronological matches to surface defensive-variance signal.
- `Defense Adjustment`: per-match opponent-alliance underperformance,
  reused directly from Stage 1's Raw Data Processing output.
- `Average Compatability`: per-match own-alliance performance ratio,
  same reuse.

That's 14 of the 32 sheets after Stage 2. Team Lookup shows the new
stats (fitted distribution mode, defense metrics, compatibility) live.

**Stage 3 — done, in this delivery.**
- `ROP`, `RDP`, `RPP`: the final per-team power-ranking composites, built
  from every earlier stage's RRP columns plus a couple of sheet-specific
  weighted-average and normalization quirks (e.g. RDP dropping the first
  chronological match, RPP's `SQRT((1-ROP)^2+(1-RDP)^2)` "distance from
  ideal" metric).
- `Team Ability Distribution`: league-wide RPP benchmarks (top-4, top-8,
  elims-window, and the "Goal Ally RPP" bar) used as the Pick List's
  quality threshold.
- `Alliance Builder Filtering`: the real Pick List logic — teams that
  clear the Goal Ally RPP bar are ranked by score-consistency ratio;
  everyone else is a fallback list ranked by ROP.
- `Alliance Base Generator` + `Blue/Red Alliance Generator` + `Match
  Odds`: combines three teammates' Stage 2 curves into an alliance-level
  score distribution (splitting each curve at its own mode into a rising
  and falling branch, then pairing up branches rank-position by
  rank-position across teammates — see
  `calculations/alliance_generator.py`'s docstring for the full
  mechanics), then computes win probability and expected score via a
  discretized cumulative-sum comparison between the two alliances'
  combined curves.

All 32 sheets are now implemented. Match Lookup, Team Lookup, Pick List,
and Rankings are all wired to real computed data — no more interim
placeholders anywhere in the app. The pipeline (including Alliance
Generator → Match Odds) was run end-to-end against synthetic data with
no errors and sane output (win probabilities summing to 1, expected
scores in range).

### Important: the one piece that needs your validation
The Alliance Generator → Match Odds chain (the last bullet above) was the
single most intricate part of the entire workbook — internally, the
source sheet cross-labels "Blue Alliance Generator" as actually being
built from the *Red* alliance's combined curve (framed as "the score Blue
needs to clear"), and vice versa. I could not confirm that cross-labeling
with full certainty from static formula analysis alone, so **this port
builds each alliance's combined distribution directly from its own three
teammates** instead — mathematically equivalent for computing a win
probability, and unambiguous to read. Please spot-check a real match's
win% here against what your Google Sheet shows for the same match. If the
numbers land in noticeably different places, that cross-labeling is the
first thing to double check — I'm glad to adjust it if the sheet's
literal (opponent-referenced) framing turns out to matter to the result.

Two smaller documented assumptions, both easy to override:
- `ELIM_ALLIANCE_TEAMS` in `calculations/team_ability.py` (default 24,
  i.e. 8 alliances × 3) — the sheet switches between 24 and 32 based on a
  per-event setting I didn't have a live value for.
- Exact-match score lookup in `alliance_generator.py` when building the
  empirical frequency curve — matches the sheet's `VLOOKUP` exact-match
  behavior, so scores with no exact combined sample stay at density 0
  rather than being smoothed/interpolated.

### What's left
Every sheet now has a Python home. What's still worth polishing:
- A results/history view so Match Odds predictions can be checked against
  actual outcomes over a season (great next step once you've validated
  the win-probability numbers above).
- Nicer visualizations — e.g. plotting a team's fitted score curve, or an
  alliance's combined distribution, right in the Team Lookup / Match
  Lookup tabs (the underlying data — `normalized_distributions`,
  `AllianceDistribution.empirical_curve` — is already there to plot).
- The `Super Scouting`-dependent Team Lookup fields, if that sheet ever
  resurfaces (currently intentionally skipped per your instruction).

### Note on the X_AXIS_MAX constant
`calculations/distributions.py` builds each **individual robot's** score
curve over whole numbers 1–500, matching the source sheet exactly. Your
real season data shows individual-robot 95th-percentile cutoffs as high as
~589, so if you find Team Lookup curves look clipped for your highest-
scoring teams, raise `X_AXIS_MAX` at the top of that file. The
**alliance-level** (3-robot combined) curve used by Match Lookup no longer
shares this constant — see Stage 7 below — so raising `X_AXIS_MAX` only
affects the single-robot curves, not the alliance combination.

Each stage was delivered the same way: real formulas from your
`FORMULA_EXPORT` tab mapped 1:1 to Python, then sanity-checked against
sample values before being called "done."

### A data note: the missing "Super Scouting" sheet
Several formulas in `Team Lookup` (Team Name, weak-to-defense notes,
climb-confidence flags) reference a sheet called `Super Scouting` that
does **not** exist anywhere in your export — 32 sheets were exported and
`Super Scouting` isn't one of them. Either it was deleted from this copy
of the workbook, or it lives in a different spreadsheet. Those specific
fields can't be reconstructed without it. If you have that sheet
somewhere, send it over (via the same Apps Script export method) and I'll
wire those fields in.

## Project layout

```
frc_scouting_app/
├── main.py                        # entry point — run this
├── database.py                    # SQLite schema (local file, no server)
├── data_import.py                 # CSV importers for the 3 input tables
├── requirements.txt
├── calculations/
│   ├── team_roster.py             # "Team Numbers" sheet
│   ├── raw_processing.py          # "BPS", "Unfiltered Raw Data", "Raw Data"
│   ├── matrix_stats.py            # shared Min/Max/STDEV/AVG/RRP/Skew helper
│   ├── balls_scored.py            # "Auto/Teleop Balls Scored"
│   ├── score_variance.py          # "Score Variance", "Raw Data Processing",
│   │                               #   Match Schedule "Adjusted" cols,
│   │                               #   "Adjusted Score Variance"
│   ├── skew_methods.py            # "SQRT/Log10/1÷X Method",
│   │                               #   "Skew Adjusted Spreads"
│   ├── transforms.py              # shared skew-transform math (Stage 1 & 2)
│   ├── distributions.py           # "Skew Distributions",
│   │                               #   "Normalized Distributions"
│   ├── defense.py                 # "Defense Calculations",
│   │                               #   "Defense Adjustment",
│   │                               #   "Average Compatability"
│   ├── power_rankings.py          # "ROP", "RDP", "RPP"
│   ├── team_ability.py            # "Team Ability Distribution"
│   ├── pick_list.py               # "Alliance Builder Filtering"
│   ├── alliance_generator.py      # "Alliance Base Generator",
│   │                               #   "Blue/Red Alliance Generator"
│   ├── match_odds.py              # "Match Odds"
│   └── pipeline.py                # runs everything in dependency order
├── ui/
│   ├── app.py                     # main window, menu, notebook of 4 tabs
│   ├── match_lookup_tab.py        # tab 1: Match Lookup (live win odds)
│   ├── team_lookup_tab.py         # tab 2: Team Lookup
│   ├── pick_list_tab.py           # tab 3: Pick List (real ranking logic)
│   └── rankings_tab.py            # tab 4: Rankings (real RPP/ROP/RDP)
└── data/
    └── scouting.db                # created automatically on first run
```

## Setup (Windows and Mac)

1. Install **Python 3.11+** from [python.org](https://www.python.org/downloads/)
   (on Mac, use the official installer, not a Homebrew build that was
   compiled without Tk — the installer from python.org always bundles Tk).
2. Open a terminal in the `frc_scouting_app` folder and run:
   ```
   pip install -r requirements.txt
   python main.py
   ```
   (On Mac you may need `python3` / `pip3` instead of `python` / `pip`.)
3. The app opens with four tabs: **Match Lookup, Team Lookup, Pick List,
   Rankings**. Use the **Data** menu to import your two CSVs (Match
   Schedule, then Raw Data — column formats are documented in the
   "Getting data into the app" section below and at the top of
   `data_import.py`), then click **Recalculate Now** (importing does
   this automatically too).
4. Use **Data → Set My Team Number...** so the Pick List tab excludes
   your own team from its rankings.

Everything after that point runs from the local `data/scouting.db` file.
Closing your laptop's Wi-Fi doesn't change anything — there is no code
path anywhere in this app that opens a network socket.

## Getting data into the app

The app has exactly two CSV imports, and both together are all it needs:

**Data → Import Match Schedule CSV...** (do this first) then
**Data → Import Raw Data CSV (Team + Score Breakdown)...**

### Import Match Schedule CSV

7 required columns + 2 optional trailing columns:

| Column | Notes |
|---|---|
| Match Number | required. The header may be blank — some spreadsheet exports leave that corner cell empty, and a blank header is still recognized as the match number column |
| Red 1 / Red 2 / Red 3 | required — the three red-alliance team numbers |
| Blue 1 / Blue 2 / Blue 3 | required — the three blue-alliance team numbers |
| Red Score / Blue Score | optional — the official recorded final alliance scores |

Header matching is case/space/underscore-insensitive, so "Red 1", "red1",
"RedTeam1" all work. If no header row is recognized at all, the importer
falls back to strict column order (match #, red1-3, blue1-3, then
optionally red_score, blue_score).

Re-importing only ever updates the columns actually present in that CSV
— it never blanks out data another import already filled in (e.g.
team-slot assignments written automatically by the Raw Data import,
below, are preserved if you later import scores-only, and vice versa).

**Match Schedule is always the authoritative source of alliance/slot
assignment** — see "Why Match Schedule always wins" below for why this
matters.

### Import Raw Data CSV (Team + Score Breakdown)

One row per scouted robot per match: team number, match number, alliance
slot, the auto/teleop/climb score breakdown, a total score, and an
optional note. Header names are matched case/space/underscore-
insensitively, and either a single header row or a two-row "grouped"
header (some exports split e.g. "Auto" / "SHOOTING" across two rows) is
auto-detected:

| Column | Notes |
|---|---|
| Team Number | required |
| Match Number | required |
| Alliance / Position | optional — `R1`/`B2`/`red3`/bare `Blue` are all accepted (a bare color with no slot number is auto-numbered 1st/2nd/3rd in order of appearance for that match). **This is only ever used as a fallback.** The importer first checks whether Match Schedule already knows this team+match's slot; only if it doesn't does it fall back to this cell. See "Why Match Schedule always wins" below |
| Auto Shooting | Auto balls scored |
| Auto Climb / Auto L1 | Auto climb bonus points |
| Teleop Shooting | Teleop balls scored |
| Teleop L1 / L2 / L3 | Teleop climb level bonus |
| Score | optional — if blank, it's derived from the breakdown columns (summing the auto/teleop fields, defaulting to 2 if that sum is 0, exactly like the source sheet's own quirk) |
| Notes | optional |

Blank/placeholder rows (missing a team or match number — some exports
include empty template rows) are silently skipped and counted. Rows
whose alliance can't be determined either from the CSV or from a
Match Schedule lookup are also skipped, and reported back to you by
name (match/team) after the import finishes, rather than guessed at.

This import also upserts each robot's team number into the right
`match_schedule` slot when (and only when) Match Schedule didn't already
have that team+match — it never touches the score columns, so it can't
clobber official scores imported separately.

### Why Match Schedule always wins

**This fixed a real correctness bug** found while cross-checking the
app's Adjusted Score Variance output against the original Google
Sheet's cached values (see
`calculations/score_variance.py::build_raw_data_processing` for the
full writeup). The importer used to trust each Raw Data row's own
Alliance/Position cell *before* checking Match Schedule, and would
unconditionally upsert that value into `match_schedule`. In practice,
a real-world Raw Data export's Position column often does **not**
reliably match the official schedule slot (it looks like scouts
sometimes record it as "the Nth robot I personally scouted" rather
than the true red/slot number). Trusting it over an already-correct
Match Schedule import silently corrupted the team roster for that
match — e.g. a real case from testing had the true schedule
(Red: 10935, 88, 3044 / Blue: 1540, 2783, 6436) get scrambled into
(Red: 88, 6436, 2783 / Blue: 3354, 10935, 2783) purely because of
Raw Data rows whose own Position cell disagreed with the schedule.
Since every alliance-grouped calculation (Raw Data Processing's
alliance ratios, the Adjusted Score apportionment, and everything
built on top of it — ROP/RDP/RPP, Match Odds) reads alliance
membership straight from `match_schedule`, this single import bug
was enough to make Adjusted Score Variance diverge from the sheet
across the board, even though the underlying per-robot Raw Data /
Score Variance numbers stayed correct (this is a faithful match of
the original spreadsheet's own design too — its "Raw Data" sheet
has *no* alliance/position column at all; alliance membership there
comes solely from Match Schedule's manually-entered team columns).

The fix: `import_raw_data_csv` now always tries a Match Schedule
lookup for a row's team+match first, and only falls back to that
row's own Position cell if the lookup fails. It also detects (and
reports, without acting on) rows whose Position guess conflicts with
a team already on record for that slot — a sign of a mis-typed team
or match number in the Raw Data CSV — instead of silently
overwriting known-good data. If you see a "schedule_conflicts"
message after an import, those specific rows are worth checking by
hand.

### A second, subtler bug: the occurrence-indexed lookup

The sheet's Raw Data Processing sheet doesn't look up "this team's raw
score for this match" directly — it counts how many times a team has
appeared anywhere in Match Schedule up through the current match row
(a running `COUNTIF`), and uses *that count* as a positional index (via
`XLOOKUP`) into the team's Score Variance history (which is just that
team's own raw scores, in chronological order, capped at the sheet's
15 match columns). Ordinarily this gives the same answer as a direct
(team, match) lookup — but if a team has a match on the official
schedule that was never actually scouted (no Raw Data row for it),
every later occurrence index for that team silently shifts by one, and
the sheet ends up attributing a *different* match's score to the
current one. This is a real, reproducible quirk of the original
spreadsheet's formula design (confirmed against its cached values),
not a translation mistake — so it's now replicated exactly rather than
"corrected" to a simpler direct lookup, since the goal is to match the
sheet's actual behavior. See `build_raw_data_processing`'s docstring
for the mechanics.

One known, deliberate exception: rows 23–25 of the original sheet's
Match Schedule (matches 22–24) contain an isolated copy-paste error —
their Adjusted-column formulas reference the *next* match's official
score instead of their own (confirmed by tracing the formula text).
This app does not replicate that specific 3-row artifact, since it's
clearly an unintentional mistake in the source spreadsheet rather than
part of the intended algorithm; if you spot-check those three matches
against the live sheet, expect the app's numbers to be the more
correct ones.

### A third bug, and a lesson from it: evidence-based typo correction

Real Match Schedule exports can themselves contain typos (a manually
typed team number missing a digit, e.g. "325" instead of "3256").
When that happens, the previous fix above ("Match Schedule always
wins") would faithfully preserve the *typo* forever, since nothing
would ever be allowed to correct it — and the wrongly-orphaned real
team (the typo'd number) would show up in Team Lookup with no
scouting data at all, while the real, well-scouted team would never
get credited for that match.

`import_raw_data_csv` now also checks, for every conflict it detects,
whether the team currently on record for that slot is a total
"orphan" — appearing in Match Schedule exactly this once, with zero
corroborating scouting data anywhere (including elsewhere in the same
Raw Data CSV) — while the row's own team is well-established (several
other matches' worth of real data in the same file). Only in that
narrow, lopsided case is the schedule slot corrected automatically
(and always reported as a `likely_typo_corrections` entry so it can be
double-checked); every more ambiguous conflict (both teams well-
established elsewhere — the far more common shape of this problem) is
still just reported, never guessed at.

**A note on validating this against `FORMULA_EXPORT`**: if you're
diffing the app's output against the cached values in
`Copy_of_Worlds_Scouting_Sheet_-_FORMULA_EXPORT.csv`, be aware that
cache was generated from the *same, not-yet-corrected* source data —
so it will still reflect any typo the app now fixes on import (e.g.
it has "325" baked into its own cached Adjusted Score Variance values
for every team affected by that match). That's expected and is not a
sign the app's fix is wrong; it just means the ground-truth cache and
the corrected app diverge for that one data point until the source
spreadsheet itself is corrected and re-exported.

### Why the "Adjusted Score" fallback matters

`build_raw_data_processing` (still used for Defense Adjustment/Average
Compatability/RDP - see the Experiment section below) apportions each
robot's raw score against its alliance's *official* recorded match
score (`match_schedule.red_score`/`blue_score`). For any match still
missing that (no Match Schedule import yet, or that match wasn't in
it), this app falls back to using each robot's raw scouted score as-is
(apportionment ratio of 1.0) rather than collapsing to zero. The
moment a real score is present for a match, the exact original
apportioned formula takes over for it automatically. This is a
deliberate deviation from the literal sheet behavior (the sheet's
Match Schedule was always fully populated) — see
`calculations/score_variance.py::build_raw_data_processing`.

### Experiment: Adjusted Score Variance removed

At the user's request, this app currently does **not** compute or use
"Adjusted Score Variance" anywhere — plain Score Variance is used in
its place, everywhere: Skew Adjusted Spreads, Skew/Normalized
Distributions, and ROP all now take Score Variance directly (see
`calculations/pipeline.py`). This was requested as a deliberate
experiment: real scouting data is human-entered and will always have
holes in it (missed matches, typos), which is exactly what Adjusted
Score Variance's occurrence-indexed lookup (see the "second, subtler
bug" section above) is most sensitive to. Score Variance itself is
simpler, has been independently verified against the source
spreadsheet's cached values, and — per the user's own testing on the
live Google Sheet — Adjusted Score Variance was only ever a minor
adjustment on top of it. The hope is that removing it entirely
produces more reliable results on real, imperfect data than a
"more accurate in theory, more fragile in practice" calculation would.

What's unaffected: `build_raw_data_processing` (Raw Data Processing /
the Match Schedule "Adjusted" columns) still runs, because its
`own_alliance_ratio`/`opponent_alliance_ratio` outputs are a different
calculation, used by Defense Adjustment, Average Compatability, and
RDP - none of that is "Adjusted Score Variance" and none of it changed.
`score_variance.build_adjusted_score_variance()` itself hasn't been
deleted, either - it's simply unused now. It still returns a
same-shaped `TeamMatrixRow` dict, so reverting this experiment is a
small, localized change if the results don't hold up:

1. In `calculations/pipeline.py`, add back
   `asv = score_variance.build_adjusted_score_variance(rdp_rows_raw)`
   and pass `asv` (instead of `sv`) into
   `skew_methods.build_transform_methods`,
   `skew_methods.build_skew_adjusted_spreads`,
   `distributions.build_skew_distributions`,
   `distributions.build_normalized_distributions`, and
   `power_rankings.build_rop`.
2. Add `adjusted_score_variance: dict` back to `ComputedData` and its
   constructor call.
3. In `ui/team_lookup_tab.py` and `ui/match_lookup_tab.py`, point the
   removed/renamed panels back at `self.data.adjusted_score_variance`.

### What happened to Raw Scouting CSV and BPS Samples CSV

Earlier versions of this app also supported a more granular import path
— an "Unfiltered Raw Data"-style CSV of raw in-match actions (shooting
*time*, shuttle/floor/climb flags, died/beached), combined with a BPS
(balls-per-second) calibration CSV, that the app would convert into Raw
Data itself. That's a different scouting methodology (stopwatch-timed
actions instead of directly recording ball counts), and since it's not
how this project scouts, both imports have been removed from the UI to
keep the Data menu to the two imports above. The underlying calculation
code (`calculations/raw_processing.py::team_bps_averages`,
`_augment_unfiltered_rows`, `build_raw_data`) and the `raw_scouting` /
`bps_samples` tables are still in the codebase, documented as legacy/
unused, in case that workflow is ever needed again — but nothing writes
to them anymore, and `calculations/pipeline.py` always builds Raw Data
from the manual import above.

### Stage 7 — Two real bugs fixed in Match Lookup's expected score

Symptom reported: Match Lookup's expected score was coming out far below
real match scores, as if the alliance combination was only picking up
one of the three teammates' scores most of the time. Investigation (in
`calculations/alliance_generator.py`, cross-checked against
`FORMULA_EXPORT`'s `Alliance Base Generator` / `Blue Alliance Generator`
/ `Match Odds` sheets) found two distinct, real bugs stacked on top of
each other:

**Bug 1 — the ascending branch was combined in the wrong point order.**
Each teammate's normalized curve is split at its own mode into an
ascending branch (before the peak) and a descending branch (at/after the
peak), then the three teammates' branches are combined rank-by-rank
(1st ascending point + 1st ascending point + 1st ascending point, etc).
The sheet's own formulas (`Alliance Base Generator`'s "Lower" columns,
via a `SORT(..., SEQUENCE(n), FALSE())` trick) order the ascending
branch starting right next to each team's own mode and moving *outward*
toward its minimum score — not left-to-right as an earlier version of
this port assumed. With the wrong (left-to-right) order, a teammate with
a narrower ascending branch got zero-padded starting immediately next to
its own mode — exactly its most heavily-weighted region — silently
dropping that teammate's real contribution from most of the alliance's
higher-density combined samples. Fixed by reversing the ascending
branch's point order to match the sheet.

**Bug 2 — the alliance-level combined curve was capped at the same 500-point
axis used for a single robot.** A 3-robot combined score can run up to
3x a single robot's max, and in your real data it very often does —
`Alliance Base Generator`'s own cached combined-sample values in
`FORMULA_EXPORT` run as high as ~1079 with a median around ~670, and your
actual recorded alliance scores range up to 819 with a median of 439.
Since both this port and the **original Google Sheet** built the
combined-alliance empirical curve over the same 1–500 axis as a single
robot's score, the majority of an alliance's real combined-score
probability mass had nowhere to land and was being silently dropped —
in the live sheet too, confirmed directly from its own cached values, not
just this port. Fixed by giving the alliance-level curve its own axis,
`ALLIANCE_X_AXIS_MAX = 3 * X_AXIS_MAX`, sized to the true maximum a
3-robot combination can reach; single-robot curves (Team Lookup,
Skew/Normalized Distributions) are unaffected.

Bug 2 was the larger contributor for any match whose real combined score
already exceeded 500 — fixing Bug 1 alone barely moved those matches'
expected scores, since most of the probability mass was still being cut
off by the axis cap regardless of how correctly the samples were combined.

**Validated against all 110 matches in your real Match Schedule with a
recorded official score** (`Untitled_spreadsheet_-_Match_Schedule.csv`):
mean absolute error between expected and actual alliance score dropped
from ~175 points to ~100 points, and win-direction accuracy (does the
predicted favorite match the actual winner) rose from 67% to 69%. An
average error around 100 points on scores that swing from under 200 to
over 800 is a plausible result for a single-number forecast built from
noisy, human-scouted data — not perfect, but no longer "massively" off,
and the predicted favorite now agrees with reality roughly 7 times out of
10. This is a good candidate for the still-outstanding Section 6.5-style
validation: pick a real match, compare this app's Match Lookup number
against what your live Google Sheet shows for the same match, and see
whether the sheet suffers the same axis-truncation issue (it should,
since it uses the identical 1–500 axis) or whether something elsewhere in
the sheet compensates for it that this analysis missed.

## Stage 9 — Bug fix: importing a new competition's CSVs was mixing with the old competition's data

**Symptom reported by the user:** after loading one competition's Match
Schedule + Raw Data CSVs, importing a *different* competition's CSVs did
not replace the first competition's data — it mixed with it.

**Root cause:** `ui/app.py`'s `_import()` always called both importers
in merge/upsert mode (`replace_existing=False`), even though both
`data_import.import_match_schedule_csv()` and
`data_import.import_raw_data_csv()` already supported a
`replace_existing` flag — it was simply never wired up to the UI. Two
distinct effects followed from this:

- `match_schedule` has `match_num` as its primary key, so re-importing
  it in merge mode *upserts* by match number rather than duplicating —
  this is actually the desired, documented behavior for updating the
  *same* competition (e.g. importing scores after the matches finish).
  But if a second competition reuses match numbers 1, 2, 3... (which
  every event does), its rows silently overwrote the first competition's
  matches one-for-one rather than being kept separate or clearing the
  slate — the two competitions' schedules ended up interleaved by match
  number with no way to tell which match belonged to which event.
- `manual_raw_data` has **no** natural key at all (a plain
  auto-incrementing `id`), so merge-mode import doesn't upsert there —
  it just appends. Every raw-data import, even re-importing the exact
  same file, added a second full set of rows on top of the first,
  silently doubling (and, on subsequent competitions, further
  compounding) every downstream chronological/statistical calculation
  that reads from `manual_raw_data` (Score Variance, Balls Scored,
  Raw Data Processing, and everything built on top of them).

**Fix:** `ui/app.py` now shows an explicit `ImportModeDialog` before
every CSV import, asking whether this file is more data for the
competition already loaded, or the start of a different competition:

- **"Update current competition"** — unchanged from the original
  behavior: both importers run in their existing upsert/merge mode
  (`replace_existing=False`). This is what you want for adding official
  scores to a schedule you already imported, or re-importing a raw-data
  CSV that has new/corrected rows for the same event.
- **"New competition"** — calls the new
  `database.clear_active_competition_data()`, which deletes every row
  from **both** `match_schedule` and `manual_raw_data` (not just the
  table the CSV you're about to import populates), then imports with
  `replace_existing=True`. Both tables are wiped together, regardless of
  which of the two CSVs you import first for the new event, so there's
  no window where an old competition's schedule can mix with a new
  competition's raw data or vice versa. A "Cancel" button on the dialog
  backs out of the import entirely with no changes made.

The import-complete dialog now also says "Cleared previous
competition's data." at the top of its message whenever replace mode
ran, so it's obvious after the fact which mode was used.

**What did NOT change:** `raw_scouting`, `bps_samples`, and
`team_roster` are untouched by `clear_active_competition_data()` — the
first two are legacy/unused tables (Section "Getting data into the
app" above), and `team_roster` is not competition-specific. Neither of
the two importer functions' own internal logic changed at all — Stage 9
only wires the UI up to the `replace_existing` parameter both already
supported, plus the new wholesale two-table wipe for the "New
competition" case specifically (mirroring the two importers' own
per-table `replace_existing=True` behavior, but covering both tables
together instead of leaving it to import order).

**Validation:** re-ran the real Match Schedule + Raw Data CSVs through
`import_match_schedule_csv()`/`import_raw_data_csv()` twice in a row,
headless, to reproduce and then confirm the fix:
- Old behavior (merge mode both times): `manual_raw_data` went from 625
  rows to 1250 rows on the second import — the bug, reproduced exactly.
- New behavior (`clear_active_competition_data()` + `replace_existing=True`
  on the second import): `manual_raw_data` stayed at 625 rows, `match_schedule`
  stayed at 110 rows, and `calculations.pipeline.build_all()` still
  produced the expected 75-team roster with 625 raw-data rows — matching
  the original single-import baseline exactly, with no duplication and
  no leftover rows from the "old" load.

## Stage 10 — Team Lookup: Score Trend chart

At the user's request, the Team Lookup tab now shows a line chart of the
selected team's scouted-score history right under the team header,
above the existing stat panels. It plots exactly the same data the
"Score Variance" panel's Average/Std Dev/Skew/RRP figures are computed
from (`calculations/score_variance.py::build_score_variance()`'s
per-team chronological list, capped at 15 matches like the source
sheet's Score Variance tab), with a dashed line marking that team's
average. The x-axis is scouting order (1st, 2nd, 3rd... scouted match),
not the real FRC match number, since that per-team value list has no
match number attached to each entry — same convention the source
sheet's own B:P columns use.

Implementation: `matplotlib`'s Tkinter (`TkAgg`) backend, embedded
directly via `FigureCanvasTkAgg` inside `ui/team_lookup_tab.py`'s
existing `_render()` flow — a new figure is built and packed into the
tab's body each time a team is looked up, and the whole body (including
the chart) is destroyed and rebuilt on every `_render()` call exactly
like the rest of the tab already worked, so there's no separate
lifecycle/cleanup logic needed. `matplotlib>=3.8` was added to
requirements.txt; it's BSD-licensed and makes no network calls — the
`TkAgg` backend just draws into the already-open tkinter window.

No calculation code changed anywhere — this is a pure visualization of
data the pipeline already produces. Verified headlessly (Agg backend)
against the user's real Score Variance data (team 1796: 8 scouted
matches, values from 50.5 to 304.99, average ≈237.2) — chart built and
saved to a PNG with no errors, and the empty-history case (a team with
no `score_variance` row) was confirmed to render a "No scouted score
history for this team." placeholder instead of crashing.

## Stage 11 — Team Lookup: trimmed down to fit without scrolling

After Stage 10's chart was added, the user reported the Team Lookup tab
no longer fit on screen and there was no way to scroll to see the rest
of it. Rather than add scrolling right away, the user asked to first
see if trimming the tab's content down was enough on its own. Three
panels were removed from below the chart, all in `ui/team_lookup_tab.py`
only:

- **Score Variance** — redundant now that the Stage 10 chart shows the
  same underlying data (and its average) visually.
- **Skew Adjusted Spread** — the user said this wasn't something they
  actually referenced.
- **Defense** — its "Opponent-suppression RRP" was arguably useful, but
  the tab's Overall Power panel already surfaces the practical
  takeaway from it (the "Weak to Defense?" flag, which is `rpp.rdp`
  derived), so the separate panel was dropped as redundant too.

The remaining grid was reflowed from 5 rows down to 3 (Auto Balls
Scored / Teleop Balls Scored, then Fitted Score Distribution / Average
Compatability, then Overall Power spanning both columns), rather than
leaving gaps where the removed panels used to sit.

**What did NOT change:** none of the underlying calculations were
touched — `calculations/score_variance.py::build_score_variance()`,
`skew_methods.py::build_skew_adjusted_spreads()`, and
`defense.py::build_defense_calculations()`/`build_defense_adjustment()`
all still run every pipeline build exactly as before; their outputs are
just no longer rendered in these three specific panels. If a future
session wants any of them back, `self.data.score_variance`,
`self.data.skew_adjusted_spreads`, `self.data.defense_calculations`,
and `self.data.defense_adjustment` are all still populated and ready to
use — see the git history / earlier zip for the exact panel code that
was removed if you want to restore it verbatim instead of rewriting it.

Whether removing these three panels was enough to avoid needing a
scroll feature depends on the user's actual screen/window size, which
can't be confirmed in this build environment (no display) — this is
the next thing to check once the app is run for real.

## Stage 12 — Match Lookup: Score Distribution chart

At the user's request, the Match Lookup tab now shows a chart below the
red/blue alliance panels overlaying both alliances' combined-score
curves on one plot, so it's visually obvious how much (or how little)
their likely-score ranges overlap.

**Data source:** each alliance's `AllianceDistribution.empirical_curve`
from `calculations/alliance_generator.py::build_alliance_distribution()`
— the exact same curve `calculations/match_odds.py::compute_match_odds()`
already computes win probability from. No new calculation was added;
this chart draws from data the pipeline was already producing for the
existing win-odds numbers.

**Why the chart is smoothed for display:** `empirical_curve` is built
via an exact-match lookup onto a 1500-point integer axis (matching the
source sheet's own VLOOKUP behavior — see `alliance_generator.py`'s
module docstring), so the vast majority of integer scores have no exact
combined sample and sit at exactly 0 immediately next to points near
1.0. Plotted raw, this is a real property of the data (confirmed by
inspecting individual values, not a bug) but it renders as a comb of
hundreds of thin spikes that makes two overlapping alliances impossible
to visually compare. `ui/match_lookup_tab.py::_draw_alliance_chart()`
applies a moving average (window 25) and then plots every 6th point,
**for display only** — `red_dist`/`blue_dist` themselves, and every
number shown in the panels above the chart (expected score, win
probability), are still computed from the raw, unsmoothed curve exactly
as before. Each curve is independently rescaled so its own peak is 1.0
(relative shape/overlap is what this chart is for, not absolute
density, which is already presented numerically above it).

**Validation:** ran this exact smoothing/trimming logic against all 110
real matches in the user's Match Schedule — all 110 produced a valid
1500-point smoothed curve with no errors. Spot-checked three matches
across the win-probability range: a lopsided 18.9%/81.1% match showed
the two curves clearly separated with modest overlap; a near-coinflip
50.9%/49.1% match showed the two curves almost fully overlapping — both
exactly the visual behavior this chart is meant to show.

**What did NOT change:** `calculations/alliance_generator.py` and
`calculations/match_odds.py` are both untouched — the smoothing lives
entirely in the new `_draw_alliance_chart()` method in
`ui/match_lookup_tab.py`, alongside the same `matplotlib`/`TkAgg`
embedding pattern Stage 10 already established for Team Lookup's Score
Trend chart.

## Testing note

This was built and its full calculation pipeline (`calculations/pipeline.py`,
including the Stage 3 Alliance Generator → Match Odds chain) was run
end-to-end against synthetic sample data to confirm it executes without
errors and produces sane numbers (win probabilities summing to 1,
expected scores in a realistic range, RPP/ROP/RDP all landing in
[0, 1]). The `tkinter` GUI layer could not be visually smoke-tested in
the environment this was built in (no display), so please flag anything
that looks visually off once you run it — the underlying data it
displays has been verified, but window layout quirks are more likely
than calculation errors at this stage.

As flagged above, the Alliance Generator / Match Odds numbers specifically
are the one area to compare against a real match in your Google Sheet
before trusting them for in-competition use — everything else in Stages
1–3 was traced formula-by-formula with high confidence.

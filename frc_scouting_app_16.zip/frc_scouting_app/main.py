"""
main.py

Entry point. Run with:  python main.py
100% offline - the only I/O this app performs is reading/writing the
local SQLite file in data/scouting.db and any CSV files you explicitly
import via the Data menu.
"""

from ui.app import run

if __name__ == "__main__":
    run()

"""
ui/app.py

Main application window. tkinter ships with the standard Python installer
on both Windows and macOS, so this GUI needs no extra install and makes
no network connections of any kind.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from database import init_db, clear_active_competition_data
from calculations.pipeline import build_all
import data_import

from ui.match_lookup_tab import MatchLookupTab
from ui.team_lookup_tab import TeamLookupTab
from ui.pick_list_tab import PickListTab
from ui.rankings_tab import RankingsTab
from ui.match_simulator_tab import MatchSimulatorTab


class ImportModeDialog(tk.Toplevel):
    """
    Modal dialog shown before every CSV import, asking whether this file
    is more data for the SAME competition already loaded (merge/update -
    the original, pre-Stage-9 behavior: new rows are added, and a
    re-imported match/team's columns are upserted in place, e.g. adding
    official scores after the fact) or the start of a DIFFERENT
    competition (replace - wipes both match_schedule and manual_raw_data
    first, so nothing from the old event can linger and mix with the
    new one).

    Sets self.result to "merge", "replace", or None (window closed /
    Cancel) before the dialog is destroyed. See ScoutingApp._import() for
    how the result is used.
    """

    def __init__(self, parent):
        super().__init__(parent)
        self.title("Import CSV")
        self.result: str | None = None
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        pad = {"padx": 16, "pady": 6}
        ttk.Label(
            self,
            text="Is this CSV more data for the competition already\n"
                 "loaded, or the start of a different competition?",
            justify="left",
        ).pack(anchor="w", **pad)

        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=16, pady=(4, 12))

        ttk.Button(
            btn_frame, text="Update current competition (keep existing data)",
            command=lambda: self._choose("merge"),
        ).pack(fill="x", pady=2)
        ttk.Button(
            btn_frame, text="New competition (replace ALL existing data)",
            command=lambda: self._choose("replace"),
        ).pack(fill="x", pady=2)
        ttk.Button(
            btn_frame, text="Cancel", command=self._cancel,
        ).pack(fill="x", pady=(8, 2))

        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.bind("<Escape>", lambda _e: self._cancel())

        self.update_idletasks()
        parent_x = parent.winfo_rootx()
        parent_y = parent.winfo_rooty()
        self.geometry(f"+{parent_x + 60}+{parent_y + 60}")

    def _choose(self, result: str):
        self.result = result
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()

    def show(self) -> str | None:
        self.wait_window()
        return self.result


class ScoutingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FRC Scouting App (Offline)")
        self.geometry("1150x720")
        self.minsize(900, 600)

        init_db()
        self.data = None  # calculations.pipeline.ComputedData, set by recalculate()
        self.my_team_num: int | None = None

        self._build_menu()
        self._build_notebook()
        self._build_status_bar()

        self.recalculate()

    # ------------------------------------------------------------------
    def _build_menu(self):
        menubar = tk.Menu(self)

        data_menu = tk.Menu(menubar, tearoff=0)
        data_menu.add_command(label="Import Match Schedule CSV...",
                               command=lambda: self._import("match_schedule"))
        data_menu.add_command(label="Import Raw Data CSV (Team + Score Breakdown)...",
                               command=lambda: self._import("raw_data"))
        data_menu.add_separator()
        data_menu.add_command(label="Set My Team Number...", command=self._set_my_team)
        data_menu.add_command(label="Recalculate Now", command=self.recalculate)
        menubar.add_cascade(label="Data", menu=data_menu)

        self.config(menu=menubar)

    def _build_notebook(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=6, pady=(6, 0))

        self.match_lookup_tab = MatchLookupTab(self.notebook, self)
        self.team_lookup_tab = TeamLookupTab(self.notebook, self)
        self.pick_list_tab = PickListTab(self.notebook, self)
        self.rankings_tab = RankingsTab(self.notebook, self)
        self.match_simulator_tab = MatchSimulatorTab(self.notebook, self)

        self.notebook.add(self.match_lookup_tab, text="Match Lookup")
        self.notebook.add(self.team_lookup_tab, text="Team Lookup")
        self.notebook.add(self.pick_list_tab, text="Pick List")
        self.notebook.add(self.rankings_tab, text="Rankings")
        # Match Simulator is a new, 5th tab beyond the 4 required tabs
        # that mirror the source Google Sheet - placed last so it never
        # disturbs the "first four tabs match the source sheet" mapping
        # the rest of this project's documentation relies on.
        self.notebook.add(self.match_simulator_tab, text="Match Simulator")

    def _build_status_bar(self):
        self.status_var = tk.StringVar(value="Ready")
        bar = ttk.Label(self, textvariable=self.status_var, anchor="w",
                         relief="sunken")
        bar.pack(fill="x", side="bottom")

    # ------------------------------------------------------------------
    def _import(self, kind: str):
        path = filedialog.askopenfilename(
            title=f"Select {kind} CSV",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return

        # Stage 9 fix: previously this always merged/upserted (as if
        # "Update current competition" were the only option), which is
        # why importing a second competition's CSVs on top of a first
        # competition's already-loaded data silently mixed the two
        # together instead of replacing it - both matches AND raw-data
        # rows from the old event stuck around, keyed by match numbers
        # that a different competition's schedule was free to reuse.
        # Now the user is asked explicitly every time. See
        # ImportModeDialog and database.clear_active_competition_data.
        mode = ImportModeDialog(self).show()
        if mode is None:
            return  # user cancelled
        replace = mode == "replace"

        if replace:
            # Wipe BOTH input tables, not just the one this CSV
            # populates. Wiping only match_schedule (or only
            # manual_raw_data) would still let the other table's old
            # competition data linger and mix with the new one,
            # depending on which of the two CSVs happens to be imported
            # first for the new event - a full wipe makes the fix work
            # regardless of import order.
            clear_active_competition_data()

        try:
            if kind == "raw_data":
                result = data_import.import_raw_data_csv(path, replace_existing=replace)
            elif kind == "match_schedule":
                n = data_import.import_match_schedule_csv(path, replace_existing=replace)
            else:
                return
        except Exception as exc:  # noqa: BLE001 - surface any import error to the user
            messagebox.showerror("Import failed", str(exc))
            return

        if kind == "raw_data":
            msg = f"Imported {result['imported']} rows."
            if replace:
                msg = "Cleared previous competition's data.\n" + msg
            if result["skipped_missing_ids"]:
                msg += f"\nSkipped {result['skipped_missing_ids']} row(s) missing a team or match number."
            if result["skipped_ambiguous_alliance"]:
                examples = ", ".join(f"match {m}/team {t}" for m, t in result["ambiguous_examples"])
                msg += (
                    f"\nSkipped {result['skipped_ambiguous_alliance']} row(s) whose alliance "
                    f"couldn't be determined (e.g. {examples}). Import a Match Schedule CSV "
                    f"first so these can be looked up by team+match, or add a Position/"
                    f"Alliance value to those rows."
                )
            if result.get("likely_typo_corrections"):
                examples = ", ".join(
                    f"match {m}: schedule had team {old} (no scouting data anywhere "
                    f"for it), corrected to team {new} (well-established elsewhere "
                    f"in this file)"
                    for m, old, new in result["likely_typo_correction_examples"]
                )
                msg += (
                    f"\n{result['likely_typo_corrections']} match_schedule slot(s) were "
                    f"auto-corrected as likely typos (e.g. {examples}). Please double "
                    f"check these against your real schedule."
                )
            if result.get("schedule_conflicts"):
                examples = ", ".join(
                    f"match {m}: row said team {t}, schedule already has team {existing}"
                    for m, t, existing in result["schedule_conflict_examples"]
                )
                msg += (
                    f"\n{result['schedule_conflicts']} row(s) had a Position/Alliance value "
                    f"that disagreed with a team already on record for that slot "
                    f"(e.g. {examples}). These rows were still imported for scoring, but "
                    f"match_schedule was NOT overwritten - please double check these rows "
                    f"for a mis-typed team or match number."
                )
            messagebox.showinfo("Import complete", msg)
        else:
            msg = f"Imported {n} rows."
            if replace:
                msg = "Cleared previous competition's data.\n" + msg
            messagebox.showinfo("Import complete", msg)
        self.recalculate()

    def _set_my_team(self):
        value = simpledialog.askinteger(
            "My Team Number",
            "Enter your team number (excluded from the Pick List):",
            initialvalue=self.my_team_num,
        )
        if value is not None:
            self.my_team_num = value
            self.recalculate()

    def recalculate(self):
        self.status_var.set("Recalculating...")
        self.update_idletasks()
        try:
            self.data = build_all(my_team_num=self.my_team_num)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Calculation error", str(exc))
            self.status_var.set("Calculation error - see dialog")
            return

        self.match_lookup_tab.refresh(self.data)
        self.team_lookup_tab.refresh(self.data)
        self.pick_list_tab.refresh(self.data)
        self.rankings_tab.refresh(self.data)
        self.match_simulator_tab.refresh(self.data)

        self.status_var.set(
            f"Ready - {len(self.data.roster)} teams, "
            f"{len(self.data.raw_data_rows)} scouted robot-matches"
        )


def run():
    app = ScoutingApp()
    app.mainloop()

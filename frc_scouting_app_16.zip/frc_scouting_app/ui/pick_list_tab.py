"""
ui/pick_list_tab.py

Recreates the "Pick List" sheet: teams ranked for alliance selection,
using calculations.pick_list (Alliance Builder Filtering) - teams that
clear the league-wide "Goal Ally RPP" bar are ranked by quality ratio
first, followed by the remaining teams ranked by ROP as a fallback list.
"""

import tkinter as tk
from tkinter import ttk


class PickListTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.data = None

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=(10, 0))
        self.info_var = tk.StringVar(value="")
        ttk.Label(top, textvariable=self.info_var, wraplength=1000,
                  foreground="#555").pack(fill="x")

        columns = ("rank", "team", "bucket", "quality", "rop")
        self.tree = ttk.Treeview(self, columns=columns, show="headings")
        headings = {
            "rank": "Rank", "team": "Team", "bucket": "Tier",
            "quality": "Quality Ratio", "rop": "ROP",
        }
        widths = {"rank": 50, "team": 80, "bucket": 110, "quality": 110, "rop": 90}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="center")
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)

    def refresh(self, data):
        self.data = data
        self.tree.delete(*self.tree.get_children())
        if not data:
            return

        team_label = f"Team {data.my_team_num}" if data.my_team_num else "your team"
        self.info_var.set(
            f"Pick List for {team_label} — teams at or above the league's "
            f"Goal Ally RPP bar ({data.team_ability.goal_ally_rpp:.3f}) are ranked "
            f"as Top Picks by score-consistency ratio; the rest are ranked as "
            f"Other Picks by ROP."
        )

        for i, entry in enumerate(data.pick_list, start=1):
            tier = "Top Pick" if entry.is_top_pick else "Other"
            quality = f"{entry.quality_ratio:.2f}" if entry.quality_ratio is not None else "—"
            self.tree.insert("", "end", values=(
                i, entry.team_num, tier, quality, f"{entry.rop:.3f}",
            ))

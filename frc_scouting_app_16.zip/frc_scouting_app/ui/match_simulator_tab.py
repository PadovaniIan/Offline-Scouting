"""
ui/match_simulator_tab.py

Stage 14: Match Simulator. Lets the user type in any six team numbers
(three red, three blue) that do NOT need to appear anywhere in the
imported Match Schedule, and see the exact same win-odds/expected-score
output the Match Lookup tab shows for a real, scheduled match - so the
user can try out hypothetical alliance combinations (e.g. "what would
happen if we allied with team X instead of team Y in eliminations?")
without needing that matchup to exist in the schedule.

This tab intentionally reuses ui/alliance_display.py's
build_alliance_panel() and draw_alliance_chart() - the exact same
rendering code ui/match_lookup_tab.py uses - so the two tabs can never
visually drift apart. The only real difference from Match Lookup is:

  1. The six teams come from user-typed Entry fields instead of a
     match number looked up in match_schedule.
  2. There is no real-world recorded score to show (the match doesn't
     exist), so build_alliance_panel() is called with
     actual_score=None, which omits that line entirely rather than
     showing a misleading 0 or blank. The computed "guess" (expected
     score) and win probability ARE still shown, exactly as Match
     Lookup shows them for a real match - that's the whole point of
     this tab.

No calculation code is touched or duplicated by this tab:
calculations.alliance_generator.build_alliance_distribution() and
calculations.match_odds.compute_match_odds() are called exactly as
Match Lookup calls them, on whichever six teams the user typed in.
"""

import tkinter as tk
from tkinter import ttk

from calculations.alliance_generator import build_alliance_distribution
from calculations.match_odds import compute_match_odds
from ui.alliance_display import build_alliance_panel, draw_alliance_chart


class MatchSimulatorTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.data = None

        vcmd = (self.register(self._validate_digits), "%P")

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)

        ttk.Label(
            top,
            text="Enter any six team numbers to simulate a hypothetical match "
                 "(they don't need to be on the schedule).",
        ).grid(row=0, column=0, columnspan=6, sticky="w", pady=(0, 8))

        self.red_vars = [tk.StringVar() for _ in range(3)]
        self.blue_vars = [tk.StringVar() for _ in range(3)]

        ttk.Label(top, text="Red Alliance:", foreground="#a33").grid(
            row=1, column=0, sticky="w", padx=(0, 6))
        self.red_entries = []
        for i, var in enumerate(self.red_vars):
            e = ttk.Entry(top, textvariable=var, width=8,
                           validate="key", validatecommand=vcmd)
            e.grid(row=1, column=1 + i, padx=4)
            e.bind("<Return>", lambda ev: self._simulate())
            self.red_entries.append(e)

        ttk.Label(top, text="Blue Alliance:", foreground="#36c").grid(
            row=2, column=0, sticky="w", padx=(0, 6), pady=(6, 0))
        self.blue_entries = []
        for i, var in enumerate(self.blue_vars):
            e = ttk.Entry(top, textvariable=var, width=8,
                           validate="key", validatecommand=vcmd)
            e.grid(row=2, column=1 + i, padx=4, pady=(6, 0))
            e.bind("<Return>", lambda ev: self._simulate())
            self.blue_entries.append(e)

        ttk.Button(top, text="Simulate", command=self._simulate).grid(
            row=1, column=4, rowspan=2, padx=(16, 0), sticky="ns")

        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=10, pady=10)

        ttk.Label(
            self.body,
            text="Enter six team numbers above and click Simulate.",
        ).pack()

    @staticmethod
    def _validate_digits(proposed: str) -> bool:
        # Allow the field to be cleared, and allow digits only (no decimals,
        # no negatives - team numbers are positive integers).
        return proposed == "" or proposed.isdigit()

    def refresh(self, data):
        self.data = data
        # If the user already had six teams typed in (e.g. after an
        # import/recalculate), re-run the simulation against the fresh
        # data rather than leaving stale numbers on screen.
        raw = [v.get().strip() for v in self.red_vars + self.blue_vars]
        if all(raw):
            self._simulate()

    def _simulate(self):
        for w in self.body.winfo_children():
            w.destroy()

        if not self.data:
            ttk.Label(self.body, text="No data loaded yet. Use the Data menu to import "
                                       "a Match Schedule and Raw Data CSV.").pack()
            return

        raw_red = [v.get().strip() for v in self.red_vars]
        raw_blue = [v.get().strip() for v in self.blue_vars]
        if not all(raw_red + raw_blue):
            ttk.Label(self.body, text="Enter all six team numbers above, then click "
                                       "Simulate.").pack()
            return

        red_teams = [int(t) for t in raw_red]
        blue_teams = [int(t) for t in raw_blue]
        all_six = red_teams + blue_teams

        if len(set(all_six)) != 6:
            ttk.Label(self.body, text="Each team number can only appear once in a "
                                       "match - one of your six teams is repeated.",
                      foreground="#a33").pack(anchor="w", padx=5, pady=(10, 0))
            return

        odds = None
        odds_error = None
        red_dist = None
        blue_dist = None
        try:
            missing = [t for t in all_six if t not in self.data.normalized_distributions]
            if missing:
                odds_error = f"Missing fitted distribution for team(s): {missing}"
            else:
                red_dist = build_alliance_distribution(
                    tuple(self.data.normalized_distributions[t] for t in red_teams)
                )
                blue_dist = build_alliance_distribution(
                    tuple(self.data.normalized_distributions[t] for t in blue_teams)
                )
                odds = compute_match_odds(red_dist, blue_dist)
        except Exception as exc:  # noqa: BLE001
            odds_error = str(exc)

        cols = ttk.Frame(self.body)
        cols.pack(fill="both", expand=True)

        red_win = odds.alliance_a_win_probability if odds else None
        blue_win = odds.alliance_b_win_probability if odds else None
        red_expected = odds.expected_score_a if odds else 0.0
        blue_expected = odds.expected_score_b if odds else 0.0

        # actual_score=None (not 0, not omitted-but-implied-zero): this
        # matchup has no real recorded score at all, since it may not
        # exist on the schedule. build_alliance_panel() simply skips
        # that line rather than showing a misleading value.
        red_frame = build_alliance_panel(cols, "Red Alliance", red_teams, self.data.score_variance,
                                          actual_score=None, win_prob=red_win, expected_score=red_expected)
        red_frame.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

        blue_frame = build_alliance_panel(cols, "Blue Alliance", blue_teams, self.data.score_variance,
                                           actual_score=None, win_prob=blue_win, expected_score=blue_expected)
        blue_frame.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)

        for c in range(2):
            cols.columnconfigure(c, weight=1)

        if odds_error:
            ttk.Label(self.body, text=f"Win odds unavailable: {odds_error}",
                      foreground="#a33").pack(anchor="w", padx=5, pady=(10, 0))

        chart_frame = ttk.LabelFrame(self.body, text="Score Distribution")
        chart_frame.pack(fill="both", expand=True, pady=(10, 0))
        draw_alliance_chart(chart_frame, red_dist, blue_dist)

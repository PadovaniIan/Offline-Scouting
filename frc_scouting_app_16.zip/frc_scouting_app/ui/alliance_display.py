"""
ui/alliance_display.py

Shared rendering helpers used by BOTH ui/match_lookup_tab.py (real,
scheduled matches) and ui/match_simulator_tab.py (hypothetical,
user-entered matchups). Factored out during the Match Simulator
addition so the two tabs can never visually drift apart - there is
exactly one implementation of "how an alliance panel looks" and
"how the score-distribution chart is drawn", used by both tabs.

Nothing in this module computes anything - build_alliance_panel() and
draw_alliance_chart() only display values (AllianceDistribution objects,
MatchOdds objects, per-team ScoreVarianceRow objects) that the caller
already computed via calculations.alliance_generator /
calculations.match_odds. See those modules for the actual algorithm.
"""

from tkinter import ttk


def build_alliance_panel(parent, title, teams, score_variance, *,
                          actual_score=None, win_prob=None, expected_score=None):
    """Build one alliance's panel: a small table of the three teams'
    Score Variance avg/RRP, followed by the actual recorded score (if
    known - real matches only) and the computed expected score / win
    probability (if odds could be computed).

    actual_score=None means "no real-world score exists for this
    matchup" (the Match Simulator's case) - that line is simply
    omitted rather than shown as 0 or "-", so a simulated match is
    never confused for a real one with a blank/zero score.
    """
    frame = ttk.LabelFrame(parent, text=title)
    tree = ttk.Treeview(frame, columns=("avg", "rrp"), show="tree headings", height=3)
    tree.heading("#0", text="Team")
    tree.heading("avg", text="Avg Score")
    tree.heading("rrp", text="Score RRP")
    tree.column("#0", width=80, anchor="center")
    tree.column("avg", width=110, anchor="center")
    tree.column("rrp", width=90, anchor="center")
    tree.pack(fill="x", padx=5, pady=5)
    for t in teams:
        sv = score_variance.get(t)
        avg = f"{sv.avg:.1f}" if sv else "—"
        rrp = f"{sv.rrp:.3f}" if sv else "—"
        tree.insert("", "end", text=str(t), values=(avg, rrp), iid=str(t))

    if actual_score is not None:
        ttk.Label(frame, text=f"Actual recorded score: {actual_score:g}",
                  font=("TkDefaultFont", 10, "bold")).pack(anchor="w", padx=5)
    if win_prob is not None:
        ttk.Label(frame, text=f"Expected score: {expected_score:.0f}").pack(anchor="w", padx=5)
        ttk.Label(frame, text=f"Win probability: {win_prob*100:.1f}%",
                  font=("TkDefaultFont", 11, "bold")).pack(anchor="w", padx=5, pady=(0, 5))
    return frame


def draw_alliance_chart(parent, red_dist, blue_dist):
    """Overlay red and blue's combined-score curves on one plot.

    Draws from AllianceDistribution.empirical_curve - the exact same
    per-integer-score density list calculations/match_odds.py
    computes win probability from (see calculations/
    alliance_generator.py). That raw curve is an EXACT-MATCH lookup
    onto a 1500-point integer axis (matching the source sheet's own
    VLOOKUP behaviour - see alliance_generator.py's module
    docstring), so most integer scores have no exact combined sample
    and sit at 0 right next to points near 1.0 - real, and not a
    bug, but a comb of hundreds of spikes if plotted directly, which
    makes the two alliances' actual overlap hard to see at a glance.

    For DISPLAY ONLY, this method smooths that curve with a
    trailing/leading moving average (width 25) and then plots only
    every 6th point - this does not touch red_dist/blue_dist or any
    calculation anywhere; match_odds.py and every number shown in
    the panels above are computed from the unsmoothed curve exactly
    as before. Each curve is independently rescaled so its own peak
    is 1.0 for readability (relative shape/overlap is what matters
    here, not absolute density).
    """
    # Imported here rather than at module level: matplotlib (and its
    # font-cache build on first import) is one of the slowest imports
    # in this app, and this function is only reached from a chart
    # draw. Deferring the import means a fresh install / empty
    # database (nothing to chart yet) never pays that cost at
    # startup. See match_lookup_tab.py / team_lookup_tab.py.
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

    fig = Figure(figsize=(8, 3.2), dpi=100)
    ax = fig.add_subplot(111)

    if red_dist is None or blue_dist is None:
        ax.text(0.5, 0.5, "Score distribution unavailable for this match.",
                 ha="center", va="center", transform=ax.transAxes,
                 color="#64748b")
        ax.set_xticks([])
        ax.set_yticks([])
        fig.tight_layout()
        canvas = FigureCanvasTkAgg(fig, master=parent)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)
        return

    window, stride = 25, 6

    def smoothed(curve):
        n = len(curve)
        half = window // 2
        csum = [0.0]
        for v in curve:
            csum.append(csum[-1] + v)
        out = []
        for i in range(n):
            lo = max(0, i - half)
            hi = min(n, i + half + 1)
            out.append((csum[hi] - csum[lo]) / (hi - lo))
        peak = max(out) if out else 0.0
        if peak > 0:
            out = [v / peak for v in out]
        return out

    red_y = smoothed(red_dist.empirical_curve)
    blue_y = smoothed(blue_dist.empirical_curve)
    xs = list(range(1, len(red_y) + 1))

    nonzero = [i for i, (r, b) in enumerate(zip(red_y, blue_y))
               if r > 0.01 or b > 0.01]
    if nonzero:
        lo = max(0, min(nonzero) - 10)
        hi = min(len(xs) - 1, max(nonzero) + 10)
    else:
        lo, hi = 0, len(xs) - 1

    rx = xs[lo:hi:stride]
    ry = red_y[lo:hi:stride]
    bx = xs[lo:hi:stride]
    by = blue_y[lo:hi:stride]

    ax.plot(rx, ry, color="#dc2626", linewidth=1.8, label="Red Alliance")
    ax.fill_between(rx, ry, color="#dc2626", alpha=0.15)
    ax.plot(bx, by, color="#2563eb", linewidth=1.8, label="Blue Alliance")
    ax.fill_between(bx, by, color="#2563eb", alpha=0.15)

    ax.set_xlabel("Combined alliance score")
    ax.set_ylabel("Relative likelihood")
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    canvas = FigureCanvasTkAgg(fig, master=parent)
    canvas.draw()
    canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)

"""
ui/rankings_tab.py

Recreates the "Rankings" sheet: every team ordered by RPP (overall power)
by default, with ROP, RDP, and Distance shown alongside - matching the
sheet's Rank / Team / RPP / ROP / RDP / Distance columns. A "Sort by"
dropdown lets the user re-sort the same table by RPP, ROP, RDP, or
Distance without hiding any of the other columns.
"""

import tkinter as tk
from tkinter import ttk


class RankingsTab(ttk.Frame):
    # Maps the dropdown label -> (attribute on the rpp row, whether a
    # HIGHER value should be ranked first). RPP/ROP/RDP are power scores
    # (bigger is better); Distance is "distance from the ideal (1,1)
    # point" (smaller is better), so it sorts ascending instead.
    SORT_OPTIONS = {
        "RPP": ("rpp", True),
        "ROP": ("rop", True),
        "RDP": ("rdp", True),
        "Distance": ("distance", False),
    }

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.data = None

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=(10, 0))
        ttk.Label(top, text="Sort by:").pack(side="left")
        self.sort_var = tk.StringVar(value="RPP")
        self.sort_combo = ttk.Combobox(top, textvariable=self.sort_var,
                                        state="readonly", width=10,
                                        values=list(self.SORT_OPTIONS.keys()))
        self.sort_combo.pack(side="left", padx=6)
        self.sort_combo.bind("<<ComboboxSelected>>", lambda e: self._render())

        columns = ("rank", "team", "rpp", "rop", "rdp", "distance", "defense_susceptible")
        self.tree = ttk.Treeview(self, columns=columns, show="headings")
        headings = {
            "rank": "Rank", "team": "Team", "rpp": "RPP", "rop": "ROP",
            "rdp": "RDP", "distance": "Distance", "defense_susceptible": "Weak to Defense?",
        }
        widths = {"rank": 50, "team": 80, "rpp": 90, "rop": 90, "rdp": 90,
                  "distance": 90, "defense_susceptible": 130}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="center")
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)

    def refresh(self, data):
        self.data = data
        self._render()

    def _render(self):
        self.tree.delete(*self.tree.get_children())
        if not self.data:
            return

        attr, descending = self.SORT_OPTIONS.get(self.sort_var.get(), ("rpp", True))
        rows = sorted(self.data.rpp.values(), key=lambda r: getattr(r, attr), reverse=descending)
        for i, row in enumerate(rows, start=1):
            self.tree.insert("", "end", values=(
                i, row.team_num, f"{row.rpp:.3f}", f"{row.rop:.3f}",
                f"{row.rdp:.3f}", f"{row.distance:.3f}",
                "Yes" if row.defense_susceptible else "No",
            ))


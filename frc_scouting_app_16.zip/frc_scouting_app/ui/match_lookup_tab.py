"""
ui/match_lookup_tab.py

Recreates the "Match Lookup" sheet: pick a match, see both alliances,
their per-robot stats, and the computed win odds / expected scores from
calculations.alliance_generator + calculations.match_odds (built live
from each alliance's three teammates' Normalized Distributions curves -
see those modules' docstrings for exactly how the two alliances' curves
are combined and compared).

Stage 12 added a "Score Distribution" chart below the two alliance
panels, overlaying red and blue's combined-score curves (each
AllianceDistribution.empirical_curve from calculations/
alliance_generator.py - the exact same curve calculations/match_odds.py
computes win probability from) on one plot so the user can see how much
the two alliances' likely-score ranges overlap. See
ui/alliance_display.py::draw_alliance_chart()'s docstring for why the
raw curve is smoothed for display (a pure visualization step - no
calculation changed).

Stage 14 (Match Simulator) moved the alliance-panel and chart-drawing
code that used to live directly in this file out into
ui/alliance_display.py, so ui/match_simulator_tab.py could reuse the
exact same rendering code for hypothetical matchups with zero risk of
the two tabs' displays drifting apart. This was a pure code-motion -
nothing about what this tab computes or displays changed.
"""

import tkinter as tk
from tkinter import ttk

from database import get_connection
from calculations.alliance_generator import build_alliance_distribution
from calculations.match_odds import compute_match_odds
from ui.alliance_display import build_alliance_panel, draw_alliance_chart


class MatchLookupTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.data = None
        self.matches: list[int] = []

        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)
        ttk.Label(top, text="Match #:").pack(side="left")

        # Digits-only validation, applied as the user types.
        vcmd = (self.register(self._validate_digits), "%P")
        self.match_var = tk.StringVar()
        self.match_entry = ttk.Entry(top, textvariable=self.match_var, width=10,
                                      validate="key", validatecommand=vcmd)
        self.match_entry.pack(side="left", padx=6)
        # Enter/Return submits, as does clicking away (focus-out).
        self.match_entry.bind("<Return>", lambda e: self._render())
        self.match_entry.bind("<FocusOut>", lambda e: self._render())

        ttk.Button(top, text="Go", command=self._render).pack(side="left")

        self.body = ttk.Frame(self)
        self.body.pack(fill="both", expand=True, padx=10, pady=10)

    @staticmethod
    def _validate_digits(proposed: str) -> bool:
        # Allow the field to be cleared, and allow digits only (no decimals,
        # no negatives - match numbers are positive integers).
        return proposed == "" or proposed.isdigit()

    def refresh(self, data):
        self.data = data
        with get_connection() as conn:
            rows = conn.execute(
                "SELECT match_num FROM match_schedule ORDER BY match_num"
            ).fetchall()
        self.matches = [r["match_num"] for r in rows]
        if self.matches and not self.match_var.get():
            self.match_var.set(str(self.matches[0]))
        self._render()

    def _render(self):
        for w in self.body.winfo_children():
            w.destroy()
        if not self.data:
            ttk.Label(self.body, text="No match schedule loaded yet. Use the Data menu to import a Match Schedule CSV.").pack()
            return

        raw = self.match_var.get().strip()
        if not raw:
            ttk.Label(self.body, text="Type a match number above and press Enter.").pack()
            return

        match_num = int(raw)
        with get_connection() as conn:
            m = conn.execute(
                "SELECT * FROM match_schedule WHERE match_num = ?", (match_num,)
            ).fetchone()
        if not m:
            ttk.Label(self.body, text=f"Match {match_num} not found.").pack()
            return

        red_teams = [m["red1"], m["red2"], m["red3"]]
        blue_teams = [m["blue1"], m["blue2"], m["blue3"]]

        odds = None
        odds_error = None
        red_dist = None
        blue_dist = None
        try:
            missing = [t for t in red_teams + blue_teams
                       if t not in self.data.normalized_distributions]
            if missing:
                odds_error = f"Missing fitted distribution for team(s): {missing}"
            else:
                red_dist = build_alliance_distribution(
                    tuple(self.data.normalized_distributions[t] for t in red_teams)
                )
                blue_dist = build_alliance_distribution(
                    tuple(self.data.normalized_distributions[t] for t in blue_teams)
                )
                odds = compute_match_odds(red_dist, blue_dist)
        except Exception as exc:  # noqa: BLE001
            odds_error = str(exc)

        cols = ttk.Frame(self.body)
        cols.pack(fill="both", expand=True)

        red_win = odds.alliance_a_win_probability if odds else None
        blue_win = odds.alliance_b_win_probability if odds else None
        red_expected = odds.expected_score_a if odds else 0.0
        blue_expected = odds.expected_score_b if odds else 0.0

        red_frame = build_alliance_panel(cols, "Red Alliance", red_teams, self.data.score_variance,
                                          actual_score=(m["red_score"] or 0),
                                          win_prob=red_win, expected_score=red_expected)
        red_frame.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

        blue_frame = build_alliance_panel(cols, "Blue Alliance", blue_teams, self.data.score_variance,
                                           actual_score=(m["blue_score"] or 0),
                                           win_prob=blue_win, expected_score=blue_expected)
        blue_frame.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)

        for c in range(2):
            cols.columnconfigure(c, weight=1)

        if odds_error:
            ttk.Label(self.body, text=f"Win odds unavailable: {odds_error}",
                      foreground="#a33").pack(anchor="w", padx=5, pady=(10, 0))

        chart_frame = ttk.LabelFrame(self.body, text="Score Distribution")
        chart_frame.pack(fill="both", expand=True, pady=(10, 0))
        draw_alliance_chart(chart_frame, red_dist, blue_dist)

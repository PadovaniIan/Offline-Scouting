"""
data_import.py

Bulk-loads CSV exports into the local input tables. All reads are from
local files on disk - nothing here touches the network.

Two supported inputs (see README.md "Getting data into the app"):

manual raw data CSV (a "Raw Data"-sheet-shaped export - team number,
match number, alliance slot, score breakdown, total score, and an
optional note - one row per scouted robot per match; see
import_raw_data_csv()):
    Required:  team_num, match_num
    Optional:  alliance (falls back to a Match Schedule lookup by
               team+match if blank or omitted entirely - see
               _lookup_alliance_from_schedule), auto_balls,
               auto_climb_pts, teleop_balls, teleop_l1, teleop_l2,
               teleop_l3, score (derived from the breakdown if blank),
               notes.
    Header row may be a single row (e.g. "Team Number, Match Number,
    Alliance, Auto Shooting, Auto Climb, Teleop Shooting, Teleop L1,
    Teleop L2, Teleop L3, Score, Notes") or the two-row grouped-header
    style some spreadsheet exports use, e.g.:
        row1:  ,      ,        ,Auto    ,Auto,Teleop  ,Teleop,Teleop,Teleop,      ,
        row2:  Team Number,Match,Position,SHOOTING,L1,SHOOTING,L1,L2,L3,Score,Notes
    Both are auto-detected - see _detect_raw_data_header().

match_schedule CSV:
    Required (7): match_num, red1, red2, red3, blue1, blue2, blue3
    Optional (2), trailing: red_score, blue_score
    The match_num column's header may be blank (some spreadsheet
    exports leave the corner cell empty) - see MATCH_SCHEDULE_ALIASES.
    Only touches the columns actually present in the CSV when a match
    row already exists (partial upsert), so importing team assignments
    now and official scores later (or vice versa, via
    import_raw_data_csv's own slot upsert) never clobbers the other.

Recommended order: import Match Schedule CSV first, then Raw Data CSV -
rows in the Raw Data CSV with a blank alliance/position are resolved by
looking up that team+match in the already-imported match_schedule.
"""

import csv
from collections import defaultdict
from pathlib import Path

from database import get_connection, init_db

MATCH_SCHEDULE_REQUIRED = ["match_num", "red1", "red2", "red3", "blue1", "blue2", "blue3"]
MATCH_SCHEDULE_OPTIONAL = ["red_score", "blue_score"]

# Accepted header spellings, mapped to the internal column name. Matching
# is case-insensitive and ignores spaces/underscores, so "Auto Shooting",
# "auto_balls", "Auto Balls" all resolve to the same field. A blank
# header ("") is treated as the match number column, since some exports
# leave that corner cell empty.
MATCH_SCHEDULE_ALIASES = {
    "": "match_num", "matchnum": "match_num", "matchnumber": "match_num",
    "match": "match_num", "matchno": "match_num",
    "red1": "red1", "redteam1": "red1", "r1": "red1",
    "red2": "red2", "redteam2": "red2", "r2": "red2",
    "red3": "red3", "redteam3": "red3", "r3": "red3",
    "blue1": "blue1", "blueteam1": "blue1", "b1": "blue1",
    "blue2": "blue2", "blueteam2": "blue2", "b2": "blue2",
    "blue3": "blue3", "blueteam3": "blue3", "b3": "blue3",
    "redscore": "red_score", "redtotal": "red_score", "redfinalscore": "red_score",
    "bluescore": "blue_score", "bluetotal": "blue_score", "bluefinalscore": "blue_score",
}

# Accepted header spellings for the manual Raw-Data-shaped CSV, mapped to
# the internal column name. Also doubles as the target list for the
# two-row grouped-header combiner (e.g. "Auto" + "SHOOTING" -> "autoshooting").
RAW_DATA_HEADER_ALIASES = {
    "team_num": "team_num", "teamnumber": "team_num", "team": "team_num",
    "match_num": "match_num", "matchnumber": "match_num", "match": "match_num",
    "alliance": "alliance", "position": "alliance",
    "auto_balls": "auto_balls", "autoshooting": "auto_balls",
    "autoballs": "auto_balls",
    "auto_climb_pts": "auto_climb_pts", "autoclimb": "auto_climb_pts",
    "autol1": "auto_climb_pts", "autoclimbpts": "auto_climb_pts",
    "teleop_balls": "teleop_balls", "teleopshooting": "teleop_balls",
    "teleopballs": "teleop_balls",
    "teleop_l1": "teleop_l1", "teleopl1": "teleop_l1",
    "teleop_l2": "teleop_l2", "teleopl2": "teleop_l2",
    "teleop_l3": "teleop_l3", "teleopl3": "teleop_l3",
    "score": "score", "totalscore": "score",
    "notes": "notes", "note": "notes",
}

ALLIANCE_SLOT_TO_SCHEDULE_COL = {
    "r1": "red1", "r2": "red2", "r3": "red3",
    "b1": "blue1", "b2": "blue2", "b3": "blue3",
}
SCHEDULE_COL_TO_ALLIANCE_SLOT = {v: k for k, v in ALLIANCE_SLOT_TO_SCHEDULE_COL.items()}


def _num(value, default=0.0):
    if value is None or value == "":
        return default
    try:
        return float(str(value).replace(",", ""))
    except ValueError:
        return default


def _int_or_none(value):
    if value is None or value == "":
        return None
    try:
        return int(float(str(value).replace(",", "")))
    except ValueError:
        return None


def _normalize_header(h: str) -> str:
    return (h or "").lower().strip().replace(" ", "").replace("_", "")


def _match_headers(header_row: list[str], aliases: dict[str, str]) -> dict[str, int]:
    """Maps internal field name -> column index, first match wins."""
    matches: dict[str, int] = {}
    for i, h in enumerate(header_row):
        mapped = aliases.get(_normalize_header(h))
        if mapped and mapped not in matches:
            matches[mapped] = i
    return matches


def _cell(row: list[str], idx) -> str:
    if idx is None or idx >= len(row):
        return ""
    return row[idx]


# --------------------------------------------------------------------------
# Raw Data CSV
# --------------------------------------------------------------------------

def _detect_raw_data_header(rows: list[list[str]]) -> tuple[dict[str, int], int]:
    """
    Figures out which row(s) are the header and returns (field -> column
    index map, index of the first data row).

    Tries a single-row header first (row 0 alone). If that doesn't yield
    both team_num and match_num, tries combining rows 0 and 1 - handles
    the two-row grouped-header style (e.g. "Auto"/"SHOOTING" split across
    two rows) - and uses that instead.
    """
    if not rows:
        raise ValueError("Raw Data CSV is empty.")

    single = _match_headers(rows[0], RAW_DATA_HEADER_ALIASES)
    if "team_num" in single and "match_num" in single:
        return single, 1

    if len(rows) > 1:
        combined = []
        row0, row1 = rows[0], rows[1]
        width = max(len(row0), len(row1))
        for i in range(width):
            a = row0[i].strip() if i < len(row0) else ""
            b = row1[i].strip() if i < len(row1) else ""
            combined.append(f"{a} {b}".strip())
        two_row = _match_headers(combined, RAW_DATA_HEADER_ALIASES)
        if "team_num" in two_row and "match_num" in two_row:
            return two_row, 2

    raise ValueError(
        "Raw Data CSV is missing required column(s): team_num, match_num. "
        "Expected headers like Team Number, Match Number, Alliance/Position, "
        "Auto Shooting, Auto Climb, Teleop Shooting, Teleop L1/L2/L3, Score, Notes "
        "(either as a single header row, or split across two grouped-header rows)."
    )


def _lookup_alliance_from_schedule(conn, match_num: int, team_num: int) -> str | None:
    """Finds which red1..blue3 slot a team occupies for a given match in
    the already-imported match_schedule table. Returns 'r1'..'b3', or
    None if that match/team combination isn't there yet."""
    row = conn.execute(
        "SELECT red1, red2, red3, blue1, blue2, blue3 FROM match_schedule WHERE match_num = ?",
        (match_num,),
    ).fetchone()
    if not row:
        return None
    for slot_col, slot_name in SCHEDULE_COL_TO_ALLIANCE_SLOT.items():
        if row[slot_col] == team_num:
            return slot_name
    return None


def _normalize_alliance(raw: str, seen_counts: dict[tuple[int, str], int],
                         match_num: int):
    """
    Turns an explicit Alliance/Position cell into the app's
    'r1'/'r2'/'r3'/'b1'/'b2'/'b3' convention. Returns None if the cell is
    blank or unrecognized (caller should fall back to a match_schedule
    lookup instead of guessing).

    Accepts: 'R1','r1','B2','Red 1','BLUE3','red','blue' (bare color -
    in which case a slot number is assigned in order of appearance for
    that match+color, 1st/2nd/3rd row seen).
    """
    text = (raw or "").strip().lower()
    if not text:
        return None

    if text.startswith("red"):
        color, rest = "r", text[3:]
    elif text.startswith("blue"):
        color, rest = "b", text[4:]
    elif text[:1] in ("r", "b"):
        color, rest = text[0], text[1:]
    else:
        return None  # unrecognized text - treat as blank, fall back to lookup

    rest = rest.strip()
    slot = "".join(ch for ch in rest if ch.isdigit())
    if slot in ("1", "2", "3"):
        return f"{color}{slot}"

    # No slot number given - assign the next open slot (1,2,3) for this
    # match+color, in order of appearance.
    key = (match_num, color)
    seen_counts[key] = seen_counts.get(key, 0) + 1
    slot_num = min(seen_counts[key], 3)
    return f"{color}{slot_num}"


def import_raw_data_csv(path: str | Path, replace_existing: bool = False) -> dict:
    """
    Load a "Raw Data"-sheet-shaped CSV directly: one row per scouted
    robot per match, with team number, match number, alliance slot, the
    auto/teleop/climb score breakdown, a total score, and an optional
    note. This is the primary/only Raw Data source in this app - see
    calculations.raw_processing.build_raw_data_from_manual and
    calculations.pipeline.build_all.

    Match Schedule is always treated as the authoritative source for
    alliance/slot assignment, exactly like the original Google Sheet
    (whose Raw Data sheet has no alliance/position column at all -
    every calculation there determines red/blue membership solely from
    Match Schedule's manually-entered Red1-3/Blue1-3 columns). So for
    every row, this function first tries to look up that team+match in
    the already-imported match_schedule table; only if that lookup
    fails does it fall back to this row's own Alliance/Position cell,
    and it upserts match_num + alliance-slot team number into
    match_schedule (red1..blue3) ONLY in that fallback case - so Match
    Lookup has something to list immediately when Raw Data is imported
    before Match Schedule, without ever letting a Raw Data row's own
    (sometimes unreliable - e.g. a scout's personal "1st/2nd/3rd robot
    I saw" numbering rather than the true official slot) Position value
    silently overwrite a schedule slot that's already known to be
    correct. This never touches red_score/blue_score either, so a
    separate Match Schedule CSV import for the real final scores won't
    be clobbered and vice versa.

    Rows missing team_num or match_num, or whose alliance can't be
    determined at all (no match_schedule entry AND no usable
    Alliance/Position cell), are skipped and counted in the returned
    summary rather than guessed at blindly. Rows whose own
    Alliance/Position cell disagrees with a team number already on
    record for that slot (a sign of a data-entry error in the CSV
    itself, such as a mis-typed team number) are also skipped-from-
    upsert and counted separately as schedule_conflicts - UNLESS the
    team already on record is a clear "orphan" (appears in Match
    Schedule exactly this once, with zero corroborating scouting data
    anywhere, including this same CSV) while this row's team is
    well-established elsewhere in the CSV, in which case it's treated
    as a likely Match Schedule typo and corrected automatically
    (counted separately as likely_typo_corrections, always reported so
    it can be double-checked). See the inline comment above the
    conflict-handling code for the exact evidence used.

    Returns a dict: {"imported": n, "skipped_missing_ids": n,
    "skipped_ambiguous_alliance": n, "ambiguous_examples": [(match,team),...],
    "schedule_conflicts": n, "schedule_conflict_examples": [(match,team,existing_team),...],
    "likely_typo_corrections": n, "likely_typo_correction_examples": [(match,old_team,new_team),...]}
    """
    init_db()
    imported = 0
    skipped_missing_ids = 0
    skipped_ambiguous = 0
    ambiguous_examples: list[tuple[int, int]] = []
    schedule_conflicts = 0
    schedule_conflict_examples: list[tuple[int, int, int]] = []  # (match, team, existing_team)
    likely_typo_corrections = 0
    likely_typo_correction_examples: list[tuple[int, int, int]] = []  # (match, old_team, new_team)
    seen_counts: dict[tuple[int, str], int] = {}

    with open(path, newline="", encoding="utf-8-sig") as f:
        all_rows = [r for r in csv.reader(f) if any(cell.strip() for cell in r)]

    col, data_start = _detect_raw_data_header(all_rows)
    data_rows = all_rows[data_start:]

    # Pre-scan: how many rows in THIS CSV mention each team number at all
    # (regardless of match). Used below to tell a well-established,
    # heavily-scouted team (e.g. one with 9 rows across 9 matches) apart
    # from a team that shows up only once - see the conflict-resolution
    # comment further down.
    csv_team_counts: dict[int, int] = defaultdict(int)
    for row in data_rows:
        t = _int_or_none(_cell(row, col.get("team_num")))
        if t:
            csv_team_counts[t] += 1

    with get_connection() as conn:
        cur = conn.cursor()
        if replace_existing:
            cur.execute("DELETE FROM manual_raw_data")

        # How many of Match Schedule's 6 slots (across all matches, in
        # the already-imported table) each team currently occupies, and
        # how many manual_raw_data rows already exist per team - both
        # used as "corroboration" evidence below.
        sched_team_counts: dict[int, int] = defaultdict(int)
        for row in cur.execute(
            "SELECT red1,red2,red3,blue1,blue2,blue3 FROM match_schedule"
        ):
            for t in row:
                if t is not None:
                    sched_team_counts[t] += 1
        raw_db_team_counts: dict[int, int] = defaultdict(int)
        for row in cur.execute(
            "SELECT team_num, COUNT(*) c FROM manual_raw_data GROUP BY team_num"
        ):
            raw_db_team_counts[row["team_num"]] = row["c"]

        for row in data_rows:
            team_num = _int_or_none(_cell(row, col.get("team_num")))
            match_num = _int_or_none(_cell(row, col.get("match_num")))
            # Skip placeholder/empty template rows (blank team and/or match).
            if not team_num or match_num is None:
                skipped_missing_ids += 1
                continue

            # Match Schedule is the authoritative source of truth for
            # alliance/slot assignment - exactly like the original Google
            # Sheet, where the Raw Data sheet has no alliance/position
            # column at all and every calculation determines red/blue
            # membership solely from Match Schedule's (manually entered,
            # ground-truth) Red1-3/Blue1-3 columns. So we ALWAYS check
            # match_schedule first if this match/team pair is already
            # there. Only when that lookup fails (match_schedule doesn't
            # have this match yet, or doesn't list this team in any of
            # its 6 slots) do we fall back to this row's own
            # Alliance/Position cell as a best-effort guess.
            #
            # This ordering matters a lot in practice: real-world Raw
            # Data exports often carry a Position column that reflects
            # the scout's own bookkeeping (e.g. "the 1st robot I
            # scouted") rather than the official schedule slot. Trusting
            # that column over an already-known-correct schedule would
            # silently upsert the WRONG team number into
            # match_schedule's redN/blueN column, corrupting alliance
            # grouping for every downstream calculation (Raw Data
            # Processing's alliance ratios, the Adjusted Score
            # apportionment, and everything built on top of it) even
            # though the per-robot Raw Data/Score Variance numbers stay
            # correct. See README.md for a worked example of this bug.
            alliance = _lookup_alliance_from_schedule(conn, match_num, team_num)
            used_fallback = False
            if alliance is None:
                alliance = _normalize_alliance(
                    _cell(row, col.get("alliance")), seen_counts, match_num
                )
                used_fallback = alliance is not None
            if alliance is None:
                skipped_ambiguous += 1
                if len(ambiguous_examples) < 10:
                    ambiguous_examples.append((match_num, team_num))
                continue

            score_raw = _cell(row, col.get("score"))
            score = _num(score_raw, default=None) if score_raw not in ("", None) else None

            cur.execute(
                """INSERT INTO manual_raw_data
                   (match_num, alliance, team_num, auto_balls, auto_climb_pts,
                    teleop_balls, teleop_l1, teleop_l2, teleop_l3, score, notes)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    match_num, alliance, team_num,
                    _num(_cell(row, col.get("auto_balls"))),
                    _num(_cell(row, col.get("auto_climb_pts"))),
                    _num(_cell(row, col.get("teleop_balls"))),
                    _num(_cell(row, col.get("teleop_l1"))),
                    _num(_cell(row, col.get("teleop_l2"))),
                    _num(_cell(row, col.get("teleop_l3"))),
                    score, _cell(row, col.get("notes")),
                ),
            )
            imported += 1

            # Only upsert this robot's team number into match_schedule when
            # we actually had to FALL BACK to this row's own
            # Alliance/Position cell (i.e. match_schedule didn't already
            # know this match/team). If the alliance came from an existing
            # match_schedule lookup above, match_schedule already has the
            # correct, authoritative value - upserting again would be
            # redundant at best and, if a differently-slotted duplicate
            # team number shows up elsewhere in the file, harmful at
            # worst. This is what keeps a correct Match Schedule import
            # from ever being clobbered by Raw Data's own Position column.
            if used_fallback:
                slot_col = ALLIANCE_SLOT_TO_SCHEDULE_COL[alliance]
                existing = cur.execute(
                    f"SELECT {slot_col} FROM match_schedule WHERE match_num = ?",
                    (match_num,),
                ).fetchone()
                existing_team = existing[0] if existing else None
                if existing_team is not None and existing_team != team_num:
                    # This row's own Alliance/Position guess disagrees with
                    # a team number ALREADY on record for that slot (from
                    # an earlier row in this same file, since a real
                    # Match Schedule import would have made
                    # _lookup_alliance_from_schedule succeed above and
                    # skipped this branch entirely). This is a genuine
                    # data anomaly - but which side is wrong isn't always
                    # a coin flip: if the team already on record is an
                    # "orphan" (appears in Match Schedule exactly this
                    # once, with zero scouting data anywhere for it -
                    # including nowhere else in this very CSV), while
                    # this row's team is well-established (several other
                    # matches' worth of real scouting data for it in this
                    # CSV), that lopsidedness is strong evidence the
                    # schedule slot itself is a typo (a classic case:
                    # "325" in Match Schedule where every other data point
                    # says "3256" - a single dropped digit) rather than a
                    # genuine ambiguity between two real teams. In that
                    # specific, narrow case we correct it and report the
                    # correction; in every other case (both teams equally
                    # well-established elsewhere - the far more common
                    # shape of this problem) we still refuse to guess and
                    # just report the conflict, exactly as before.
                    existing_is_orphan = (
                        sched_team_counts.get(existing_team, 0) <= 1
                        and raw_db_team_counts.get(existing_team, 0) == 0
                        and csv_team_counts.get(existing_team, 0) == 0
                    )
                    candidate_established = csv_team_counts.get(team_num, 0) >= 3
                    if existing_is_orphan and candidate_established:
                        cur.execute(
                            f"""INSERT INTO match_schedule (match_num, {slot_col})
                                VALUES (?, ?)
                                ON CONFLICT(match_num) DO UPDATE SET {slot_col} = excluded.{slot_col}""",
                            (match_num, team_num),
                        )
                        likely_typo_corrections += 1
                        if len(likely_typo_correction_examples) < 10:
                            likely_typo_correction_examples.append(
                                (match_num, existing_team, team_num)
                            )
                    else:
                        schedule_conflicts += 1
                        if len(schedule_conflict_examples) < 10:
                            schedule_conflict_examples.append(
                                (match_num, team_num, existing_team)
                            )
                else:
                    cur.execute(
                        f"""INSERT INTO match_schedule (match_num, {slot_col})
                            VALUES (?, ?)
                            ON CONFLICT(match_num) DO UPDATE SET {slot_col} = excluded.{slot_col}""",
                        (match_num, team_num),
                    )

        conn.commit()

    return {
        "imported": imported,
        "skipped_missing_ids": skipped_missing_ids,
        "skipped_ambiguous_alliance": skipped_ambiguous,
        "ambiguous_examples": ambiguous_examples,
        "schedule_conflicts": schedule_conflicts,
        "schedule_conflict_examples": schedule_conflict_examples,
        "likely_typo_corrections": likely_typo_corrections,
        "likely_typo_correction_examples": likely_typo_correction_examples,
    }


# --------------------------------------------------------------------------
# Match Schedule CSV
# --------------------------------------------------------------------------

def import_match_schedule_csv(path: str | Path, replace_existing: bool = False) -> int:
    """
    Load a Match Schedule CSV: match number + the six team slots
    (red1-3, blue1-3), with optional trailing red_score/blue_score
    columns. Header aliases are matched case/space/underscore-
    insensitively; a blank header on the first column is treated as the
    match number (some spreadsheet exports leave that corner cell
    empty). Falls back to strict column-position order (match_num,
    red1, red2, red3, blue1, blue2, blue3, [red_score, blue_score]) if
    no header row is recognized at all.

    Only writes the columns actually present in this CSV - if a match
    row already exists (e.g. team slots were populated earlier by
    import_raw_data_csv), columns this CSV doesn't provide are left
    untouched rather than being reset to NULL, and vice versa.

    Returns the number of rows imported.
    """
    init_db()
    rows_written = 0

    with open(path, newline="", encoding="utf-8-sig") as f:
        all_rows = [r for r in csv.reader(f) if any(cell.strip() for cell in r)]
    if not all_rows:
        raise ValueError("Match Schedule CSV is empty.")

    col = _match_headers(all_rows[0], MATCH_SCHEDULE_ALIASES)
    if all(c in col for c in MATCH_SCHEDULE_REQUIRED):
        data_start = 1
    else:
        # No recognizable header - fall back to strict positional order.
        col = {name: i for i, name in enumerate(MATCH_SCHEDULE_REQUIRED + MATCH_SCHEDULE_OPTIONAL)}
        data_start = 0

    has_red_score = "red_score" in col
    has_blue_score = "blue_score" in col

    set_cols = ["red1", "red2", "red3", "blue1", "blue2", "blue3"]
    if has_red_score:
        set_cols.append("red_score")
    if has_blue_score:
        set_cols.append("blue_score")

    with get_connection() as conn:
        cur = conn.cursor()
        if replace_existing:
            cur.execute("DELETE FROM match_schedule")

        for row in all_rows[data_start:]:
            match_num = _int_or_none(_cell(row, col.get("match_num")))
            if match_num is None:
                continue

            values = {
                "red1": _int_or_none(_cell(row, col.get("red1"))),
                "red2": _int_or_none(_cell(row, col.get("red2"))),
                "red3": _int_or_none(_cell(row, col.get("red3"))),
                "blue1": _int_or_none(_cell(row, col.get("blue1"))),
                "blue2": _int_or_none(_cell(row, col.get("blue2"))),
                "blue3": _int_or_none(_cell(row, col.get("blue3"))),
            }
            if has_red_score:
                values["red_score"] = _num(_cell(row, col.get("red_score")), default=None)
            if has_blue_score:
                values["blue_score"] = _num(_cell(row, col.get("blue_score")), default=None)

            insert_cols = ["match_num"] + set_cols
            placeholders = ",".join(["?"] * len(insert_cols))
            update_clause = ",".join(f"{c} = excluded.{c}" for c in set_cols)
            cur.execute(
                f"""INSERT INTO match_schedule ({",".join(insert_cols)})
                    VALUES ({placeholders})
                    ON CONFLICT(match_num) DO UPDATE SET {update_clause}""",
                [match_num] + [values[c] for c in set_cols],
            )
            rows_written += 1

        conn.commit()
    return rows_written

"""
calculations/power_rankings.py

Recreates "ROP" (offensive power), "RDP" (defensive power), and "RPP"
(overall power - what Rankings and Pick List are ultimately sorted by).

--------------------------------------------------------------------------
ROP sheet
--------------------------------------------------------------------------
    B = Auto Balls Scored!RRP        (calculations.balls_scored)
    C = Teleop Balls Scored!RRP      (calculations.balls_scored)
    D = Score Variance!RRP           (calculations.score_variance) -
                                      EXPERIMENT: was Adjusted Score
                                      Variance!RRP - see README.md
                                      "Experiment: Adjusted Score
                                      Variance removed" and
                                      pipeline.py
    E = Average Compatability!RRP    (calculations.defense)
    F = STDEV(B,C,D,E)
    G = AVERAGE.WEIGHTED({D,E}, {2,0.5})   <- B,C feed only F, not G
    H = G / F   (unused downstream but kept for parity with the sheet)
    ROP = G / MAX(every team's G)

--------------------------------------------------------------------------
RDP sheet
--------------------------------------------------------------------------
Reuses Raw Data Processing's opponent_alliance_ratio per-team match list
(already built in Stage 1/2 for Defense Adjustment):
    Min   = SMALL(all values, 2)
    Max   = LARGE(values[1:], 2)      <- sheet quirk: excludes 1st match
    STDEV/AVG = over values[1:]       <- same exclusion
    RDP = AVERAGE.WEIGHTED(
              {MIN(every team's AVG) / this team's AVG, 2},
              {Defense Calculations RRP, 1}
          )

--------------------------------------------------------------------------
RPP sheet
--------------------------------------------------------------------------
    D = AVERAGE.WEIGHTED({ROP, 2}, {RDP, 1})
    RPP = D / MAX(every team's D)
    defense_susceptible = Defense Calculations' raw (non-normalized)
                           defensive_variance < 0
    variance = Score Variance!STDEV
    distance = SQRT((1-ROP)^2 + (1-RDP)^2)   <- distance from the "ideal"
                                                 (1,1) point; smaller is better
"""

from dataclasses import dataclass, field

from calculations.matrix_stats import _sample_stdev, _small_nth, _large_nth


@dataclass
class ROPRow:
    team_num: int
    stdev: float
    weighted_avg: float
    rop: float = 0.0


def build_rop(
    auto_balls_scored: dict, teleop_balls_scored: dict,
    score_variance: dict, average_compatability: dict,
) -> dict[int, ROPRow]:
    teams = set(auto_balls_scored) | set(teleop_balls_scored) | \
        set(score_variance) | set(average_compatability)

    rows: dict[int, ROPRow] = {}
    for team in teams:
        b = auto_balls_scored[team].rrp if team in auto_balls_scored else 0.0
        c = teleop_balls_scored[team].rrp if team in teleop_balls_scored else 0.0
        d = score_variance[team].rrp if team in score_variance else 0.0
        e = average_compatability[team].rrp if team in average_compatability else 0.0

        stdev = _sample_stdev([b, c, d, e])
        weighted_avg = (2 * d + 0.5 * e) / 2.5

        rows[team] = ROPRow(team_num=team, stdev=stdev, weighted_avg=weighted_avg)

    max_g = max((r.weighted_avg for r in rows.values()), default=0.0)
    for r in rows.values():
        r.rop = (r.weighted_avg / max_g) if max_g else 0.0

    return rows


@dataclass
class RDPRow:
    team_num: int
    values: list[float]
    avg: float
    rdp: float = 0.0


def build_rdp(
    opponent_ratio_by_team: dict[int, list[float]],
    defense_calculations: dict,
) -> dict[int, RDPRow]:
    rows: dict[int, RDPRow] = {}
    for team, values in opponent_ratio_by_team.items():
        tail = values[1:]  # sheet excludes the first chronological match
        avg = (sum(tail) / len(tail)) if tail else 0.0
        rows[team] = RDPRow(team_num=team, values=values, avg=avg)

    all_avgs = [r.avg for r in rows.values() if r.avg]
    min_avg = min(all_avgs, default=0.0)

    for team, r in rows.items():
        dc = defense_calculations.get(team)
        dc_rrp = dc.rrp if dc else 0.0
        ratio_component = (min_avg / r.avg) if r.avg else 0.0
        r.rdp = (2 * ratio_component + 1 * dc_rrp) / 3.0

    return rows


@dataclass
class RPPRow:
    team_num: int
    rop: float
    rdp: float
    weighted_avg: float
    rpp: float = 0.0
    defense_susceptible: bool = False
    variance: float = 0.0
    distance: float = 0.0


def build_rpp(
    rop: dict[int, ROPRow], rdp: dict[int, RDPRow],
    defense_calculations: dict, score_variance: dict,
) -> dict[int, RPPRow]:
    teams = set(rop) | set(rdp)
    rows: dict[int, RPPRow] = {}
    for team in teams:
        rop_val = rop[team].rop if team in rop else 0.0
        rdp_val = rdp[team].rdp if team in rdp else 0.0
        weighted_avg = (2 * rop_val + 1 * rdp_val) / 3.0
        dc = defense_calculations.get(team)
        sv = score_variance.get(team)
        rows[team] = RPPRow(
            team_num=team, rop=rop_val, rdp=rdp_val, weighted_avg=weighted_avg,
            defense_susceptible=(dc.defensive_variance < 0) if dc else False,
            variance=sv.stdev if sv else 0.0,
            distance=((1 - rop_val) ** 2 + (1 - rdp_val) ** 2) ** 0.5,
        )

    max_d = max((r.weighted_avg for r in rows.values()), default=0.0)
    for r in rows.values():
        r.rpp = (r.weighted_avg / max_d) if max_d else 0.0

    return rows

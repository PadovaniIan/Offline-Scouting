"""
calculations/raw_processing.py

Currently active: build_raw_data_from_manual() - see "Manual Raw Data"
below. This is the sole Raw Data source used by calculations.pipeline
now that the granular Raw Scouting / BPS CSV imports have been removed
in favor of a single Raw Data CSV (data_import.import_raw_data_csv).

Legacy / currently unused: team_bps_averages(), _augment_unfiltered_rows(),
and build_raw_data() below recreate three sheets ("BPS", "Unfiltered Raw
Data", and "Raw Data") from granular shooting-time-based scouting entries
plus BPS calibration samples. Nothing in the app writes to the
raw_scouting or bps_samples tables anymore, so these functions are dead
code in practice - kept only in case that stopwatch-based scouting
workflow is reintroduced later. Their formula documentation below is
still accurate if that happens.
    "BPS"                 -> team_bps_averages()
    "Unfiltered Raw Data" (derived columns S-AC) -> _augment_unfiltered_rows()
    "Raw Data"             -> build_raw_data()

--------------------------------------------------------------------------
BPS sheet (legacy)
--------------------------------------------------------------------------
    BPS!A = team number (manual)
    BPS!D:J = manually recorded ball-per-second calibration samples
    BPS!C = =iferror(AVERAGE(D2:J2), 0)

--------------------------------------------------------------------------
Unfiltered Raw Data sheet (legacy, derived columns, formulas from FORMULA_EXPORT)
--------------------------------------------------------------------------
    T  (BPS)                    = LOOKUP(team, BPS!A, BPS!C)
    S  (Auto Theory Balls)      = G(auto_shooting_time) * T
    U  (Teleop Theory Balls)    = K(teleop_shooting_time) * T
    V  (Auto Total Theory)      = SUM(S) for same match & alliance color
    W  (Teleop Total Theory)    = SUM(U) for same match & alliance color
    X  (Actual Auto Balls)      = Match Schedule red/blue auto balls for
                                   this match, picked by alliance color
    Y  (Actual Teleop Balls)    = Match Schedule red/blue teleop balls
    Z  (Auto Contribution)      = S / V   (this robot's share of its
                                            alliance's theoretical auto)
    AA (Teleop Contribution)    = U / W
    AB (Auto Guess Balls)       = Z * X
    AC (Teleop Guess Balls)     = AA * Y

--------------------------------------------------------------------------
Raw Data sheet (legacy derivation - see "Manual Raw Data" below for the
active path, which reads these same fields directly from a CSV instead)
--------------------------------------------------------------------------
    A (Team Number)     = Unfiltered!E  (team_num)
    B (Auto Shooting)   = Unfiltered!AB (Auto Guess Balls)
    C (Auto L1/Climb)   = 15 if Unfiltered!auto_climb == "CLIMB" else 0
    D (Teleop Shooting) = Unfiltered!AC (Teleop Guess Balls)
    E (Teleop L1)       = 10 if Unfiltered!teleop_climb == "1" else 0
    F (Teleop L2)       = 20 if Unfiltered!teleop_climb == "2" else 0
    G (Teleop L3)       = 30 if Unfiltered!teleop_climb == "3" else 0
    H (Score)           = B+C+D+E+F+G, but 2 if that sum is 0
    I (Notes)           = Unfiltered!notes

--------------------------------------------------------------------------
Manual Raw Data (ACTIVE - direct import, no BPS/Unfiltered Raw Data needed)
--------------------------------------------------------------------------
See build_raw_data_from_manual() below: the user's Raw Data CSV already
has the Raw Data sheet's own columns (team, auto/teleop/climb breakdown,
total score, notes) plus a match number and alliance slot for each row,
so this is the Raw Data source directly. calculations.pipeline.build_all()
always uses this.
"""

from collections import defaultdict


def team_bps_averages(conn) -> dict[int, float]:
    """BPS!C column: average of each team's manually recorded samples."""
    sums: dict[int, list[float]] = defaultdict(list)
    for row in conn.execute("SELECT team_num, sample_value FROM bps_samples"):
        sums[row["team_num"]].append(row["sample_value"])
    return {team: (sum(vals) / len(vals) if vals else 0.0) for team, vals in sums.items()}


def _alliance_color(alliance: str) -> str:
    """'r1'/'r2'/'r3' -> 'r', 'b1'/'b2'/'b3' -> 'b' (LEFT(D,1) in the sheet)."""
    return (alliance or "").strip().lower()[:1]


def _fetch_match_schedule(conn) -> dict[int, dict]:
    out = {}
    for row in conn.execute("SELECT * FROM match_schedule"):
        out[row["match_num"]] = dict(row)
    return out


def _augment_unfiltered_rows(conn) -> list[dict]:
    """
    Reproduces Unfiltered Raw Data columns S..AC for every raw_scouting row.
    Returns a list of dicts (one per raw_scouting row) with the original
    fields plus: bps, auto_theory, teleop_theory, auto_alliance_theory,
    teleop_alliance_theory, actual_auto_balls, actual_teleop_balls,
    auto_contribution, teleop_contribution, auto_guess_balls,
    teleop_guess_balls.
    """
    bps_avg = team_bps_averages(conn)
    schedule = _fetch_match_schedule(conn)

    rows = [dict(r) for r in conn.execute("SELECT * FROM raw_scouting")]

    # T, S, U per row first (need alliance totals next)
    for r in rows:
        r["bps"] = bps_avg.get(r["team_num"], 0.0)
        r["auto_theory"] = (r["auto_shooting_time"] or 0.0) * r["bps"]
        r["teleop_theory"] = (r["teleop_shooting_time"] or 0.0) * r["bps"]

    # V, W: sum of S / U across the same match + alliance color
    group_auto: dict[tuple, float] = defaultdict(float)
    group_teleop: dict[tuple, float] = defaultdict(float)
    for r in rows:
        key = (r["match_num"], _alliance_color(r["alliance"]))
        group_auto[key] += r["auto_theory"]
        group_teleop[key] += r["teleop_theory"]

    for r in rows:
        key = (r["match_num"], _alliance_color(r["alliance"]))
        r["auto_alliance_theory"] = group_auto[key]
        r["teleop_alliance_theory"] = group_teleop[key]

        m = schedule.get(r["match_num"], {})
        is_red = _alliance_color(r["alliance"]) == "r"
        r["actual_auto_balls"] = (m.get("red_auto_balls") if is_red
                                   else m.get("blue_auto_balls")) or 0.0
        r["actual_teleop_balls"] = (m.get("red_teleop_balls") if is_red
                                     else m.get("blue_teleop_balls")) or 0.0

        r["auto_contribution"] = (
            r["auto_theory"] / r["auto_alliance_theory"]
            if r["auto_alliance_theory"] else 0.0
        )
        r["teleop_contribution"] = (
            r["teleop_theory"] / r["teleop_alliance_theory"]
            if r["teleop_alliance_theory"] else 0.0
        )
        r["auto_guess_balls"] = r["auto_contribution"] * r["actual_auto_balls"]
        r["teleop_guess_balls"] = r["teleop_contribution"] * r["actual_teleop_balls"]

    return rows


def build_raw_data(conn) -> list[dict]:
    """
    Reproduces the "Raw Data" sheet: one row per scouted robot per match,
    with fields: team_num, auto_balls, auto_climb_pts, teleop_balls,
    teleop_l1, teleop_l2, teleop_l3, score, notes, match_num, alliance.

    match_num/alliance are kept (not present as spreadsheet columns) so
    downstream calculations (Score Variance, Raw Data Processing) can
    order/attribute matches without re-deriving them.
    """
    unfiltered = _augment_unfiltered_rows(conn)
    # Preserve insertion/appearance order - this order defines "match
    # occurrence 1..15" for a team downstream, exactly like row order did
    # in the spreadsheet.
    out = []
    for r in unfiltered:
        auto_climb_pts = 15.0 if (r["auto_climb"] or "").strip().upper() == "CLIMB" else 0.0
        climb_level = (r["teleop_climb"] or "").strip()
        teleop_l1 = 10.0 if climb_level == "1" else 0.0
        teleop_l2 = 20.0 if climb_level == "2" else 0.0
        teleop_l3 = 30.0 if climb_level == "3" else 0.0

        auto_balls = r["auto_guess_balls"]
        teleop_balls = r["teleop_guess_balls"]

        total = auto_balls + auto_climb_pts + teleop_balls + teleop_l1 + teleop_l2 + teleop_l3
        score = total if total != 0 else 2.0  # sheet default-to-2 quirk

        out.append({
            "team_num": r["team_num"],
            "match_num": r["match_num"],
            "alliance": r["alliance"],
            "auto_balls": auto_balls,
            "auto_climb_pts": auto_climb_pts,
            "teleop_balls": teleop_balls,
            "teleop_l1": teleop_l1,
            "teleop_l2": teleop_l2,
            "teleop_l3": teleop_l3,
            "score": score,
            "notes": r.get("notes", ""),
        })
    return out


def build_raw_data_from_manual(conn) -> list[dict]:
    """
    Reproduces the same output shape as build_raw_data() - one dict per
    scouted robot per match with team_num, match_num, alliance,
    auto_balls, auto_climb_pts, teleop_balls, teleop_l1, teleop_l2,
    teleop_l3, score, notes - but reads it directly from the
    manual_raw_data table (a user-uploaded CSV shaped like the Raw Data
    sheet plus match/alliance columns) instead of deriving it from
    Unfiltered Raw Data + BPS.

    Rows are sorted chronologically by match_num (ties broken by id,
    i.e. import/appearance order) since every downstream calculation
    that windows "a team's first N matches" relies on that ordering,
    exactly like Raw Data's row order did in the spreadsheet.
    """
    rows = conn.execute(
        "SELECT * FROM manual_raw_data ORDER BY match_num ASC, id ASC"
    ).fetchall()

    out = []
    for r in rows:
        auto_balls = r["auto_balls"] or 0.0
        auto_climb_pts = r["auto_climb_pts"] or 0.0
        teleop_balls = r["teleop_balls"] or 0.0
        teleop_l1 = r["teleop_l1"] or 0.0
        teleop_l2 = r["teleop_l2"] or 0.0
        teleop_l3 = r["teleop_l3"] or 0.0

        total = auto_balls + auto_climb_pts + teleop_balls + teleop_l1 + teleop_l2 + teleop_l3
        # Honor an explicitly-provided Score column (it's the ground truth
        # the user actually recorded); only fall back to the sheet's
        # from-breakdown formula - including its "default to 2" quirk -
        # when Score was left blank.
        if r["score"] is not None:
            score = r["score"]
        else:
            score = total if total != 0 else 2.0

        out.append({
            "team_num": r["team_num"],
            "match_num": r["match_num"],
            "alliance": r["alliance"],
            "auto_balls": auto_balls,
            "auto_climb_pts": auto_climb_pts,
            "teleop_balls": teleop_balls,
            "teleop_l1": teleop_l1,
            "teleop_l2": teleop_l2,
            "teleop_l3": teleop_l3,
            "score": score,
            "notes": r["notes"] or "",
        })
    return out

"""
calculations/team_ability.py

Recreates "Team Ability Distribution": a handful of league-wide RPP
benchmarks used elsewhere as quality thresholds (most importantly, by
Alliance Builder Filtering to decide which teams are strong enough to be
worth listing as pick candidates at all).

    avg_rpp        = AVERAGE(every team's RPP)
    top4_avg_rpp   = AVERAGE(top 4 teams' RPP)
    top8_avg_rpp   = AVERAGE(top 8 teams' RPP)
    elims_avg_rpp  = AVERAGE(top N teams' RPP), N = 24 or 32 depending on
                     event alliance-selection format (ELIM_ALLIANCE_TEAMS)
    goal_ally_rpp  = (top8_avg_rpp + elims_avg_rpp) / 2
                     <- the threshold Alliance Builder Filtering uses
"""

from dataclasses import dataclass

# The sheet picks between two window sizes (24 or 32) based on a per-event
# setting (how many alliances make elims: 8 alliances * 3 = 24 teams is the
# standard FRC format; some larger events use more). Adjust if your event
# uses a non-standard alliance-selection bracket size.
ELIM_ALLIANCE_TEAMS = 24


@dataclass
class TeamAbilityBenchmarks:
    avg_rpp: float
    top4_avg_rpp: float
    top8_avg_rpp: float
    elims_avg_rpp: float
    goal_ally_rpp: float


def build_team_ability_distribution(rpp: dict) -> TeamAbilityBenchmarks:
    ranked = sorted(rpp.values(), key=lambda r: r.rpp, reverse=True)
    values = [r.rpp for r in ranked]

    def avg_top(n: int) -> float:
        top = values[:n]
        return (sum(top) / len(top)) if top else 0.0

    avg_rpp = avg_top(len(values))
    top4 = avg_top(4)
    top8 = avg_top(8)
    elims = avg_top(ELIM_ALLIANCE_TEAMS)
    goal = (top8 + elims) / 2.0

    return TeamAbilityBenchmarks(
        avg_rpp=avg_rpp, top4_avg_rpp=top4, top8_avg_rpp=top8,
        elims_avg_rpp=elims, goal_ally_rpp=goal,
    )

"""
calculations/pipeline.py

Runs every Stage-1 calculation in the same dependency order the
spreadsheet's formulas implied, and hands back one object the UI layer can
read from. This is the Python equivalent of Google Sheets recalculating
the whole workbook.

STAGE 1 (implemented here): Team Numbers -> Raw Data (from the manual
    Raw Data CSV import - see data_import.import_raw_data_csv) ->
    Auto/Teleop Balls Scored -> Score Variance -> Raw Data Processing ->
    Match Schedule "Adjusted" columns -> SQRT/Log10/1-over-X Methods ->
    Skew Adjusted Spreads.

    EXPERIMENT (see README.md "Experiment: Adjusted Score Variance
    removed"): "Adjusted Score Variance" is deliberately NOT computed
    or used here anymore, at the user's request, to test how much
    difference it actually makes versus using plain Score Variance
    everywhere downstream. Score Variance is known-correct (verified
    against the source spreadsheet); Adjusted Score Variance was only a
    minor apportionment adjustment on top of it, and testing on the
    real spreadsheet showed the impact of that adjustment was small.
    Raw Data Processing is still computed - it's still needed for
    Defense Adjustment / Average Compatability / RDP, which are a
    different calculation, not Adjusted Score Variance - but its
    per-match "adjusted_score" values are no longer fed into anything.
    `score_variance.build_adjusted_score_variance()` still exists and
    is a one-line change to bring back (see the README section above).

STAGE 2 (not yet implemented - see README.md): Skew Distributions,
    Normalized Distributions (the actual skew-normal curve fitting
    described in the algorithm PDF).

STAGE 3 (not yet implemented - see README.md): Defense Calculations,
    Defense Adjustment, Average Compatability, ROP, RDP, RPP,
    Blue/Red/Base Alliance Generators, Match Odds, Alliance Builder
    Filtering, Team Ability Distribution, Rankings, Pick List.

Re-run build_all() any time the underlying data changes (after an import,
or when the user clicks "Recalculate" in the UI) - it is cheap enough to
run on every app launch for realistic scouting-dataset sizes.
"""

from dataclasses import dataclass

from database import get_connection
from calculations import (
    team_roster, raw_processing, balls_scored, score_variance, skew_methods,
    distributions, defense, power_rankings, team_ability, pick_list,
)


@dataclass
class ComputedData:
    raw_data_rows: list[dict]
    roster: list[team_roster.TeamRosterEntry]
    auto_balls_scored: dict
    teleop_balls_scored: dict
    score_variance: dict
    raw_data_processing: list
    sqrt_method: dict
    log10_method: dict
    onex_method: dict
    skew_adjusted_spreads: dict
    # Stage 2
    skew_distribution_curves: dict
    normalized_distributions: dict
    defense_calculations: dict
    defense_adjustment: dict
    average_compatability: dict
    # Stage 3
    rop: dict
    rdp: dict
    rpp: dict
    team_ability: object
    pick_list: list
    my_team_num: int | None


def build_all(my_team_num: int | None = None) -> ComputedData:
    with get_connection() as conn:
        # Raw Data comes from the manual Raw-Data-shaped CSV import - the
        # sole Raw Data source in this app (see data_import.import_raw_data_csv
        # and raw_processing.build_raw_data_from_manual).
        raw_data_rows = raw_processing.build_raw_data_from_manual(conn)
        roster = team_roster.build_team_roster(conn, raw_data_rows)

        auto_bs = balls_scored.build_auto_balls_scored(raw_data_rows)
        teleop_bs = balls_scored.build_teleop_balls_scored(raw_data_rows)

        sv = score_variance.build_score_variance(raw_data_rows)
        # Still needed for Defense Adjustment / Average Compatability / RDP
        # (own_alliance_ratio / opponent_alliance_ratio) - unrelated to the
        # experiment above, since those aren't Adjusted Score Variance.
        rdp_rows_raw = score_variance.build_raw_data_processing(conn, raw_data_rows, sv)

        # EXPERIMENT: everywhere Adjusted Score Variance used to be passed
        # downstream, plain Score Variance (sv) is passed instead - see the
        # module docstring above and README.md.
        sqrt_m, log10_m, onex_m = skew_methods.build_transform_methods(sv)
        sas = skew_methods.build_skew_adjusted_spreads(sv, sqrt_m, log10_m, onex_m)

        # Stage 2
        raw_curves = distributions.build_skew_distributions(sv, sas)
        norm_dists = distributions.build_normalized_distributions(sv, raw_curves)
        defense_calc = defense.build_defense_calculations(sv)
        defense_adj = defense.build_defense_adjustment(rdp_rows_raw)
        avg_compat = defense.build_average_compatability(rdp_rows_raw)

        # Stage 3
        rop = power_rankings.build_rop(auto_bs, teleop_bs, sv, avg_compat)
        _, opp_ratio_by_team = defense.team_ratio_lists(rdp_rows_raw)
        rdp = power_rankings.build_rdp(opp_ratio_by_team, defense_calc)
        rpp = power_rankings.build_rpp(rop, rdp, defense_calc, sv)
        ability = team_ability.build_team_ability_distribution(rpp)
        team_nums = [t.team_num for t in roster]
        picks = pick_list.build_pick_list(
            team_nums, my_team_num, rpp, sv, ability.goal_ally_rpp,
        )

    return ComputedData(
        raw_data_rows=raw_data_rows,
        roster=roster,
        auto_balls_scored=auto_bs,
        teleop_balls_scored=teleop_bs,
        score_variance=sv,
        raw_data_processing=rdp_rows_raw,
        sqrt_method=sqrt_m,
        log10_method=log10_m,
        onex_method=onex_m,
        skew_adjusted_spreads=sas,
        skew_distribution_curves=raw_curves,
        normalized_distributions=norm_dists,
        defense_calculations=defense_calc,
        defense_adjustment=defense_adj,
        average_compatability=avg_compat,
        rop=rop,
        rdp=rdp,
        rpp=rpp,
        team_ability=ability,
        pick_list=picks,
        my_team_num=my_team_num,
    )

"""
calculations/alliance_generator.py

Recreates "Alliance Base Generator" and "Blue/Red Alliance Generator":
combining three teammates' individual Normalized Distributions curves
(Stage 2) into one alliance-level combined score distribution, without a
full Monte Carlo simulation - matching the PDF's stated goal of using the
already-fitted curves directly instead of simulating.

--------------------------------------------------------------------------
The combination method (traced from the sheet formulas)
--------------------------------------------------------------------------
Each teammate's normalized curve is unimodal (rises to a peak of 1 at its
mode, then falls). The sheet splits each teammate's curve at its own mode
into two monotonic branches:
    ascending  branch: x < mode, curve rising   (see _split_branches for
                                                    the real point order -
                                                    it is NOT left-to-right)
    descending branch: x >= mode, curve falling  (points ordered left-to-right,
                                                    starting at the peak)

To combine three teammates, the sheet pairs up the i-th point of each
teammate's ascending branch together (and separately, the i-th point of
each descending branch), rank-position by rank-position rather than by
matching x-values or a true convolution:

    combined_point_value(i) = x_A(i) + x_B(i) + x_C(i)
    combined_density(i)     = (y_A(i) + y_B(i) + y_C(i)) / 3

A teammate whose branch is shorter than another's contributes 0 for the
remaining ranks once its branch is exhausted (matching the sheet's
IF(range="",0,range) coercion) rather than stopping the whole sum - this
is a real quirk of the source formulas, not a bug in this port. Getting
each branch's point ORDER right (see _split_branches) is what keeps this
zero-padding confined to the sparse tail farthest from each teammate's own
mode, rather than landing right next to it.

This produces a list of (point_value, density) samples approximating the
alliance's combined score distribution. Blue/Red Alliance Generator then
sorts these by point_value and looks each integer score up by EXACT match
(scores with no exact sample stay at density 0) to build an empirical
frequency curve, one entry per possible final score over ALLIANCE_X_AXIS_MAX
(see below) - this became column "F" that Match Odds reads from.

--------------------------------------------------------------------------
Two real bugs found and fixed here (see git history / README for detail)
--------------------------------------------------------------------------
1. Ascending-branch point order. An earlier version of this file built
   the ascending branch in plain left-to-right (x-ascending) order. The
   sheet's own formulas (Alliance Base Generator's "Lower" columns
   AE:AG, via a SORT(..., SEQUENCE(n), FALSE()) trick that reverses the
   natural FILTER order) actually order it the opposite way: starting
   right next to the mode and moving outward to the team's minimum score.
   Left in x-ascending order, a teammate with a narrower ascending branch
   got zero-padded starting right next to its OWN mode - i.e. exactly in
   its most heavily-weighted region - which silently dropped that
   teammate's contribution from most of the alliance's high-density
   combined samples. Fixed by reversing the ascending branch in
   _split_branches().
2. Alliance-axis truncation. Both this port and the ORIGINAL sheet build
   the combined-alliance empirical curve over the same 1..500 axis used
   for a single robot's score - but a combined 3-robot sample can run up
   to 3x a single robot's max. Confirmed directly against
   FORMULA_EXPORT: 'Alliance Base Generator's own cached combined
   point-value samples commonly exceed 500 (median ~670, max seen
   ~1079 in the season's real data), meaning the majority of an
   alliance's real combined-score probability mass was landing nowhere on
   a 1..500 axis and getting silently dropped - in the live sheet too, not
   just this port. Fixed by giving the alliance-level curve its own,
   wider axis (ALLIANCE_X_AXIS_MAX = 3 * X_AXIS_MAX) sized to the true
   maximum a 3-robot combination can reach.
Together these two bugs were the root cause of Match Lookup's expected
scores coming out far below real match scores - fixing #1 alone
barely moved the number for any match whose real combined score already
exceeded 500, because most of its probability mass was still being cut
off by #2.

--------------------------------------------------------------------------
A note on this implementation's alliance attribution
--------------------------------------------------------------------------
The source sheet cross-labels these curves (e.g. "Blue Alliance
Generator" is actually built from the RED alliance's three curves, framed
as "the score Blue needs to clear to win"). That cross-labeling could not
be confirmed with full certainty from static formula analysis alone. This
port instead builds each alliance's combined distribution directly from
its OWN three teammates - mathematically equivalent for computing win
probability, and unambiguous. If you validate this against a known match
in the original sheet and the win percentages don't line up, that
labeling is the first place to check.
"""

from dataclasses import dataclass

from calculations.distributions import TeamDistribution, X_AXIS_MIN, X_AXIS_MAX

# The sheet's "Blue/Red Alliance Generator" tabs build their point-value
# axis (column A) as a literal 1..500 - the SAME 500-row range used for a
# single robot's Skew/Normalized Distributions - and then VLOOKUP each
# combined (3-robot) sample's point_value into that same 1..500 axis to
# build the empirical curve Match Odds reads from. Any combined sample
# whose point_value falls outside 1..500 simply has nowhere to land and is
# silently dropped from that curve entirely (not clipped to the boundary -
# gone, along with its probability mass).
#
# This is a real limitation of the ORIGINAL sheet, not something
# introduced by this port - confirmed directly against
# FORMULA_EXPORT: 'Alliance Base Generator's own cached combined
# point-value samples (columns W/AI, the per-alliance "Point Value"
# columns) run as high as ~1079 with a median around ~670 for this
# season's data, meaning the majority of an alliance's real combined-score
# probability mass never even has a chance to reach the 1..500 axis in the
# live sheet, let alone this port. A single robot's score routinely tops
# out well under X_AXIS_MAX (500), but summing three robots' scores
# together very often exceeds it.
#
# Since a combined alliance sample is the sum of three individual robot
# x-values, each of which is itself bounded to [X_AXIS_MIN, X_AXIS_MAX] by
# construction (calculations.distributions), the true maximum possible
# combined value is exactly 3 * X_AXIS_MAX. Using that as the alliance
# axis's upper bound (instead of reusing the single-robot X_AXIS_MAX)
# costs nothing - the extra rows are simply 0 wherever no team's scores
# actually reach that high - and it captures every real combined sample
# instead of quietly discarding most of them. match_odds.py only assumes
# both alliances' empirical_curve lists share the same length and start at
# X_AXIS_MIN, which still holds here.
ALLIANCE_X_AXIS_MAX = 3 * X_AXIS_MAX


@dataclass
class AllianceDistribution:
    team_nums: tuple[int, int, int]
    samples: list[tuple[float, float]]   # (point_value, density), unsorted
    empirical_curve: list[float]         # density per integer x, X_AXIS_MIN..ALLIANCE_X_AXIS_MAX


def _split_branches(dist: TeamDistribution) -> tuple[list[tuple[float, float]], list[tuple[float, float]]]:
    """Returns (ascending_branch, descending_branch) as (x, y) point lists, y > 0 only.

    Ordering matters here and is NOT simply "left to right" for the
    ascending branch. Traced from the sheet's own formulas (Alliance Base
    Generator, "Lower" columns AE:AG): the ascending-branch density values
    are first collected in natural x order (low x -> mode), then passed
    through SORT(values, SEQUENCE(n), FALSE()) - sorting by an increasing
    1..n key in descending order, which simply REVERSES the list. So the
    sheet's actual "Lower" branch is ordered starting from the point
    closest to the mode (highest density) outward to the team's minimum
    score (lowest density) - the mirror image of the descending/"Upper"
    branch, which the sheet leaves in natural order (mode outward to the
    team's max/cutoff score, via a plain FILTER with no SORT).

    This ordering is what makes the later rank-by-rank combination
    (_combine_branches) line up three teammates' curves by "distance from
    each one's own mode" on BOTH sides, not just the descending side. Left
    in natural x-ascending order (as an earlier version of this file did),
    a teammate with a narrower ascending branch gets zero-padded starting
    right next to its own mode - i.e. zeroed out exactly in its most
    heavily-weighted, most-likely-score region - which silently drops that
    teammate's real contribution from most of the alliance's combined
    high-density samples and can make the alliance's expected score come
    out far lower than reality. Reversing the ascending branch here (to
    match the sheet) instead pushes any zero-padding out to the sparse,
    low-density tail near each team's minimum score, where it belongs.
    """
    ascending, descending = [], []
    for x, y in zip(dist.x_values, dist.normalized_curve):
        if y <= 0:
            continue
        if x < dist.mode_x:
            ascending.append((float(x), y))
        else:
            descending.append((float(x), y))
    ascending.reverse()
    return ascending, descending


def _combine_branches(branches: list[list[tuple[float, float]]]) -> list[tuple[float, float]]:
    max_len = max((len(b) for b in branches), default=0)
    samples = []
    for i in range(max_len):
        xs = [b[i][0] if i < len(b) else 0.0 for b in branches]
        ys = [b[i][1] if i < len(b) else 0.0 for b in branches]
        samples.append((sum(xs), sum(ys) / len(branches)))
    return samples


def build_alliance_distribution(
    team_distributions: tuple[TeamDistribution, TeamDistribution, TeamDistribution],
) -> AllianceDistribution:
    ascending_branches, descending_branches = [], []
    for dist in team_distributions:
        asc, desc = _split_branches(dist)
        ascending_branches.append(asc)
        descending_branches.append(desc)

    lower_samples = _combine_branches(ascending_branches)
    upper_samples = _combine_branches(descending_branches)
    samples = lower_samples + upper_samples

    # Exact-match lookup onto the integer score axis (matches the sheet's
    # VLOOKUP exact-match behaviour) - first sample found wins on ties.
    lookup: dict[int, float] = {}
    for point_value, density in samples:
        key = round(point_value)
        if key not in lookup:
            lookup[key] = density

    empirical_curve = [lookup.get(x, 0.0) for x in range(X_AXIS_MIN, ALLIANCE_X_AXIS_MAX + 1)]

    return AllianceDistribution(
        team_nums=tuple(d.team_num for d in team_distributions),
        samples=samples,
        empirical_curve=empirical_curve,
    )

"""
calculations/pick_list.py

Recreates "Alliance Builder Filtering": the sheet that actually powers
the Pick List tab. Splits every team (other than your own) into two
buckets based on whether their RPP clears the Team Ability Distribution's
"Goal Ally RPP" bar, then ranks each bucket separately.

    quality_ratio = Score Variance!AVG / Score Variance!STDEV
                    (only computed for teams at/above the RPP bar)
    top_picks     = teams at/above the bar, sorted by quality_ratio desc
    other_picks   = teams below the bar, sorted by ROP desc
                    (a fallback list - "best of the rest")

The final Pick List is top_picks followed by other_picks.
"""

from dataclasses import dataclass


@dataclass
class PickListEntry:
    team_num: int
    quality_ratio: float | None  # None for "other" (below-bar) picks
    rop: float
    is_top_pick: bool


def build_pick_list(
    roster_teams: list[int],
    my_team_num: int | None,
    rpp: dict,
    score_variance: dict,
    goal_ally_rpp: float,
) -> list[PickListEntry]:
    top_picks: list[PickListEntry] = []
    other_picks: list[PickListEntry] = []

    for team in roster_teams:
        if my_team_num is not None and team == my_team_num:
            continue

        rpp_row = rpp.get(team)
        sv_row = score_variance.get(team)
        rop_val = rpp_row.rop if rpp_row else 0.0

        clears_bar = (rpp_row is not None) and (rpp_row.rpp >= goal_ally_rpp)
        if clears_bar and sv_row and sv_row.stdev:
            ratio = sv_row.avg / sv_row.stdev
            top_picks.append(PickListEntry(
                team_num=team, quality_ratio=ratio, rop=rop_val, is_top_pick=True,
            ))
        else:
            other_picks.append(PickListEntry(
                team_num=team, quality_ratio=None, rop=rop_val, is_top_pick=False,
            ))

    top_picks.sort(key=lambda e: e.quality_ratio, reverse=True)
    other_picks.sort(key=lambda e: e.rop, reverse=True)

    return top_picks + other_picks

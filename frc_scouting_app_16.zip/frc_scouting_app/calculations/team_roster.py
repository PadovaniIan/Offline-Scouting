"""
calculations/team_roster.py

Recreates the "Team Numbers" sheet.

Sheet reference:
    Team Numbers!A  = team number (manually maintained list)
    Team Numbers!E  = =COUNTIF('Raw Data'!A:A, A2)   -> match count for team

Since Raw Data doesn't exist as its own table in this app (it's derived -
see raw_processing.py), "count" here means: number of Raw Data rows for
that team, i.e. len(raw_processing.build_raw_data() filtered by team),
which is exactly what COUNTIF('Raw Data'!A:A, team) measured in the sheet.
"""

from dataclasses import dataclass


@dataclass
class TeamRosterEntry:
    team_num: int
    team_name: str | None
    match_count: int


def build_team_roster(conn, raw_data_rows: list[dict]) -> list[TeamRosterEntry]:
    """
    raw_data_rows: output of calculations.raw_processing.build_raw_data()
                   (each dict has a "team_num" key)
    """
    from database import known_team_numbers

    counts: dict[int, int] = {}
    for row in raw_data_rows:
        counts[row["team_num"]] = counts.get(row["team_num"], 0) + 1

    names = {}
    for r in conn.execute("SELECT team_num, team_name FROM team_roster"):
        names[r["team_num"]] = r["team_name"]

    roster = []
    for team in known_team_numbers(conn):
        roster.append(
            TeamRosterEntry(
                team_num=team,
                team_name=names.get(team),
                match_count=counts.get(team, 0),
            )
        )
    return roster

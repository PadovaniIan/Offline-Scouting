"""
calculations/score_variance.py

Recreates four sheets, in dependency order:

    1. "Score Variance"        - per-team chronological Raw Data!H (Score)
                                  history + stats.
    2. "Raw Data Processing"   - per-match, per-alliance-slot: this robot's
                                  own-alliance performance ratio and the
                                  OPPOSING alliance's performance ratio
                                  (used later as a defense proxy).
    3. Match Schedule columns N-S ("Adjusted Red/Blue 1/2/3") - each
                                  robot's share of its alliance's *actual*
                                  recorded score, apportioned by its raw
                                  scouted score relative to its two
                                  alliance partners.

                                  Judgment call: the sheet always has a
                                  real recorded alliance score to
                                  apportion against. This offline app lets
                                  match_schedule.red_score/blue_score
                                  arrive later (e.g. via a separate Match
                                  Schedule CSV import, or never, for
                                  practice/synthetic data), so when that
                                  cell is still NULL for a match, this
                                  falls back to using each robot's raw
                                  scouted score as-is (apportionment
                                  ratio 1.0) instead of collapsing to 0 -
                                  otherwise every downstream stage
                                  (Skew Adjusted Spreads, fitted curves,
                                  ROP/RDP/RPP, Match Odds) would be zeroed
                                  out until official scores are imported.
                                  Once a real red_score/blue_score is
                                  present, the exact original apportioned
                                  formula is used, matching the sheet.
    4. "Adjusted Score Variance" - per-team chronological history of the
                                  Adjusted values from step 3, plus the
                                  logic that picks which of 4 skew-reducing
                                  transforms (see skew_methods.py) best
                                  normalizes that team's distribution.

Everything here reads only from build_raw_data() (calculations.raw_processing)
and the match_schedule table - no spreadsheet XLOOKUP/COUNTIF tricks are
needed because Raw Data rows already carry their real match_num, so we can
join team+match directly instead of reconstructing "occurrence index".
"""

from collections import defaultdict
from dataclasses import dataclass

from calculations.matrix_stats import build_team_matrix, TeamMatrixRow


# ---------------------------------------------------------------------
# 1. Score Variance
# ---------------------------------------------------------------------

def build_score_variance(raw_data_rows: list[dict]) -> dict[int, TeamMatrixRow]:
    """Per-team chronological Raw Data 'score' history + stats.

    Capped to each team's first 15 chronological matches - the sheet's
    Score Variance tab only has 15 match columns (B:P), and later sheets
    (Raw Data Processing's occurrence-indexed XLOOKUP - see
    build_raw_data_processing below) depend on this cap matching
    exactly, since a lookup past column P is a #N/A there (silently
    caught by IFERROR and treated as 0).
    """
    by_team: dict[int, list[float]] = defaultdict(list)
    # raw_data_rows is already in appearance/chronological order
    for row in raw_data_rows:
        by_team[row["team_num"]].append(row["score"])
    by_team = {team: values[:15] for team, values in by_team.items()}
    return build_team_matrix(by_team, stdev_offset=0.0, include_skew=True)


# ---------------------------------------------------------------------
# 2 & 3. Raw Data Processing + Match Schedule "Adjusted" columns
# ---------------------------------------------------------------------

@dataclass
class AdjustedMatchRow:
    match_num: int
    team_num: int
    alliance: str          # 'red' or 'blue'
    raw_score: float
    adjusted_score: float  # this robot's apportioned share of the real score
    own_alliance_ratio: float       # Raw Data Processing col J (red) / T (blue)
    opponent_alliance_ratio: float  # the other alliance's ratio for this match


def build_raw_data_processing(conn, raw_data_rows: list[dict],
                               score_variance: dict[int, TeamMatrixRow],
                               ) -> list[AdjustedMatchRow]:
    """
    IMPORTANT - this does NOT simply look up "this team's raw score for
    this match" by (team, match) key, even though that would seem like
    the obvious/direct translation. The sheet's own D/E/F (red) and
    N/O/P (blue) columns instead go through an indirect,
    occurrence-count-based lookup:

        COUNTIF({$A$3:$C<row>,$K$3:$M<row>}, <team>)
            -> XLOOKUP(that count, 'Score Variance'!$B$2:$P$2,
                       FILTER('Score Variance'!row for this team))

    i.e. "how many times has this team appeared anywhere in Match
    Schedule's 6 team columns, from the top of the schedule through
    this row?" gives an occurrence index K, and the sheet then takes
    the K-th value from that team's Score Variance history (columns
    B:P, chronological, capped at 15 - see build_score_variance).

    This is NOT equivalent to a direct (team, match) lookup whenever a
    team has a schedule appearance with no corresponding Raw Data row
    (a match that was never scouted for that team, but still appears
    in Match Schedule). In that case K counts the missing match, but
    Score Variance's history doesn't have an entry for it - so every
    subsequent occurrence index for that team is silently shifted by
    one, and the sheet ends up pulling a LATER match's score in place
    of the current match's. This is a genuine quirk of the source
    spreadsheet's formula design (not a translation bug), but it's
    real, reproducible, and affects Adjusted Score Variance - so it is
    replicated exactly here rather than "corrected", since the goal is
    to match the sheet's actual output.
    """
    # Per-team, chronological, 15-capped raw-score history - exactly
    # the values sitting in that team's Score Variance row (B:P).
    sv_values = {team: mr.values for team, mr in score_variance.items()}

    team_avg = {team: mr.avg for team, mr in score_variance.items()}

    out: list[AdjustedMatchRow] = []
    matches = conn.execute(
        "SELECT * FROM match_schedule ORDER BY match_num"
    ).fetchall()

    # Running "how many times has this team appeared in the schedule so
    # far" counter - mirrors the sheet's growing COUNTIF range that runs
    # from the first schedule row through the current one.
    occurrence_count: dict[int, int] = defaultdict(int)

    for m in matches:
        red_teams = [m["red1"], m["red2"], m["red3"]]
        blue_teams = [m["blue1"], m["blue2"], m["blue3"]]

        # If a team appears more than once within THIS SAME match row (a
        # data anomaly, but it happens in real exports), the sheet's
        # COUNTIF range covers the whole row at once regardless of which
        # column is being evaluated - so every slot holding that team in
        # this row shares the SAME occurrence index. Bump the counter
        # once per team (not once per slot) before resolving any of
        # this row's raw scores.
        row_teams = [t for t in (red_teams + blue_teams) if t]
        for team in set(row_teams):
            occurrence_count[team] += row_teams.count(team)

        def raw_for(team):
            if not team:
                return 0.0
            k = occurrence_count[team]
            vals = sv_values.get(team, [])
            if 1 <= k <= len(vals):
                return vals[k - 1]
            return 0.0  # matches IFERROR(...,0) when the occurrence has

        red_raw = [raw_for(t) for t in red_teams]
        blue_raw = [raw_for(t) for t in blue_teams]

        red_avgs = [team_avg.get(t, 0.0) if t else 0.0 for t in red_teams]
        blue_avgs = [team_avg.get(t, 0.0) if t else 0.0 for t in blue_teams]

        # J3 / T3 : alliance performance ratio = sum(raw) / sum(team avgs)
        red_avg_sum = sum(red_avgs)
        blue_avg_sum = sum(blue_avgs)
        red_ratio = (sum(red_raw) / red_avg_sum) if red_avg_sum else 0.0
        blue_ratio = (sum(blue_raw) / blue_avg_sum) if blue_avg_sum else 0.0

        red_raw_sum = sum(red_raw)
        blue_raw_sum = sum(blue_raw)

        for team, raw in zip(red_teams, red_raw):
            if not team:
                continue
            if m["red_score"] is None:
                adjusted = raw  # no official score imported yet - use raw as-is
            else:
                adjusted = (raw / red_raw_sum) * m["red_score"] if red_raw_sum else 0.0
            out.append(AdjustedMatchRow(
                match_num=m["match_num"], team_num=team, alliance="red",
                raw_score=raw, adjusted_score=adjusted,
                own_alliance_ratio=red_ratio,
                opponent_alliance_ratio=blue_ratio,
            ))
        for team, raw in zip(blue_teams, blue_raw):
            if not team:
                continue
            if m["blue_score"] is None:
                adjusted = raw  # no official score imported yet - use raw as-is
            else:
                adjusted = (raw / blue_raw_sum) * m["blue_score"] if blue_raw_sum else 0.0
            out.append(AdjustedMatchRow(
                match_num=m["match_num"], team_num=team, alliance="blue",
                raw_score=raw, adjusted_score=adjusted,
                own_alliance_ratio=blue_ratio,
                opponent_alliance_ratio=red_ratio,
            ))

    return out


# ---------------------------------------------------------------------
# 4. Adjusted Score Variance (+ skew-method picker)
# ---------------------------------------------------------------------

@dataclass
class AdjustedScoreVarianceRow:
    team_num: int
    matrix: TeamMatrixRow
    chosen_method: int   # 1=raw adjusted values, 2=SQRT, 3=Log10, 4=1/X


def build_adjusted_score_variance(
    adjusted_rows: list[AdjustedMatchRow],
) -> dict[int, TeamMatrixRow]:
    """Per-team chronological history of 'adjusted' scores + stats."""
    by_team: dict[int, list[tuple[int, float]]] = defaultdict(list)
    for r in adjusted_rows:
        by_team[r.team_num].append((r.match_num, r.adjusted_score))

    values_by_team = {}
    for team, pairs in by_team.items():
        pairs.sort(key=lambda p: p[0])  # chronological, as SORT(...) does
        values_by_team[team] = [v for _, v in pairs][:15]

    return build_team_matrix(values_by_team, stdev_offset=0.0, include_skew=True)

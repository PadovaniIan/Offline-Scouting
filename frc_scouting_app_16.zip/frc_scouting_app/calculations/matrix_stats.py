"""
calculations/matrix_stats.py

Shared statistics used identically across many "team x up-to-15-matches"
sheets (Auto Balls Scored, Teleop Balls Scored, Score Variance, Adjusted
Score Variance, SQRT/Log10/1-over-X Method, Defense Adjustment, Average
Compatability, RDP). Each of those sheets lays a team's chronological
per-match values across columns B:P (max 15 matches) then computes:

    Min      = SMALL(values, 2)      2nd-smallest (drops one low outlier)
    Max      = LARGE(values, 2)      2nd-largest  (drops one high outlier)
    STDEV    = sample standard deviation (Google Sheets STDEV = ddof=1)
    AVG      = mean
    AVG/STDEV= AVG / (STDEV + stdev_offset)     [offset is 1 on some
                                                   sheets, 0 on others -
                                                   see call sites]
    RRP      = AVG / MAX(every team's AVG on that sheet)
    Skew     = sample skewness (Google Sheets SKEW function)

Google Sheets' SKEW() is the adjusted Fisher-Pearson standardized moment
coefficient:  skew = [n / ((n-1)(n-2))] * sum(((x - mean)/stdev)^3)
"""

from dataclasses import dataclass, field
import math


@dataclass
class TeamMatrixRow:
    team_num: int
    values: list[float]          # chronological per-match values, <=15
    min2: float = 0.0
    max2: float = 0.0
    stdev: float = 0.0
    avg: float = 0.0
    avg_over_stdev: float = 0.0
    rrp: float = 0.0
    skew: float = 0.0


def _sample_stdev(values: list[float]) -> float:
    n = len(values)
    if n < 2:
        return 0.0
    mean = sum(values) / n
    var = sum((v - mean) ** 2 for v in values) / (n - 1)
    return math.sqrt(var)


def _sheets_skew(values: list[float]) -> float:
    """Google Sheets SKEW(): adjusted Fisher-Pearson coefficient."""
    n = len(values)
    if n < 3:
        return 0.0
    mean = sum(values) / n
    sd = _sample_stdev(values)
    if sd == 0:
        return 0.0
    m3 = sum(((v - mean) / sd) ** 3 for v in values)
    return (n / ((n - 1) * (n - 2))) * m3


def _small_nth(values: list[float], n: int) -> float:
    """SMALL(range, n): the n-th smallest value (1-indexed)."""
    s = sorted(values)
    if len(s) < n:
        return s[-1] if s else 0.0
    return s[n - 1]


def _large_nth(values: list[float], n: int) -> float:
    """LARGE(range, n): the n-th largest value (1-indexed)."""
    s = sorted(values, reverse=True)
    if len(s) < n:
        return s[-1] if s else 0.0
    return s[n - 1]


def build_team_matrix(
    team_values: dict[int, list[float]],
    stdev_offset: float = 0.0,
    include_skew: bool = True,
) -> dict[int, TeamMatrixRow]:
    """
    team_values: {team_num: [chronological per-match values]}
    stdev_offset: added to STDEV before dividing AVG by it (1.0 for the
                  Auto/Teleop Balls Scored sheets, 0.0 everywhere else).
    """
    rows: dict[int, TeamMatrixRow] = {}
    for team, values in team_values.items():
        clean = [v for v in values if v is not None]
        stdev = _sample_stdev(clean)
        avg = sum(clean) / len(clean) if clean else 0.0
        rows[team] = TeamMatrixRow(
            team_num=team,
            values=clean,
            min2=_small_nth(clean, 2) if clean else 0.0,
            max2=_large_nth(clean, 2) if clean else 0.0,
            stdev=stdev,
            avg=avg,
            avg_over_stdev=(avg / (stdev + stdev_offset)) if (stdev + stdev_offset) else 0.0,
            skew=_sheets_skew(clean) if include_skew else 0.0,
        )

    max_avg = max((r.avg for r in rows.values()), default=0.0)
    for r in rows.values():
        r.rrp = (r.avg / max_avg) if max_avg else 0.0

    return rows

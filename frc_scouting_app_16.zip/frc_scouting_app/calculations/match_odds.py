"""
calculations/match_odds.py

Recreates "Match Odds": turns two alliances' empirical combined-score
curves (calculations.alliance_generator) into a win probability, using
the same discretized cumulative-sum approach as the sheet -
P(A wins) is built by summing, over every possible score x:
    P(A scores >= x) * P(B scores <= x)
and likewise with A/B swapped for B's win curve; the two totals are then
normalized against each other into a single win percentage.
"""

from dataclasses import dataclass

from calculations.alliance_generator import AllianceDistribution


@dataclass
class MatchOddsResult:
    alliance_a_win_probability: float
    alliance_b_win_probability: float
    expected_score_a: float
    expected_score_b: float


def _suffix_sums(values: list[float]) -> list[float]:
    """suffix_sums[i] = sum(values[i:])"""
    out = [0.0] * (len(values) + 1)
    for i in range(len(values) - 1, -1, -1):
        out[i] = out[i + 1] + values[i]
    return out


def _prefix_sums(values: list[float]) -> list[float]:
    """prefix_sums[i] = sum(values[:i+1])"""
    out = [0.0] * len(values)
    running = 0.0
    for i, v in enumerate(values):
        running += v
        out[i] = running
    return out


def compute_match_odds(
    alliance_a: AllianceDistribution, alliance_b: AllianceDistribution,
) -> MatchOddsResult:
    freq_a = alliance_a.empirical_curve
    freq_b = alliance_b.empirical_curve
    n = len(freq_a)

    total_a = sum(freq_a) or 1.0
    total_b = sum(freq_b) or 1.0

    suffix_a = _suffix_sums(freq_a)   # P(A >= x), unnormalized
    suffix_b = _suffix_sums(freq_b)
    prefix_a = _prefix_sums(freq_a)   # P(A <= x), unnormalized
    prefix_b = _prefix_sums(freq_b)

    a_wins_score = 0.0
    b_wins_score = 0.0
    for i in range(n):
        p_a_at_least = suffix_a[i] / total_a
        p_b_at_most = prefix_b[i] / total_b
        a_wins_score += p_a_at_least * p_b_at_most

        p_b_at_least = suffix_b[i] / total_b
        p_a_at_most = prefix_a[i] / total_a
        b_wins_score += p_b_at_least * p_a_at_most

    denom = a_wins_score + b_wins_score
    if denom > 0:
        p_a = a_wins_score / denom
        p_b = b_wins_score / denom
    else:
        p_a = p_b = 0.5

    x_axis_start = 1
    expected_a = sum((x_axis_start + i) * f for i, f in enumerate(freq_a)) / total_a
    expected_b = sum((x_axis_start + i) * f for i, f in enumerate(freq_b)) / total_b

    return MatchOddsResult(
        alliance_a_win_probability=p_a,
        alliance_b_win_probability=p_b,
        expected_score_a=expected_a,
        expected_score_b=expected_b,
    )

"""
calculations/defense.py

Recreates three sheets that all read from data Stage 1 already computed
(Score Variance, and the per-match own/opponent alliance ratios from
Raw Data Processing) - no new raw data needed, just new statistics on
data structures the pipeline already builds.

--------------------------------------------------------------------------
Defense Calculations sheet
--------------------------------------------------------------------------
Fits a trend line (SLOPE) through each team's first 12 chronological raw
scores (Score Variance!B3:M3 against the constant index 1..12), then
looks at how far each of those 12 scores falls from that trend line
("residual"). A team whose residuals trend consistently down over a
season, or dip sharply on specific matches, is read as a defense signal.

    slope          = SLOPE(first 12 raw scores, index 1..12)
    residual_i     = raw_i - (slope*i + (team_avg - slope*12))
    defensive_var  = (sum(residuals) - min(residuals)) / (count(residuals) - 1)
                     [trimmed mean dropping the single worst residual]
    RRP            = min-max normalize defensive_var across all teams

--------------------------------------------------------------------------
Defense Adjustment sheet
--------------------------------------------------------------------------
Per team, per match, "how much did the OPPOSING alliance underperform
their own expectation" (Raw Data Processing's opponent_alliance_ratio) -
a proxy for how much defense this team played, since a well-defended
opponent alliance scores below its own average expectation.

    min2/max2 = 2nd smallest / 2nd largest opponent ratio
    avg       = AVERAGE(min2, max2)          <- NOT the mean of all matches
    adj_avg   = 1 - abs(1 - avg)
    RRP       = min-max normalize adj_avg across all teams
    skew      = SKEW(all opponent ratios)

--------------------------------------------------------------------------
Average Compatability sheet
--------------------------------------------------------------------------
Per team, per match, "how well did MY OWN alliance perform relative to
expectation" (Raw Data Processing's own_alliance_ratio) - a proxy for how
this team's presence affects overall alliance efficiency. The sheet
intentionally drops the first chronological match before computing stats.

    values (excl. 1st match) -> min2, max2, stdev
    avg  = AVERAGE(values excl. 1st match) - 1     <- centered on 0
    ratio = avg / stdev
    RRP  = min-max normalize ratio across all teams
"""

from collections import defaultdict
from dataclasses import dataclass

from calculations.matrix_stats import _sample_stdev, _sheets_skew, _small_nth, _large_nth
from calculations.score_variance import AdjustedMatchRow


TREND_MATCH_COUNT = 12  # Score Variance!$B$2:$M$2 - fixed 12-match window


@dataclass
class DefenseCalcRow:
    team_num: int
    slope: float
    residuals: list[float]
    defensive_variance: float
    rrp: float = 0.0


def _slope(y: list[float], x: list[float]) -> float:
    """Google Sheets SLOPE(known_y, known_x): least-squares linear slope."""
    n = len(y)
    if n < 2 or n != len(x):
        return 0.0
    mean_x = sum(x) / n
    mean_y = sum(y) / n
    num = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
    den = sum((x[i] - mean_x) ** 2 for i in range(n))
    return num / den if den else 0.0


def build_defense_calculations(
    score_variance: dict[int, "object"],  # calculations.matrix_stats.TeamMatrixRow
) -> dict[int, DefenseCalcRow]:
    rows: dict[int, DefenseCalcRow] = {}
    for team, sv in score_variance.items():
        first12 = sv.values[:TREND_MATCH_COUNT]
        idx = list(range(1, len(first12) + 1))
        slope = _slope(first12, [float(i) for i in idx])
        intercept_ref = sv.avg - slope * TREND_MATCH_COUNT
        residuals = [first12[i] - (slope * (i + 1) + intercept_ref) for i in range(len(first12))]

        if len(residuals) > 1:
            defensive_variance = (sum(residuals) - min(residuals)) / (len(residuals) - 1)
        else:
            defensive_variance = 0.0

        rows[team] = DefenseCalcRow(
            team_num=team, slope=slope, residuals=residuals,
            defensive_variance=defensive_variance,
        )

    values = [r.defensive_variance for r in rows.values()]
    if values:
        vmin, vmax = min(values), max(values)
        span = (vmax + abs(vmin)) if (vmax + abs(vmin)) else 1.0
        for r in rows.values():
            r.rrp = (r.defensive_variance + abs(vmin)) / span

    return rows


@dataclass
class DefenseAdjustmentRow:
    team_num: int
    values: list[float]
    adj_avg: float
    skew: float
    rrp: float = 0.0


@dataclass
class AverageCompatabilityRow:
    team_num: int
    values: list[float]
    ratio: float
    rrp: float = 0.0


def team_ratio_lists(
    adjusted_rows: list[AdjustedMatchRow],
) -> tuple[dict[int, list[float]], dict[int, list[float]]]:
    """
    Public version of the own/opponent ratio list builder - reused by
    calculations.power_rankings (RDP) so the two sheets stay consistent.
    Returns (own_ratio_by_team, opponent_ratio_by_team).
    """
    return _team_ratio_lists(adjusted_rows)


def _team_ratio_lists(
    adjusted_rows: list[AdjustedMatchRow],
) -> tuple[dict[int, list[float]], dict[int, list[float]]]:
    """
    Returns (own_ratio_by_team, opponent_ratio_by_team), each a chronological
    (by match_num) list of per-match alliance-performance ratios, capped at
    15 matches like every other pivot sheet.
    """
    by_team_own: dict[int, list[tuple[int, float]]] = defaultdict(list)
    by_team_opp: dict[int, list[tuple[int, float]]] = defaultdict(list)
    for r in adjusted_rows:
        by_team_own[r.team_num].append((r.match_num, r.own_alliance_ratio))
        by_team_opp[r.team_num].append((r.match_num, r.opponent_alliance_ratio))

    def finalize(d):
        out = {}
        for team, pairs in d.items():
            pairs.sort(key=lambda p: p[0])
            out[team] = [v for _, v in pairs][:15]
        return out

    return finalize(by_team_own), finalize(by_team_opp)


def build_defense_adjustment(
    adjusted_rows: list[AdjustedMatchRow],
) -> dict[int, DefenseAdjustmentRow]:
    _, opp_by_team = _team_ratio_lists(adjusted_rows)

    rows: dict[int, DefenseAdjustmentRow] = {}
    for team, values in opp_by_team.items():
        if not values:
            continue
        min2 = _small_nth(values, 2)
        max2 = _large_nth(values, 2)
        avg_of_minmax = (min2 + max2) / 2.0
        adj_avg = 1 - abs(1 - avg_of_minmax)
        skew = _sheets_skew(values)
        rows[team] = DefenseAdjustmentRow(
            team_num=team, values=values, adj_avg=adj_avg, skew=skew,
        )

    adj_avgs = [r.adj_avg for r in rows.values()]
    max_adj = max(adj_avgs, default=0.0)
    for r in rows.values():
        r.rrp = (r.adj_avg / max_adj) if max_adj else 0.0

    return rows


def build_average_compatability(
    adjusted_rows: list[AdjustedMatchRow],
) -> dict[int, AverageCompatabilityRow]:
    own_by_team, _ = _team_ratio_lists(adjusted_rows)

    rows: dict[int, AverageCompatabilityRow] = {}
    for team, values in own_by_team.items():
        tail = values[1:]  # sheet excludes the first chronological match
        if not tail:
            rows[team] = AverageCompatabilityRow(team_num=team, values=values, ratio=0.0)
            continue
        stdev = _sample_stdev(tail)
        avg = (sum(tail) / len(tail)) - 1.0
        ratio = (avg / stdev) if stdev else 0.0
        rows[team] = AverageCompatabilityRow(team_num=team, values=values, ratio=ratio)

    ratios = [r.ratio for r in rows.values()]
    if ratios:
        vmin, vmax = min(ratios), max(ratios)
        span = (vmax + abs(vmin)) if (vmax + abs(vmin)) else 1.0
        for r in rows.values():
            r.rrp = (r.ratio + abs(vmin)) / span

    return rows

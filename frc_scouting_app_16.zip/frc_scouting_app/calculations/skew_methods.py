"""
calculations/skew_methods.py

Recreates the "SQRT Method", "Log10 Method", "1/X Method" and
"Skew Adjusted Spreads" sheets.

Each transform sheet takes a per-team chronological score history and
applies a transform meant to pull the distribution's skew toward 0.
Which direction of transform is used depends on the SIGN of that
team's own (untransformed) skew, exactly as written in the sheet
formulas:

    SQRT Method:  skew>0 -> sqrt(x)   | skew<=0 -> x^2
    Log10 Method: skew>0 -> log10(x)  | skew<=0 -> x^3
    1/X Method:   skew>0 -> 1/x       | skew<=0 -> x^4

(Values <= 0 under sqrt/log10/1÷x are treated as errors and skipped, the
same way Google Sheets' IFERROR wrapper drops them from the transformed
list rather than crashing the whole array formula.)

After all three transforms are computed, the method picker (X/Y columns)
is applied: for each team, of the four candidate skew values {raw, sqrt,
log10, 1/x}, whichever is closest to 0 wins, and that method's
transformed values become the team's row in "Skew Adjusted Spreads" -
the final, skew-normalized per-team score distribution that Stage 2
(Skew Distributions / Normalized Distributions) will build actual
probability curves from.

EXPERIMENT (see README.md "Experiment: Adjusted Score Variance
removed"): the source sheet builds these from Adjusted Score Variance.
At the user's request, this app now feeds them from plain Score
Variance instead (see pipeline.py) - the functions below don't care
which one they're handed, since both are the same TeamMatrixRow shape;
the parameter is just named `score_variance` to match whatever's
actually passed in.
"""

from dataclasses import dataclass

from calculations.matrix_stats import build_team_matrix, TeamMatrixRow
from calculations.transforms import (
    transform_series, METHOD_RAW, METHOD_SQRT, METHOD_LOG10, METHOD_1X,
)


def build_transform_methods(
    score_variance: dict[int, TeamMatrixRow],
) -> tuple[dict[int, TeamMatrixRow], dict[int, TeamMatrixRow], dict[int, TeamMatrixRow]]:
    """Returns (sqrt_method, log10_method, onex_method) team-matrix dicts."""
    sqrt_values, log10_values, onex_values = {}, {}, {}

    for team, row in score_variance.items():
        positive = row.skew > 0
        sqrt_values[team] = transform_series(row.values, METHOD_SQRT, positive)
        log10_values[team] = transform_series(row.values, METHOD_LOG10, positive)
        onex_values[team] = transform_series(row.values, METHOD_1X, positive)

    sqrt_method = build_team_matrix(sqrt_values, stdev_offset=0.0, include_skew=True)
    log10_method = build_team_matrix(log10_values, stdev_offset=0.0, include_skew=True)
    onex_method = build_team_matrix(onex_values, stdev_offset=0.0, include_skew=True)
    return sqrt_method, log10_method, onex_method


@dataclass
class SkewAdjustedSpreadRow:
    team_num: int
    matrix: TeamMatrixRow
    chosen_method: int


def choose_skew_methods(
    score_variance: dict[int, TeamMatrixRow],
    sqrt_method: dict[int, TeamMatrixRow],
    log10_method: dict[int, TeamMatrixRow],
    onex_method: dict[int, TeamMatrixRow],
) -> dict[int, int]:
    """
    For each team, which of the four skew values {raw, sqrt, log10,
    1/x} is closest to zero.
    """
    chosen: dict[int, int] = {}
    for team, row in score_variance.items():
        candidates = {
            METHOD_RAW: row.skew,
            METHOD_SQRT: sqrt_method.get(team, row).skew,
            METHOD_LOG10: log10_method.get(team, row).skew,
            METHOD_1X: onex_method.get(team, row).skew,
        }
        chosen[team] = min(candidates, key=lambda k: abs(candidates[k]))
    return chosen


def build_skew_adjusted_spreads(
    score_variance: dict[int, TeamMatrixRow],
    sqrt_method: dict[int, TeamMatrixRow],
    log10_method: dict[int, TeamMatrixRow],
    onex_method: dict[int, TeamMatrixRow],
) -> dict[int, SkewAdjustedSpreadRow]:
    chosen = choose_skew_methods(score_variance, sqrt_method, log10_method, onex_method)

    source_by_method = {
        METHOD_RAW: score_variance,
        METHOD_SQRT: sqrt_method,
        METHOD_LOG10: log10_method,
        METHOD_1X: onex_method,
    }

    out: dict[int, SkewAdjustedSpreadRow] = {}
    for team, method in chosen.items():
        source = source_by_method[method].get(team)
        if source is None:
            source = score_variance[team]
        out[team] = SkewAdjustedSpreadRow(
            team_num=team, matrix=source, chosen_method=method,
        )
    return out

"""
calculations/balls_scored.py

Recreates the "Auto Balls Scored" and "Teleop Balls Scored" sheets.

Both pivot Raw Data's per-robot-per-match values into one row per team,
values laid out chronologically (column B = match 1 played, C = match 2
played, etc, up to 15), then compute Min/Max/STDEV/AVG/AVG-STDEV/RRP.

    B..P   = transpose(FILTER('Raw Data'!col, 'Raw Data'!A = team))
    Q(Min) = SMALL(B:P, 2)
    R(Max) = LARGE(B:P, 2)
    S(STDEV) = STDEV(B:P)
    T(AVG)   = AVERAGE(B:P)
    U(AVG/STDEV) = T / (S + 1)      <-- note the +1, unique to these two sheets
    V(RRP)   = T / MAX(all teams' T)

Auto Balls Scored reads Raw Data column B (auto_balls).
Teleop Balls Scored reads Raw Data column D (teleop_balls).
"""

from collections import defaultdict

from calculations.matrix_stats import build_team_matrix, TeamMatrixRow


def _team_value_lists(raw_data_rows: list[dict], value_key: str) -> dict[int, list[float]]:
    by_team: dict[int, list[float]] = defaultdict(list)
    for row in raw_data_rows:
        by_team[row["team_num"]].append(row[value_key])
    return by_team


def build_auto_balls_scored(raw_data_rows: list[dict]) -> dict[int, TeamMatrixRow]:
    values = _team_value_lists(raw_data_rows, "auto_balls")
    return build_team_matrix(values, stdev_offset=1.0, include_skew=False)


def build_teleop_balls_scored(raw_data_rows: list[dict]) -> dict[int, TeamMatrixRow]:
    values = _team_value_lists(raw_data_rows, "teleop_balls")
    return build_team_matrix(values, stdev_offset=1.0, include_skew=False)

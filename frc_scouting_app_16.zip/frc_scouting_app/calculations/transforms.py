"""
calculations/transforms.py

The single source of truth for the three skew-reducing transforms used
throughout the workbook (SQRT/Log10/1-over-X methods). Both Stage 1
(SQRT Method / Log10 Method / 1/X Method sheets, which transform actual
data points) and Stage 2 (Skew Distributions sheet, which transforms
x-axis grid points to evaluate a curve) apply the exact same per-value
rule, so it lives in one place.

Per the algorithm PDF and the sheet formulas: which direction a transform
runs depends on the sign of the RAW (untransformed) skew for whatever is
being transformed:
    skew > 0 (right-skewed) -> compress the right tail: sqrt(x), log10(x), 1/x
    skew <= 0 (left-skewed) -> the opposite: x^2, x^3, x^4
"""

import math

METHOD_RAW, METHOD_SQRT, METHOD_LOG10, METHOD_1X = 1, 2, 3, 4


def transform_value(x: float, method: int, positive_skew: bool) -> float | None:
    """
    Apply one of the four skew-adjustment methods to a single value x.
    Returns None where the sheet's IFERROR would have dropped the value
    (e.g. sqrt/log10 of a non-positive number, or 1/0).
    """
    if method == METHOD_RAW:
        return x
    if method == METHOD_SQRT:
        if positive_skew:
            return math.sqrt(x) if x >= 0 else None
        return x ** 2
    if method == METHOD_LOG10:
        if positive_skew:
            return math.log10(x) if x > 0 else None
        return x ** 3
    if method == METHOD_1X:
        if positive_skew:
            return (1.0 / x) if x != 0 else None
        return x ** 4
    raise ValueError(f"Unknown method {method}")


def transform_series(values: list[float], method: int, positive_skew: bool) -> list[float]:
    out = []
    for v in values:
        t = transform_value(v, method, positive_skew)
        if t is not None:
            out.append(t)
    return out

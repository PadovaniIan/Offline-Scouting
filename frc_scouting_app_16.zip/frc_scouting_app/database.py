"""
database.py

Single local SQLite database file. No server, no network socket is ever
opened by this module - sqlite3 is part of the Python standard library and
reads/writes only the file at DB_PATH on disk.

This mirrors the THREE manually-populated "input" sheets from the original
spreadsheet. Every other sheet in the spreadsheet (Raw Data, Auto/Teleop
Balls Scored, Score Variance, Skew Distributions, Alliance Generators,
Match Odds, ROP/RDP/RPP, Rankings, Pick List, etc.) was a *formula-derived*
sheet with no independent input of its own - those are recreated as pure
Python calculations in calculations/ each time the app needs them, exactly
like the spreadsheet recalculated them from its three input sheets.

The three input tables are:
    raw_scouting   <- "Unfiltered Raw Data" sheet (one row per scouted
                       robot per match)
    bps_samples    <- "BPS" sheet (manually recorded ball-per-second
                       calibration samples per team)
    match_schedule <- "Match Schedule" sheet, columns A-M only (match
                       number, the six teams, and the final alliance
                       scores/ball counts - the part of that sheet that
                       was NOT itself a formula)
"""

import sqlite3
from pathlib import Path
from contextlib import contextmanager

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DB_PATH = DATA_DIR / "scouting.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS raw_scouting (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    initials                TEXT,
    event                   TEXT,
    match_num               INTEGER NOT NULL,
    alliance                TEXT NOT NULL,   -- 'r1','r2','r3','b1','b2','b3'
    team_num                INTEGER NOT NULL,
    auto_leave              TEXT,
    auto_shooting_time      REAL DEFAULT 0,
    auto_shuttle            TEXT,
    auto_floor              TEXT,
    auto_climb              TEXT,            -- 'CLIMB' or anything else
    teleop_shooting_time    REAL DEFAULT 0,
    teleop_shuttle          TEXT,
    teleop_outpost          TEXT,
    teleop_floor            TEXT,
    teleop_climb            TEXT,            -- '1','2','3' or blank
    died                    TEXT,
    beached                 TEXT,
    notes                   TEXT
);

CREATE TABLE IF NOT EXISTS manual_raw_data (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    match_num        INTEGER NOT NULL,
    alliance         TEXT NOT NULL,   -- 'r1','r2','r3','b1','b2','b3'
    team_num         INTEGER NOT NULL,
    auto_balls       REAL DEFAULT 0,  -- Raw Data col B (Auto Shooting)
    auto_climb_pts   REAL DEFAULT 0,  -- Raw Data col C (Auto L1/Climb)
    teleop_balls     REAL DEFAULT 0,  -- Raw Data col D (Teleop Shooting)
    teleop_l1        REAL DEFAULT 0,  -- Raw Data col E
    teleop_l2        REAL DEFAULT 0,  -- Raw Data col F
    teleop_l3        REAL DEFAULT 0,  -- Raw Data col G
    score            REAL,            -- Raw Data col H (Score); NULL = derive from breakdown
    notes            TEXT             -- Raw Data col I
);

CREATE TABLE IF NOT EXISTS bps_samples (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    team_num    INTEGER NOT NULL,
    sample_value REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS match_schedule (
    match_num         INTEGER PRIMARY KEY,
    red1              INTEGER,
    red2              INTEGER,
    red3              INTEGER,
    blue1             INTEGER,
    blue2             INTEGER,
    blue3             INTEGER,
    red_score         REAL,
    blue_score        REAL,
    red_auto_balls    REAL,
    blue_auto_balls   REAL,
    red_teleop_balls  REAL,
    blue_teleop_balls REAL
);

CREATE TABLE IF NOT EXISTS team_roster (
    team_num  INTEGER PRIMARY KEY,
    team_name TEXT
);

CREATE INDEX IF NOT EXISTS idx_raw_scouting_team  ON raw_scouting(team_num);
CREATE INDEX IF NOT EXISTS idx_raw_scouting_match ON raw_scouting(match_num);
CREATE INDEX IF NOT EXISTS idx_bps_team           ON bps_samples(team_num);
CREATE INDEX IF NOT EXISTS idx_manual_raw_team    ON manual_raw_data(team_num);
CREATE INDEX IF NOT EXISTS idx_manual_raw_match   ON manual_raw_data(match_num);
"""


def init_db() -> None:
    """Create the database file and tables if they don't already exist."""
    with get_connection() as conn:
        conn.executescript(SCHEMA)
        conn.commit()


@contextmanager
def get_connection():
    """Context-managed connection to the local, offline SQLite file."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
    finally:
        conn.close()


def known_team_numbers(conn) -> list[int]:
    """
    Union of every team number that appears anywhere in the three input
    tables - equivalent to the "Team Numbers" sheet's team list.
    """
    cur = conn.cursor()
    teams = set()
    for row in cur.execute("SELECT DISTINCT team_num FROM raw_scouting"):
        teams.add(row["team_num"])
    for row in cur.execute("SELECT DISTINCT team_num FROM manual_raw_data"):
        teams.add(row["team_num"])
    for row in cur.execute("SELECT DISTINCT team_num FROM bps_samples"):
        teams.add(row["team_num"])
    for row in cur.execute(
        "SELECT red1,red2,red3,blue1,blue2,blue3 FROM match_schedule"
    ):
        for t in (row["red1"], row["red2"], row["red3"],
                  row["blue1"], row["blue2"], row["blue3"]):
            if t is not None:
                teams.add(t)
    return sorted(teams)


def clear_active_competition_data() -> None:
    """
    Wipes both actively-used input tables (manual_raw_data and
    match_schedule) so a new competition's CSVs can be imported without
    mixing with whatever competition was loaded before. Deliberately does
    NOT touch raw_scouting/bps_samples/team_roster - those are either
    unused legacy tables (raw_scouting, bps_samples - see Stage 4/README)
    or a small local naming table that isn't competition-specific.

    Called from ui/app.py._import() when the user picks "New Competition"
    at import time - see that function's docstring for why a wholesale
    wipe (rather than the two importers' own per-table replace_existing
    flag used independently) is the safe choice regardless of which CSV
    (Match Schedule or Raw Data) is imported first for the new event.
    """
    init_db()
    with get_connection() as conn:
        conn.execute("DELETE FROM manual_raw_data")
        conn.execute("DELETE FROM match_schedule")
        conn.commit()


def has_manual_raw_data(conn) -> bool:
    """True if a Raw-Data-shaped CSV has been imported directly (see
    data_import.import_raw_data_csv / calculations.raw_processing
    .build_raw_data_from_manual). When true, pipeline.build_all() uses
    this as the source of truth instead of deriving Raw Data from
    raw_scouting + BPS."""
    row = conn.execute("SELECT 1 FROM manual_raw_data LIMIT 1").fetchone()
    return row is not None

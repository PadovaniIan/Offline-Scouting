"""
printing/escpos_builder.py

Two layers in this file:

1. `ReceiptBuilder` - a tiny wrapper around raw ESC/POS command bytes
   (the command language essentially every 80mm thermal receipt printer
   understands, regardless of brand - Epson, Star, Rongta, generic
   clones, etc. all implement the core of it). It only ever produces
   `bytes`; it knows nothing about tkinter, USB, or the OS print
   spooler - see printer_backend.py for how those bytes actually reach
   the printer.

2. `build_alliance_receipt()` - the actual content: given one alliance's
   three teams and the already-computed ComputedData (from
   calculations/pipeline.py::build_all(), exactly what every other tab
   reads from), produces the bytes for that alliance's full receipt.
   This is a deliberately trimmed-down subset of what
   ui/team_lookup_tab.py shows on-screen for each team - same source
   dicts (auto_balls_scored, teleop_balls_scored,
   normalized_distributions, rpp, score_variance), but only a few
   fields from each, chosen to keep the printout short and direct
   (see each field's comment below for what's intentionally omitted
   and why). Average Compatability is omitted entirely. At the bottom,
   that alliance's match prediction (expected score / win probability)
   is printed using the same numbers ui/alliance_display.py::
   build_alliance_panel() shows on-screen.

No calculation happens in this file - every number printed is read
directly off objects calculations/ already built.
"""

from __future__ import annotations

from dataclasses import dataclass

# --------------------------------------------------------------------------
# Raw ESC/POS command bytes.
#
# These are the same handful of commands essentially every ESC/POS-
# compatible 80mm thermal printer supports, whether it's a genuine Epson
# TM series or a cheap generic clone - this is the same small "common
# subset" widely-used receipt-printing libraries (e.g. python-escpos)
# rely on for portability, reimplemented here directly (as plain bytes)
# so this project adds no new pip dependency.
# --------------------------------------------------------------------------
ESC = b"\x1b"
GS = b"\x1d"

CMD_INIT = ESC + b"@"                  # Reset the printer to defaults
CMD_ALIGN_LEFT = ESC + b"a" + b"\x00"
CMD_ALIGN_CENTER = ESC + b"a" + b"\x01"
CMD_BOLD_ON = ESC + b"E" + b"\x01"
CMD_BOLD_OFF = ESC + b"E" + b"\x00"
CMD_DOUBLE_ON = GS + b"!" + b"\x11"    # Double width + double height
CMD_DOUBLE_OFF = GS + b"!" + b"\x00"
CMD_UNDERLINE_ON = ESC + b"-" + b"\x01"
CMD_UNDERLINE_OFF = ESC + b"-" + b"\x00"
CMD_CODEPAGE_ASCII = ESC + b"t" + b"\x00"
# Full cut. Printers without an auto-cutter simply ignore this byte
# sequence rather than erroring, so it's safe to always send it.
CMD_CUT = GS + b"V" + b"\x00"

# 80mm paper, Font A (12x24) is 48 columns on essentially every printer
# that ships with that paper width - this is the standard, documented
# default. If a given printer/font combination wraps text at a different
# width, this is the one constant to change.
CHARS_PER_LINE = 48


class ReceiptBuilder:
    """Accumulates ESC/POS bytes for one receipt. Call finish() once at
    the end to get the full byte string to send to the printer."""

    def __init__(self, chars_per_line: int = CHARS_PER_LINE):
        self.chars_per_line = chars_per_line
        self._buf = bytearray()
        self._buf += CMD_INIT
        self._buf += CMD_CODEPAGE_ASCII

    def _raw(self, data: bytes) -> None:
        self._buf += data

    def _ascii(self, text: str) -> bytes:
        # Raw thermal printers speak single-byte codepages, not UTF-8.
        # Anything outside the printable ASCII range (a curly quote
        # pasted into a team name, for instance) is replaced rather
        # than sent as multi-byte UTF-8, which a printer's ASCII
        # codepage would otherwise render as garbled symbols.
        return text.encode("ascii", errors="replace")

    def text(self, s: str = "") -> "ReceiptBuilder":
        """One line of plain text, word-wrapped to the receipt width."""
        for line in _wrap(s, self.chars_per_line):
            self._raw(self._ascii(line) + b"\n")
        if s == "":
            self._raw(b"\n")
        return self

    def center_text(self, s: str) -> "ReceiptBuilder":
        self._raw(CMD_ALIGN_CENTER)
        self.text(s)
        self._raw(CMD_ALIGN_LEFT)
        return self

    def bold_text(self, s: str) -> "ReceiptBuilder":
        self._raw(CMD_BOLD_ON)
        self.text(s)
        self._raw(CMD_BOLD_OFF)
        return self

    def header(self, s: str) -> "ReceiptBuilder":
        """Large, bold, centered heading."""
        self._raw(CMD_ALIGN_CENTER + CMD_DOUBLE_ON + CMD_BOLD_ON)
        self.text(s)
        self._raw(CMD_BOLD_OFF + CMD_DOUBLE_OFF + CMD_ALIGN_LEFT)
        return self

    def subheader(self, s: str) -> "ReceiptBuilder":
        """Bold, underlined section label (e.g. a team number)."""
        self._raw(CMD_BOLD_ON + CMD_UNDERLINE_ON)
        self.text(s)
        self._raw(CMD_UNDERLINE_OFF + CMD_BOLD_OFF)
        return self

    def hr(self, ch: str = "-") -> "ReceiptBuilder":
        self.text(ch * self.chars_per_line)
        return self

    def kv(self, label: str, value: str) -> "ReceiptBuilder":
        """One 'Label ....... value' row, right-aligned value, wrapped
        to the receipt width - the same label/value pairs Team Lookup's
        stat_row() shows on-screen, just laid out for a narrow strip of
        paper instead of a wide window."""
        room = self.chars_per_line - len(value)
        if room < len(label) + 1:
            # Label+value together don't fit on one line at this width -
            # fall back to two lines rather than truncating either one.
            self.text(label)
            self.text(value.rjust(self.chars_per_line))
        else:
            dots = "." * (room - len(label))
            self.text(f"{label}{dots}{value}")
        return self

    def feed(self, n: int = 1) -> "ReceiptBuilder":
        self._raw(b"\n" * n)
        return self

    def cut(self) -> "ReceiptBuilder":
        self.feed(3)
        self._raw(CMD_CUT)
        return self

    def finish(self) -> bytes:
        return bytes(self._buf)


def _wrap(text: str, width: int) -> list[str]:
    """Simple word wrap - splits on whitespace, breaks an overlong single
    'word' (e.g. a long team-name string with no spaces) at the width
    rather than overflowing the line."""
    if text == "":
        return [""]
    words = text.split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        while len(word) > width:
            # A single token longer than the whole line - hard-break it.
            space_left = width - len(current) - (1 if current else 0)
            if current and space_left > 0:
                current = f"{current} {word[:space_left]}" if current else word[:space_left]
                lines.append(current)
                word = word[space_left:]
            else:
                if current:
                    lines.append(current)
                lines.append(word[:width])
                word = word[width:]
            current = ""
        candidate = f"{current} {word}" if current else word
        if len(candidate) <= width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or [""]


# --------------------------------------------------------------------------
# Receipt content
# --------------------------------------------------------------------------

METHOD_NAMES = {1: "Raw", 2: "SQRT", 3: "Log10", 4: "1/X"}


@dataclass
class AlliancePrediction:
    """The subset of a MatchOddsResult (calculations/match_odds.py) one
    alliance's receipt needs - passed in by print_dialog.py rather than
    this module reaching into calculations/ itself, so this file stays a
    pure formatter."""
    expected_score: float | None
    win_probability: float | None
    actual_score: float | None
    unavailable_reason: str | None = None


def _team_section(rb: ReceiptBuilder, team: int, data) -> None:
    """Everything ui/team_lookup_tab.py shows for one team, formatted
    for the narrow receipt strip. `data` is the app's
    calculations.pipeline.ComputedData."""
    rb.subheader(f"Team {team}")

    sv = data.score_variance.get(team)
    if sv:
        rb.kv("Score avg", f"{sv.avg:.1f}")
        rb.kv("Score RRP", f"{sv.rrp:.3f}")
        if sv.values:
            history = ", ".join(f"{v:g}" for v in sv.values)
            rb.text("Score history:")
            for line in _wrap(history, rb.chars_per_line):
                rb.text(f"  {line}")
    else:
        rb.text("No scouted score history for this team.")

    a = data.auto_balls_scored.get(team)
    rb.text("")
    rb.text("Auto Balls Scored")
    if a:
        rb.kv("  Average", f"{a.avg:.2f}")
        rb.kv("  Std Dev", f"{a.stdev:.2f}")
    else:
        rb.text("  No data.")

    t = data.teleop_balls_scored.get(team)
    rb.text("")
    rb.text("Teleop Balls Scored")
    if t:
        rb.kv("  Average", f"{t.avg:.2f}")
        rb.kv("  Std Dev", f"{t.stdev:.2f}")
    else:
        rb.text("  No data.")

    nd = data.normalized_distributions.get(team)
    rb.text("")
    rb.text("Fitted Score Distribution")
    if nd:
        rb.kv("  Mode (most likely)", f"{nd.mode_x:.0f}")
        rb.kv("  Upper cutoff (95th)", f"{nd.upper_cutoff:.1f}")
    else:
        rb.text("  No fitted distribution.")

    rpp = data.rpp.get(team)
    rb.text("")
    rb.text("Overall Power")
    if rpp:
        rb.kv("  RPP", f"{rpp.rpp:.3f}")
        rb.kv("  Weak to defense?", "Yes" if rpp.defense_susceptible else "No")
    else:
        rb.text("  No data.")


def build_alliance_receipt(
    *,
    alliance_name: str,
    teams: list[int],
    data,
    prediction: AlliancePrediction,
    match_label: str,
    printed_at: str,
) -> bytes:
    """Builds one full alliance receipt (Red or Blue) as ESC/POS bytes -
    a section per teammate (everything Team Lookup shows for that team)
    followed by this alliance's match prediction at the bottom.

    `match_label` is a short line identifying which match this is (e.g.
    "Match 42" or "Simulated Matchup") - the caller decides the wording
    so this module doesn't need to know whether it's a real scheduled
    match or a Match Simulator hypothetical.
    """
    rb = ReceiptBuilder()
    rb.header(f"{alliance_name} Alliance")
    rb.center_text(match_label)
    rb.center_text(printed_at)
    rb.feed(1)

    for i, team in enumerate(teams):
        _team_section(rb, team, data)
        if i != len(teams) - 1:
            rb.feed(1)
            rb.hr()
            rb.feed(1)

    rb.feed(1)
    rb.hr("=")
    rb.bold_text(f"{alliance_name} Alliance Prediction")
    rb.hr("=")

    if prediction.actual_score is not None:
        rb.kv("Actual recorded score", f"{prediction.actual_score:g}")

    if prediction.unavailable_reason:
        rb.text(f"Win odds unavailable: {prediction.unavailable_reason}")
    else:
        rb.kv("Expected score", f"{prediction.expected_score:.0f}")
        rb.kv("Win probability", f"{prediction.win_probability * 100:.1f}%")

    # Extra trailing feed before the cut - on some printers the last
    # printed line(s) can end up sitting right at (or past) the cut
    # point otherwise, clipping the win probability line. This adds a
    # few blank lines of margin on top of cut()'s own feed(3).
    rb.feed(4)
    rb.cut()
    return rb.finish()

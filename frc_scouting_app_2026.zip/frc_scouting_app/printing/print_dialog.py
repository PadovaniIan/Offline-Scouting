"""
printing/print_dialog.py

The user-facing side of Stage 15 (Match Results Printing): the small
Tkinter printer-picker dialog, and print_match_receipts() - the one
function ui/match_lookup_tab.py's "Print Results" button calls.

Designed to be seamless on the common path and never silently fail on
the uncommon one:

    * Printer already chosen and still plugged in -> no dialog at all,
      the two receipts just print.
    * First time, and exactly one printer is installed -> that one is
      used and remembered automatically, no dialog.
    * First time (or the remembered printer disappeared - unplugged,
      renamed) and MULTIPLE printers are installed -> a picker dialog
      appears, listing every installed printer by name so the user can't
      accidentally print a 400-line receipt to their office laser
      printer. The choice is remembered for next time.
    * No printers installed at all -> a clear, actionable error message
      (install the driver, check the USB cable) rather than a traceback.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

from printing import settings
from printing.printer_backend import list_printers, send_raw_bytes, PrinterError
from printing.escpos_builder import build_alliance_receipt, AlliancePrediction


class PrinterSelectDialog(tk.Toplevel):
    """Modal list of installed printers. Sets self.result to the chosen
    printer name, or None if cancelled."""

    def __init__(self, parent, printers: list[str], reason: str | None = None):
        super().__init__(parent)
        self.title("Select Receipt Printer")
        self.result: str | None = None
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        pad = {"padx": 16, "pady": 6}
        msg = reason or (
            "More than one printer is installed on this computer.\n"
            "Which one is the thermal receipt printer?"
        )
        ttk.Label(self, text=msg, justify="left").pack(anchor="w", **pad)

        list_frame = ttk.Frame(self)
        list_frame.pack(fill="both", expand=True, padx=16)
        self.listbox = tk.Listbox(list_frame, height=min(8, max(3, len(printers))),
                                   exportselection=False)
        for name in printers:
            self.listbox.insert("end", name)
        if printers:
            self.listbox.selection_set(0)
        self.listbox.pack(side="left", fill="both", expand=True)
        self.listbox.bind("<Double-Button-1>", lambda e: self._choose())

        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.listbox.configure(yscrollcommand=scrollbar.set)

        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=16, pady=(10, 12))
        ttk.Button(btn_frame, text="Use This Printer", command=self._choose).pack(
            side="left", fill="x", expand=True, padx=(0, 4))
        ttk.Button(btn_frame, text="Cancel", command=self._cancel).pack(
            side="left", fill="x", expand=True, padx=(4, 0))

        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.bind("<Escape>", lambda e: self._cancel())
        self.bind("<Return>", lambda e: self._choose())

        self.update_idletasks()
        parent_x = parent.winfo_rootx()
        parent_y = parent.winfo_rooty()
        self.geometry(f"+{parent_x + 60}+{parent_y + 60}")

    def _choose(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        self.result = self.listbox.get(sel[0])
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()


def prompt_choose_printer(parent) -> str | None:
    """Forces the picker dialog regardless of any remembered printer -
    used both by the automatic multi-printer case and by the Data menu's
    explicit "Select Receipt Printer..." command (for when the user
    plugs in a different printer later, or the auto-pick guessed wrong).
    Remembers and returns the choice, or None if cancelled / no printers
    found."""
    try:
        printers = list_printers()
    except PrinterError as exc:
        messagebox.showerror("Printer error", str(exc))
        return None

    if not printers:
        messagebox.showerror(
            "No printer found",
            "No installed printers were found on this computer.\n\n"
            "Plug in the receipt printer, install its driver (included "
            "with this app's release), and make sure it appears as a "
            "printer in your operating system's printer settings - "
            "then try again.",
        )
        return None

    dialog = PrinterSelectDialog(parent, printers)
    dialog.wait_window()
    if dialog.result:
        settings.set_selected_printer(dialog.result)
    return dialog.result


def _resolve_printer(parent) -> str | None:
    """Returns the printer name to print to, choosing automatically
    whenever that's unambiguous and only bothering the user when it
    isn't. Returns None if the user needs to be asked and cancels, or
    if no printer is available."""
    saved = settings.get_selected_printer()
    try:
        printers = list_printers()
    except PrinterError as exc:
        messagebox.showerror("Printer error", str(exc))
        return None

    if saved and saved in printers:
        return saved

    if not printers:
        messagebox.showerror(
            "No printer found",
            "No installed printers were found on this computer.\n\n"
            "Plug in the receipt printer, install its driver (included "
            "with this app's release), and make sure it appears as a "
            "printer in your operating system's printer settings - "
            "then try again.",
        )
        return None

    if len(printers) == 1:
        # Unambiguous - no need to interrupt the user with a dialog for
        # a "choice" that isn't actually a choice.
        settings.set_selected_printer(printers[0])
        return printers[0]

    reason = None
    if saved:
        reason = (
            f"The previously-selected printer ('{saved}') is no longer "
            f"available. Which installed printer is the thermal receipt "
            f"printer?"
        )
    dialog = PrinterSelectDialog(parent, printers, reason=reason)
    dialog.wait_window()
    if dialog.result:
        settings.set_selected_printer(dialog.result)
    return dialog.result


def print_match_receipts(
    parent,
    *,
    app=None,
    match_label: str,
    red_teams: list[int],
    blue_teams: list[int],
    data,
    red_prediction: AlliancePrediction,
    blue_prediction: AlliancePrediction,
) -> None:
    """Prints both alliances' receipts for one match (or one Match
    Simulator matchup). `data` is the app's
    calculations.pipeline.ComputedData. `app`, if given, gets its
    status bar (status_var) updated - purely cosmetic, printing still
    works fine without it.

    This is the one function ui/match_lookup_tab.py's "Print Results"
    button (and, if wired up later, ui/match_simulator_tab.py's) needs
    to call.
    """
    printer_name = _resolve_printer(parent)
    if printer_name is None:
        return  # user cancelled, or no printer available (already told)

    printed_at = datetime.now().strftime("%Y-%m-%d %I:%M %p")

    red_bytes = build_alliance_receipt(
        alliance_name="Red", teams=red_teams, data=data,
        prediction=red_prediction, match_label=match_label, printed_at=printed_at,
    )
    blue_bytes = build_alliance_receipt(
        alliance_name="Blue", teams=blue_teams, data=data,
        prediction=blue_prediction, match_label=match_label, printed_at=printed_at,
    )

    if app is not None:
        app.status_var.set(f"Printing {match_label} to {printer_name}...")
        app.update_idletasks()

    try:
        send_raw_bytes(printer_name, red_bytes, job_name=f"{match_label} - Red Alliance")
        send_raw_bytes(printer_name, blue_bytes, job_name=f"{match_label} - Blue Alliance")
    except PrinterError as exc:
        messagebox.showerror("Print failed", str(exc))
        if app is not None:
            app.status_var.set("Print failed - see dialog")
        return

    if app is not None:
        app.status_var.set(f"Printed {match_label} (Red + Blue) to {printer_name}.")

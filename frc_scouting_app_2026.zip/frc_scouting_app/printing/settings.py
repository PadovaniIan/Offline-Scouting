"""
printing/settings.py

Remembers which installed printer the user picked as "the" receipt
printer, so printing is a single click after the first time instead of
asking every time.

Stored as a tiny JSON file next to the SQLite database
(database.DATA_DIR / "printer_settings.json"), deliberately NOT as a row
in scouting.db: the chosen printer is a property of this computer/
install, not of whichever competition's data happens to be loaded, so it
must survive database.clear_active_competition_data() (Stage 9) - a
"New competition" import should never make the app forget which
physical printer is plugged in.
"""

from __future__ import annotations

import json
from pathlib import Path

from database import DATA_DIR

SETTINGS_PATH: Path = DATA_DIR / "printer_settings.json"


def get_selected_printer() -> str | None:
    """Returns the printer name remembered from a previous session, or
    None if none has been chosen yet (or the settings file is missing/
    unreadable, treated the same as "not chosen yet" rather than as an
    error - the caller's normal printer-selection flow covers it)."""
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            payload = json.load(f)
        name = payload.get("printer_name")
        return name if isinstance(name, str) and name else None
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def set_selected_printer(printer_name: str) -> None:
    """Remembers this printer name for next time."""
    SETTINGS_PATH.parent.mkdir(exist_ok=True)
    with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump({"printer_name": printer_name}, f)

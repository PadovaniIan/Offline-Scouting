"""
printing/printer_backend.py

Cross-platform "list installed printers" / "send raw bytes to a named
printer" layer, for a USB thermal receipt printer that has already been
installed as a normal system printer (driver installed - see the
project's release notes / README.md "Printing Match Results" section).

Deliberately does NOT talk to the USB device directly (no `pyusb`, no
vendor/product ID matching). Going through the OS's own print spooler
instead is what makes this foolproof when multiple USB devices are
plugged in at once: the spooler already knows, by name, which installed
printer is the thermal receipt printer (that's the whole point of
installing its driver), so this module never has to guess which USB
device on the bus is the right one - it just asks the OS for the named
printer's raw byte pipe.

Two backends, chosen automatically by `platform.system()`:

  * Windows - talks straight to the print spooler via `ctypes` +
    `winspool.drv` (EnumPrintersW / OpenPrinterW / StartDocPrinterW /
    WritePrinter / ...). This is the standard, documented way to push
    raw ESC/POS bytes to a Windows-installed printer, and needs no pip
    package beyond the Python standard library - `ctypes` ships with
    every Windows Python install.

  * macOS - talks to CUPS via the `lp` command-line tool (part of every
    macOS install; no extra software needed). `-o raw` tells CUPS to
    hand the bytes straight to the printer instead of running them
    through a filter/driver that would try to interpret them as a page
    to render - exactly what's needed for raw ESC/POS.

Both backends raise PrinterError with a message meant to be shown
directly to the user (see print_dialog.py) rather than a raw
traceback - printer/driver problems are common and expected, not bugs.
"""

from __future__ import annotations

import platform
import subprocess


class PrinterError(Exception):
    """Raised for any printer-discovery or printing failure. The message
    is written to be shown directly to the user."""


def list_printers() -> list[str]:
    """Returns the names of every printer currently installed on this
    system (regardless of whether it's actually a thermal receipt
    printer - the caller/user picks the right one by name)."""
    system = platform.system()
    if system == "Windows":
        return _windows_list_printers()
    if system == "Darwin":
        return _mac_list_printers()
    raise PrinterError(
        "Receipt printing is only supported on Windows and macOS."
    )


def send_raw_bytes(printer_name: str, data: bytes, job_name: str = "FRC Scouting Receipt") -> None:
    """Sends raw bytes to the named, already-installed printer. Raises
    PrinterError with a user-facing message on any failure (printer
    unplugged, driver not installed, spooler busy, etc.)."""
    system = platform.system()
    if system == "Windows":
        _windows_send_raw(printer_name, data, job_name)
    elif system == "Darwin":
        _mac_send_raw(printer_name, data, job_name)
    else:
        raise PrinterError(
            "Receipt printing is only supported on Windows and macOS."
        )


# --------------------------------------------------------------------------
# Windows backend - ctypes + winspool.drv (no pywin32 dependency needed)
# --------------------------------------------------------------------------

def _windows_list_printers() -> list[str]:
    import ctypes
    from ctypes import wintypes

    winspool = ctypes.WinDLL("winspool.drv")

    PRINTER_ENUM_LOCAL = 0x00000002
    PRINTER_ENUM_CONNECTIONS = 0x00000004

    # First call with a zero buffer to learn how many bytes are needed,
    # then a real call with a buffer that size - the standard two-step
    # EnumPrinters pattern.
    needed = wintypes.DWORD(0)
    returned = wintypes.DWORD(0)
    winspool.EnumPrintersW(
        PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS, None, 2, None, 0,
        ctypes.byref(needed), ctypes.byref(returned),
    )
    if needed.value == 0:
        return []

    buf = ctypes.create_string_buffer(needed.value)
    ok = winspool.EnumPrintersW(
        PRINTER_ENUM_LOCAL | PRINTER_ENUM_CONNECTIONS, None, 2, buf,
        needed.value, ctypes.byref(needed), ctypes.byref(returned),
    )
    if not ok:
        raise PrinterError(
            "Windows would not return the list of installed printers "
            "(EnumPrinters failed). Try again, or check printer "
            "installation in Settings > Printers & scanners."
        )

    # PRINTER_INFO_2W's first field is a pointer to the printer name.
    class PRINTER_INFO_2(ctypes.Structure):
        _fields_ = [
            ("pServerName", wintypes.LPWSTR),
            ("pPrinterName", wintypes.LPWSTR),
            ("pShareName", wintypes.LPWSTR),
            ("pPortName", wintypes.LPWSTR),
            ("pDriverName", wintypes.LPWSTR),
            ("pComment", wintypes.LPWSTR),
            ("pLocation", wintypes.LPWSTR),
            ("pDevMode", ctypes.c_void_p),
            ("pSepFile", wintypes.LPWSTR),
            ("pPrintProcessor", wintypes.LPWSTR),
            ("pDatatype", wintypes.LPWSTR),
            ("pParameters", wintypes.LPWSTR),
            ("pSecurityDescriptor", ctypes.c_void_p),
            ("Attributes", wintypes.DWORD),
            ("Priority", wintypes.DWORD),
            ("DefaultPriority", wintypes.DWORD),
            ("StartTime", wintypes.DWORD),
            ("UntilTime", wintypes.DWORD),
            ("Status", wintypes.DWORD),
            ("cJobs", wintypes.DWORD),
            ("AveragePPM", wintypes.DWORD),
        ]

    array = ctypes.cast(buf, ctypes.POINTER(PRINTER_INFO_2 * returned.value)).contents
    return [p.pPrinterName for p in array if p.pPrinterName]


def _windows_send_raw(printer_name: str, data: bytes, job_name: str) -> None:
    import ctypes
    from ctypes import wintypes

    winspool = ctypes.WinDLL("winspool.drv")

    class DOC_INFO_1(ctypes.Structure):
        _fields_ = [
            ("pDocName", wintypes.LPWSTR),
            ("pOutputFile", wintypes.LPWSTR),
            ("pDatatype", wintypes.LPWSTR),
        ]

    handle = wintypes.HANDLE()
    if not winspool.OpenPrinterW(printer_name, ctypes.byref(handle), None):
        raise PrinterError(
            f"Could not open printer '{printer_name}'. It may have been "
            f"unplugged or its driver may not be installed correctly. "
            f"Check Settings > Printers & scanners and try again."
        )
    try:
        # "RAW" tells the spooler to pass these bytes straight to the
        # printer with no reinterpretation - exactly what raw ESC/POS
        # commands need (as opposed to "TEXT" or "EMF", which would try
        # to render them as a page).
        doc_info = DOC_INFO_1(pDocName=job_name, pOutputFile=None, pDatatype="RAW")
        job_id = winspool.StartDocPrinterW(handle, 1, ctypes.byref(doc_info))
        if job_id == 0:
            raise PrinterError(
                f"Windows refused to start a print job on '{printer_name}'. "
                f"The printer may be offline, out of paper, or busy."
            )
        try:
            if not winspool.StartPagePrinter(handle):
                raise PrinterError(f"Could not start a page on '{printer_name}'.")
            try:
                written = wintypes.DWORD(0)
                buf = ctypes.create_string_buffer(data, len(data))
                ok = winspool.WritePrinter(handle, buf, len(data), ctypes.byref(written))
                if not ok or written.value != len(data):
                    raise PrinterError(
                        f"Only {written.value} of {len(data)} bytes reached "
                        f"'{printer_name}'. Check the USB connection and try again."
                    )
            finally:
                winspool.EndPagePrinter(handle)
        finally:
            winspool.EndDocPrinter(handle)
    finally:
        winspool.ClosePrinter(handle)


# --------------------------------------------------------------------------
# macOS backend - CUPS via the `lp` command (no extra install needed)
# --------------------------------------------------------------------------

def _mac_list_printers() -> list[str]:
    try:
        result = subprocess.run(
            ["lpstat", "-p"], capture_output=True, text=True, timeout=10,
        )
    except FileNotFoundError:
        raise PrinterError(
            "macOS's printing system (CUPS) does not appear to be "
            "available on this machine."
        )
    except subprocess.TimeoutExpired:
        raise PrinterError("Timed out asking macOS for the list of installed printers.")

    if result.returncode != 0:
        # `lpstat -p` returns non-zero (with no useful stdout) when
        # there are simply no printers configured yet - not an error
        # worth surfacing as one, the caller's "no printers found" path
        # already covers this.
        return []

    names = []
    for line in result.stdout.splitlines():
        # Lines look like: "printer EPSON_TM_T20III is idle.  enabled since ..."
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "printer":
            names.append(parts[1])
    return names


def _mac_send_raw(printer_name: str, data: bytes, job_name: str) -> None:
    try:
        result = subprocess.run(
            ["lp", "-d", printer_name, "-o", "raw", "-t", job_name],
            input=data, capture_output=True, timeout=30,
        )
    except FileNotFoundError:
        raise PrinterError(
            "macOS's printing system (CUPS) does not appear to be "
            "available on this machine."
        )
    except subprocess.TimeoutExpired:
        raise PrinterError(
            f"Timed out sending the receipt to '{printer_name}'. Check "
            f"the USB connection and that the printer is powered on."
        )

    if result.returncode != 0:
        stderr = result.stderr.decode(errors="replace").strip()
        raise PrinterError(
            f"macOS could not print to '{printer_name}'"
            + (f": {stderr}" if stderr else ".")
            + " Check that the printer is plugged in, powered on, and "
              "its driver is installed."
        )

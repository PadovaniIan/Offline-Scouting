"""
printing/

Stage 15 — Match Results Printing. Everything needed to turn a Match
Lookup screen into two physical 80mm thermal-receipt printouts (one for
Red Alliance, one for Blue Alliance) lives in this package:

    escpos_builder.py  - byte-level ESC/POS command helpers plus the
                          higher-level "build a receipt" logic that knows
                          what to put on the paper (mirrors everything
                          Team Lookup shows for a team, plus that
                          alliance's match prediction).
    printer_backend.py - cross-platform "find installed printers" /
                          "send raw bytes to a printer" layer. Windows
                          talks to the OS print spooler directly via
                          ctypes + winspool.drv (no extra pip package);
                          macOS talks to CUPS via the `lp` command
                          (already on every Mac). No vendor SDK, no
                          direct USB access - the printer must be
                          installed as a normal system printer first
                          (driver install), exactly as the project's
                          release notes already describe.
    settings.py         - remembers which installed printer the user
                           picked, in a small JSON file next to the
                           SQLite database, so printing is a single
                           click after the first time.
    print_dialog.py     - the small Tkinter UI (printer picker, error
                           messages) and the top-level
                           print_match_receipts() function that
                           ui/match_lookup_tab.py's "Print Results"
                           button calls.

No file under calculations/ is imported by this package for anything
other than reading already-computed values off ComputedData - this
package computes nothing new, it only formats and prints numbers the
pipeline already produced.
"""
